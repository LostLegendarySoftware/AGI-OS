// ECHOFS Content Display Module
// Handles file content preview and directory content display

class ContentDisplayManager {
    constructor() {
        this.contentArea = document.getElementById('contentArea');
        this.welcomeScreen = document.getElementById('welcomeScreen');
        this.fileContent = document.getElementById('fileContent');
        this.directoryContent = document.getElementById('directoryContent');
        this.currentPath = document.getElementById('currentPath');
        
        this.currentDisplayType = 'welcome';
        this.currentData = null;
        
        this.init();
    }
    
    init() {
        this.showWelcomeScreen();
    }
    
    showWelcomeScreen() {
        this.hideAllContent();
        this.welcomeScreen.classList.remove('hidden');
        this.currentDisplayType = 'welcome';
        this.currentPath.textContent = 'Select a file or directory to view details';
        this.updateSystemStats();
    }
    
    showFileContent(path, data) {
        this.hideAllContent();
        this.fileContent.classList.remove('hidden');
        this.currentDisplayType = 'file';
        this.currentData = { path, data };
        
        this.updateCurrentPath(path);
        this.renderFileContent(path, data);
    }
    
    showDirectoryContent(path, data) {
        this.hideAllContent();
        this.directoryContent.classList.remove('hidden');
        this.currentDisplayType = 'directory';
        this.currentData = { path, data };
        
        this.updateCurrentPath(path);
        this.renderDirectoryContent(path, data);
    }
    
    hideAllContent() {
        this.welcomeScreen.classList.add('hidden');
        this.fileContent.classList.add('hidden');
        this.directoryContent.classList.add('hidden');
    }
    
    updateCurrentPath(path) {
        this.currentPath.innerHTML = `
            <div class="flex items-center space-x-2">
                <i class="fas fa-folder text-yellow-400"></i>
                <span class="text-white font-semibold">${path}</span>
                <button onclick="contentDisplay.showFileDetail('${path}')" 
                        class="ml-4 px-2 py-1 bg-blue-600 hover:bg-blue-700 rounded text-xs transition-colors">
                    <i class="fas fa-info-circle mr-1"></i>Details
                </button>
            </div>
        `;
    }
    
    renderFileContent(path, data) {
        const fileName = document.getElementById('fileName');
        const fileType = document.getElementById('fileType');
        const fileSize = document.getElementById('fileSize');
        const filePerms = document.getElementById('filePerms');
        const fileLayer = document.getElementById('fileLayer');
        const fileContentText = document.getElementById('fileContentText');
        
        // Update file header
        const name = path.split('/').pop();
        fileName.textContent = name;
        
        const extension = this.getFileExtension(name);
        const typeInfo = window.AGIOS_DATA.fileTypes[extension] || { description: 'Unknown File Type' };
        fileType.innerHTML = `<i class="fas fa-file mr-1"></i>${typeInfo.description}`;
        
        fileSize.innerHTML = `<i class="fas fa-weight mr-1"></i>${this.formatFileSize(data.size || 0)}`;
        filePerms.innerHTML = `<i class="fas fa-lock mr-1"></i>${data.permissions || 'N/A'}`;
        
        if (data.layer) {
            const layerInfo = window.AGIOS_DATA.layers[data.layer];
            fileLayer.innerHTML = `
                <div class="flex items-center space-x-1">
                    <div class="w-3 h-3 ${layerInfo.bgColor} rounded"></div>
                    <span>${data.layer} Layer</span>
                </div>
            `;
        } else {
            fileLayer.innerHTML = '<i class="fas fa-layer-group mr-1"></i>System';
        }
        
        // Update file content
        const content = data.content || this.generatePlaceholderContent(name, extension);
        fileContentText.innerHTML = this.syntaxHighlight(content, extension);
    }
    
    renderDirectoryContent(path, data) {
        const directoryName = document.getElementById('directoryName');
        const directoryLayer = document.getElementById('directoryLayer');
        const directoryItemCount = document.getElementById('directoryItemCount');
        const directoryFiles = document.getElementById('directoryFiles');
        
        // Update directory header
        const name = path.split('/').pop() || path;
        directoryName.textContent = name;
        
        // Determine layer based on path
        const layer = this.determineLayerFromPath(path);
        if (layer) {
            const layerInfo = window.AGIOS_DATA.layers[layer];
            directoryLayer.innerHTML = `
                <div class="flex items-center space-x-1">
                    <div class="w-3 h-3 ${layerInfo.bgColor} rounded"></div>
                    <span>${layer} Layer - ${layerInfo.description}</span>
                </div>
            `;
        } else {
            directoryLayer.innerHTML = '<i class="fas fa-folder mr-1"></i>System Directory';
        }
        
        // Count items
        const itemCount = Object.keys(data).length;
        const fileCount = Object.values(data).filter(item => item.type === 'file').length;
        const dirCount = itemCount - fileCount;
        
        directoryItemCount.innerHTML = `
            <div class="flex items-center space-x-4 text-sm">
                <span><i class="fas fa-folder mr-1"></i>${dirCount} directories</span>
                <span><i class="fas fa-file mr-1"></i>${fileCount} files</span>
                <span><i class="fas fa-list mr-1"></i>${itemCount} total items</span>
            </div>
        `;
        
        // Render directory items
        this.renderDirectoryItems(directoryFiles, data, path);
    }
    
    renderDirectoryItems(container, data, parentPath) {
        container.innerHTML = '';
        
        // Sort items: directories first, then files
        const entries = Object.entries(data);
        entries.sort(([nameA, dataA], [nameB, dataB]) => {
            const isDirectoryA = typeof dataA === 'object' && !dataA.type;
            const isDirectoryB = typeof dataB === 'object' && !dataB.type;
            
            if (isDirectoryA && !isDirectoryB) return -1;
            if (!isDirectoryA && isDirectoryB) return 1;
            return nameA.localeCompare(nameB);
        });
        
        entries.forEach(([itemName, itemData]) => {
            const itemCard = this.createDirectoryItemCard(itemName, itemData, parentPath);
            container.appendChild(itemCard);
        });
    }
    
    createDirectoryItemCard(name, data, parentPath) {
        const isDirectory = typeof data === 'object' && !data.type;
        const fullPath = `${parentPath}/${name}`;
        
        const card = document.createElement('div');
        card.className = 'directory-item cursor-pointer';
        card.onclick = () => {
            if (isDirectory) {
                window.fileTree.selectPath(fullPath);
            } else {
                window.fileTree.selectPath(fullPath);
            }
        };
        
        const extension = isDirectory ? null : this.getFileExtension(name);
        const typeInfo = isDirectory ? 
            { icon: 'fas fa-folder', color: 'text-yellow-400', description: 'Directory' } :
            (window.AGIOS_DATA.fileTypes[extension] || { icon: 'fas fa-file', color: 'text-gray-400', description: 'File' });
        
        card.innerHTML = `
            <div class="flex items-center space-x-3 mb-3">
                <div class="flex-shrink-0">
                    <i class="${typeInfo.icon} text-2xl ${typeInfo.color}"></i>
                </div>
                <div class="flex-1 min-w-0">
                    <h3 class="text-sm font-semibold text-white truncate">${name}</h3>
                    <p class="text-xs text-gray-400">${typeInfo.description}</p>
                </div>
                ${data.layer ? `
                    <div class="flex-shrink-0">
                        <div class="w-3 h-3 ${window.AGIOS_DATA.layers[data.layer].bgColor} rounded" 
                             title="${data.layer} Layer"></div>
                    </div>
                ` : ''}
            </div>
            
            ${!isDirectory && data.size ? `
                <div class="flex justify-between items-center text-xs text-gray-500">
                    <span>${this.formatFileSize(data.size)}</span>
                    <span>${data.permissions || 'N/A'}</span>
                </div>
            ` : ''}
            
            ${isDirectory ? `
                <div class="text-xs text-gray-500">
                    ${Object.keys(data).length} items
                </div>
            ` : ''}
        `;
        
        return card;
    }
    
    syntaxHighlight(content, extension) {
        if (!content) return '';
        
        // Escape HTML
        const escaped = content.replace(/&/g, '&amp;')
                              .replace(/</g, '&lt;')
                              .replace(/>/g, '&gt;');
        
        switch (extension) {
            case '.py':
                return this.highlightPython(escaped);
            case '.json':
            case '.meta':
                return this.highlightJSON(escaped);
            case '.guard':
            case '.sigil':
            case '.spell':
                return this.highlightJSON(escaped); // These are JSON-like
            case '.conf':
                return this.highlightConfig(escaped);
            case '.syn':
                return this.highlightJSON(escaped);
            default:
                return escaped;
        }
    }
    
    highlightPython(code) {
        return code
            .replace(/\b(def|class|import|from|if|else|elif|for|while|try|except|finally|with|as|return|yield|break|continue|pass|lambda|and|or|not|in|is|True|False|None)\b/g, 
                '<span class="syntax-keyword">$1</span>')
            .replace(/(["'])((?:\\.|(?!\1)[^\\])*?)\1/g, 
                '<span class="syntax-string">$1$2$1</span>')
            .replace(/\b(\d+\.?\d*)\b/g, 
                '<span class="syntax-number">$1</span>')
            .replace(/(#.*$)/gm, 
                '<span class="syntax-comment">$1</span>')
            .replace(/\b([a-zA-Z_][a-zA-Z0-9_]*)\s*(?=\()/g, 
                '<span class="syntax-function">$1</span>');
    }
    
    highlightJSON(code) {
        return code
            .replace(/(["'])((?:\\.|(?!\1)[^\\])*?)\1(\s*:)/g, 
                '<span class="syntax-keyword">$1$2$1</span>$3')
            .replace(/(["'])((?:\\.|(?!\1)[^\\])*?)\1(?!\s*:)/g, 
                '<span class="syntax-string">$1$2$1</span>')
            .replace(/\b(\d+\.?\d*)\b/g, 
                '<span class="syntax-number">$1</span>')
            .replace(/\b(true|false|null)\b/g, 
                '<span class="syntax-keyword">$1</span>');
    }
    
    highlightConfig(code) {
        return code
            .replace(/^([^=]+)(=)/gm, 
                '<span class="syntax-keyword">$1</span><span class="syntax-operator">$2</span>')
            .replace(/(["'])((?:\\.|(?!\1)[^\\])*?)\1/g, 
                '<span class="syntax-string">$1$2$1</span>')
            .replace(/^(#.*$)/gm, 
                '<span class="syntax-comment">$1</span>');
    }
    
    generatePlaceholderContent(filename, extension) {
        const templates = {
            '.guard': this.generateGuardContent(filename),
            '.sigil': this.generateSigilContent(filename),
            '.spell': this.generateSpellContent(filename),
            '.meta': this.generateMetaContent(filename),
            '.syn': this.generateSynContent(filename),
            '.conf': this.generateConfContent(filename),
            '.py': this.generatePythonContent(filename),
            '.json': this.generateJSONContent(filename),
            '.key': this.generateKeyContent(filename),
            '.psi': this.generatePsiContent(filename),
            '.state': this.generateStateContent(filename)
        };
        
        return templates[extension] || `# ${filename}\n# AGI-OS System File\n\n# This file is part of the AGI-OS symbolic file system\n# Content would be dynamically generated based on system state`;
    }
    
    generateGuardContent() {
        return JSON.stringify({
            "guard_version": "1.0",
            "created": new Date().toISOString(),
            "layer": "SYSTEM",
            "security_level": 1,
            "validation_rules": {
                "access_control": {
                    "allowed_users": ["SYSTEM"],
                    "permission_matrix": {
                        "read": 1,
                        "write": 0,
                        "execute": 0
                    }
                },
                "truth_validation": {
                    "validation_criteria": "Guardian protocol validation",
                    "trusted_sources": ["SYSTEM_CORE"]
                }
            }
        }, null, 2);
    }
    
    generateSigilContent(filename) {
        return JSON.stringify({
            "sigil_version": "1.0",
            "created": new Date().toISOString(),
            "type": "system",
            "unique_id": filename.replace('.sigil', '').toUpperCase(),
            "symbolic_data": {
                "visual_representation": "◊◈◊",
                "ternary_encoding": "101",
                "semantic_meaning": `System sigil for ${filename}`
            }
        }, null, 2);
    }
    
    generateSpellContent(filename) {
        return JSON.stringify({
            "spell_version": "1.0",
            "created": new Date().toISOString(),
            "author": "SYSTEM",
            "natural_language": {
                "description": `Symbolic script: ${filename}`,
                "usage_examples": ["Execute with XSPELL terminal"]
            },
            "symbolic_logic": {
                "ternary_conditions": ["state_0", "state_1", "state_2"],
                "execution_flow": "sequential"
            }
        }, null, 2);
    }
    
    generateMetaContent(filename) {
        return JSON.stringify({
            "meta_version": "1.0",
            "created": new Date().toISOString(),
            "target": filename.replace('.meta', ''),
            "layer": "SYSTEM",
            "metadata": {
                "description": `Metadata for ${filename.replace('.meta', '')}`,
                "version": "1.0",
                "type": "system_component"
            }
        }, null, 2);
    }
    
    generateSynContent() {
        return JSON.stringify({
            "sync_version": "1.0",
            "created": new Date().toISOString(),
            "sync_type": "system_synchronization",
            "ternary_state": 1,
            "synchronization_data": {
                "sync_targets": ["memory", "storage", "network"],
                "sync_frequency": "real_time"
            }
        }, null, 2);
    }
    
    generateConfContent(filename) {
        return `# AGI-OS Configuration File: ${filename}
# Generated: ${new Date().toISOString()}

[system]
version=1.0
layer=SYSTEM
ternary_logic=enabled

[security]
guardian_protocol=enabled
truth_validation=enabled
security_level=1

[ai_integration]
nlp_engine=enabled
symbolic_reasoning=enabled
machine_learning=enabled`;
    }
    
    generatePythonContent(filename) {
        const className = filename.replace('.py', '').split('_').map(word => 
            word.charAt(0).toUpperCase() + word.slice(1)
        ).join('');
        
        return `# AGI-OS System Module: ${filename}
# Generated: ${new Date().toISOString()}

from typing import Any, Dict, List
import json

class ${className}:
    """AGI-OS system component"""
    
    def __init__(self):
        self.version = "1.0"
        self.layer = "SYSTEM"
        self.ternary_state = 1
    
    def initialize(self) -> bool:
        """Initialize system component"""
        return True
    
    def process(self, data: Any) -> Any:
        """Process system data"""
        return data
    
    def shutdown(self) -> bool:
        """Shutdown system component"""
        return True

if __name__ == "__main__":
    component = ${className}()
    component.initialize()
    print(f"${className} initialized successfully")`;
    }
    
    generateJSONContent(filename) {
        return JSON.stringify({
            "version": "1.0",
            "created": new Date().toISOString(),
            "filename": filename,
            "type": "agios_data",
            "data": {
                "description": `AGI-OS data file: ${filename}`,
                "layer": "SYSTEM",
                "ternary_state": 1
            }
        }, null, 2);
    }
    
    generateKeyContent() {
        return "# AGI-OS Security Key File\n# This is a placeholder - actual keys would be encrypted\n\nKEY_TYPE=SYSTEM\nENCRYPTION=TERNARY_AES\nKEY_LENGTH=256\nCREATED=" + new Date().toISOString();
    }
    
    generatePsiContent() {
        return "# AGI-OS Psi Intelligence File\n# Placeholder for AI consciousness data\n\nPSI_VERSION=1.0\nCONSCIOUSNESS_LEVEL=1\nTERNARY_STATE=1\nCREATED=" + new Date().toISOString();
    }
    
    generateStateContent(filename) {
        return JSON.stringify({
            "state_version": "1.0",
            "created": new Date().toISOString(),
            "filename": filename,
            "current_state": 1,
            "ternary_states": [0, 1, 2],
            "state_data": {
                "description": `System state file: ${filename}`,
                "layer": "SYSTEM"
            }
        }, null, 2);
    }
    
    getFileExtension(filename) {
        const parts = filename.split('.');
        if (parts.length < 2) return '.file';
        
        // Handle compound extensions
        if (parts.length >= 3 && ['app', 'exe', 'key', 'psi'].includes(parts[parts.length - 2])) {
            return '.' + parts[parts.length - 2] + '.' + parts[parts.length - 1];
        }
        
        return '.' + parts[parts.length - 1];
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }
    
    determineLayerFromPath(path) {
        if (path.includes('sys/dark')) return 'DARK';
        if (path.includes('sys/halo')) return 'HALO';
        if (path.includes('usr/dom0')) return 'DOM0';
        if (path.includes('var/haven')) return 'HAVEN';
        if (path.includes('bin/xspell')) return 'XSPELL';
        return null;
    }
    
    updateSystemStats() {
        // Update welcome screen statistics
        const structure = window.AGIOS_DATA.structure.structure;
        let totalFiles = 0;
        let totalDirs = 0;
        let symbolicFiles = 0;
        
        const countItems = (data) => {
            Object.entries(data).forEach(([name, item]) => {
                if (typeof item === 'object' && !item.type) {
                    totalDirs++;
                    countItems(item);
                } else if (item.type === 'file') {
                    totalFiles++;
                    const ext = this.getFileExtension(name);
                    if (['.guard', '.sigil', '.spell', '.meta', '.syn'].includes(ext)) {
                        symbolicFiles++;
                    }
                }
            });
        };
        
        countItems(structure);
        
        document.getElementById('totalFiles').textContent = totalFiles;
        document.getElementById('totalDirs').textContent = totalDirs + '+';
        document.getElementById('symbolicFiles').textContent = symbolicFiles + '+';
    }
    
    // Public method to show file details in modal
    showFileDetail(path) {
        const modal = document.getElementById('fileDetailModal');
        const title = document.getElementById('fileDetailTitle');
        const content = document.getElementById('fileDetailContent');
        
        title.textContent = path.split('/').pop();
        
        // Get file data
        const pathParts = path.split('/');
        let data = window.AGIOS_DATA.structure.structure;
        
        for (const part of pathParts) {
            data = data[part];
            if (!data) break;
        }
        
        if (data && data.type === 'file') {
            const extension = this.getFileExtension(path.split('/').pop());
            const typeInfo = window.AGIOS_DATA.fileTypes[extension] || { description: 'Unknown File Type' };
            
            content.innerHTML = `
                <div class="space-y-6">
                    <div class="grid grid-cols-2 gap-4">
                        <div class="bg-gray-700 p-4 rounded">
                            <h3 class="font-semibold mb-2">File Information</h3>
                            <div class="space-y-2 text-sm">
                                <div><strong>Type:</strong> ${typeInfo.description}</div>
                                <div><strong>Size:</strong> ${this.formatFileSize(data.size || 0)}</div>
                                <div><strong>Permissions:</strong> ${data.permissions || 'N/A'}</div>
                                <div><strong>Extension:</strong> ${extension}</div>
                            </div>
                        </div>
                        <div class="bg-gray-700 p-4 rounded">
                            <h3 class="font-semibold mb-2">System Information</h3>
                            <div class="space-y-2 text-sm">
                                <div><strong>Layer:</strong> ${data.layer || 'System'}</div>
                                <div><strong>Path:</strong> ${path}</div>
                                <div><strong>Created:</strong> ${new Date().toLocaleDateString()}</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-gray-700 p-4 rounded">
                        <h3 class="font-semibold mb-2">Content Preview</h3>
                        <pre class="text-sm bg-gray-800 p-3 rounded overflow-x-auto max-h-64">${this.syntaxHighlight(data.content || this.generatePlaceholderContent(path.split('/').pop(), extension), extension)}</pre>
                    </div>
                </div>
            `;
        }
        
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }
}

// Export for use in other modules
window.ContentDisplayManager = ContentDisplayManager;