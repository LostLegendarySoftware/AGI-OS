// ECHOFS File Tree Module
// Handles interactive directory navigation and file tree display

class FileTreeManager {
    constructor() {
        this.treeContainer = document.getElementById('fileTree');
        this.expandedNodes = new Set();
        this.selectedNode = null;
        this.onFileSelect = null;
        this.onDirectorySelect = null;
        
        this.init();
    }
    
    init() {
        this.renderTree();
        this.setupEventListeners();
    }
    
    renderTree() {
        if (!this.treeContainer) return;
        
        const structure = window.AGIOS_DATA.structure.structure;
        this.treeContainer.innerHTML = '';
        
        // Create root nodes
        Object.keys(structure).forEach(rootPath => {
            const rootElement = this.createTreeNode(rootPath, structure[rootPath], '');
            this.treeContainer.appendChild(rootElement);
        });
    }
    
    createTreeNode(name, data, parentPath) {
        const fullPath = parentPath ? `${parentPath}/${name}` : name;
        const isDirectory = typeof data === 'object' && !data.type;
        const isExpanded = this.expandedNodes.has(fullPath);
        
        // Create main node container
        const nodeContainer = document.createElement('div');
        nodeContainer.className = 'tree-node-container';
        
        // Create the clickable node element
        const nodeElement = document.createElement('div');
        nodeElement.className = `file-tree-item ${isDirectory ? 'directory' : 'file'}`;
        nodeElement.dataset.path = fullPath;
        nodeElement.dataset.type = isDirectory ? 'directory' : 'file';
        
        // Create node content
        const nodeContent = this.createNodeContent(name, data, isDirectory, isExpanded);
        nodeElement.appendChild(nodeContent);
        
        // Add click handler
        nodeElement.addEventListener('click', (e) => {
            e.stopPropagation();
            this.handleNodeClick(nodeElement, fullPath, data, isDirectory);
        });
        
        nodeContainer.appendChild(nodeElement);
        
        // Create children container for directories
        if (isDirectory) {
            const childrenContainer = document.createElement('div');
            childrenContainer.className = 'file-tree-children';
            childrenContainer.style.display = isExpanded ? 'block' : 'none';
            
            if (isExpanded) {
                this.populateChildren(childrenContainer, data, fullPath);
            }
            
            nodeContainer.appendChild(childrenContainer);
        }
        
        return nodeContainer;
    }
    
    createNodeContent(name, data, isDirectory, isExpanded) {
        const content = document.createElement('div');
        content.className = 'flex items-center space-x-2 flex-1';
        
        // Icon
        const icon = document.createElement('i');
        if (isDirectory) {
            icon.className = `fas ${isExpanded ? 'fa-folder-open' : 'fa-folder'} file-icon directory-icon`;
        } else {
            const fileType = this.getFileType(name);
            const typeInfo = window.AGIOS_DATA.fileTypes[fileType] || { icon: 'fas fa-file', color: 'text-gray-400' };
            icon.className = `${typeInfo.icon} file-icon ${fileType.substring(1)}`;
        }
        
        // Name
        const nameSpan = document.createElement('span');
        nameSpan.textContent = name;
        nameSpan.className = 'flex-1 truncate';
        
        content.appendChild(icon);
        content.appendChild(nameSpan);
        
        // Layer indicator for files
        if (!isDirectory && data && data.layer) {
            const layerIndicator = document.createElement('div');
            layerIndicator.className = `layer-indicator ${data.layer.toLowerCase()}`;
            layerIndicator.title = `${data.layer} Layer`;
            content.appendChild(layerIndicator);
        }
        
        // File size for files
        if (!isDirectory && data && data.size) {
            const sizeSpan = document.createElement('span');
            sizeSpan.textContent = this.formatFileSize(data.size);
            sizeSpan.className = 'text-xs text-gray-500 ml-2';
            content.appendChild(sizeSpan);
        }
        
        return content;
    }
    
    populateChildren(container, data, parentPath) {
        if (!data || typeof data !== 'object') return;
        
        // Sort children: directories first, then files
        const entries = Object.entries(data);
        entries.sort(([nameA, dataA], [nameB, dataB]) => {
            const isDirectoryA = typeof dataA === 'object' && !dataA.type;
            const isDirectoryB = typeof dataB === 'object' && !dataB.type;
            
            if (isDirectoryA && !isDirectoryB) return -1;
            if (!isDirectoryA && isDirectoryB) return 1;
            return nameA.localeCompare(nameB);
        });
        
        entries.forEach(([childName, childData]) => {
            const childNode = this.createTreeNode(childName, childData, parentPath);
            container.appendChild(childNode);
        });
    }
    
    handleNodeClick(nodeElement, fullPath, data, isDirectory) {
        // Update selection
        if (this.selectedNode) {
            this.selectedNode.classList.remove('selected');
        }
        nodeElement.classList.add('selected');
        this.selectedNode = nodeElement;
        
        if (isDirectory) {
            // Toggle expansion
            this.toggleDirectory(nodeElement, fullPath, data);
            
            // Notify directory selection
            if (this.onDirectorySelect) {
                this.onDirectorySelect(fullPath, data);
            }
        } else {
            // Notify file selection
            if (this.onFileSelect) {
                this.onFileSelect(fullPath, data);
            }
        }
    }
    
    toggleDirectory(nodeElement, fullPath, data) {
        const container = nodeElement.parentElement;
        const childrenContainer = container.querySelector('.file-tree-children');
        const icon = nodeElement.querySelector('.directory-icon');
        
        if (this.expandedNodes.has(fullPath)) {
            // Collapse
            this.expandedNodes.delete(fullPath);
            childrenContainer.style.display = 'none';
            icon.classList.remove('fa-folder-open');
            icon.classList.add('fa-folder');
        } else {
            // Expand
            this.expandedNodes.add(fullPath);
            childrenContainer.style.display = 'block';
            icon.classList.remove('fa-folder');
            icon.classList.add('fa-folder-open');
            
            // Populate children if not already done
            if (childrenContainer.children.length === 0) {
                this.populateChildren(childrenContainer, data, fullPath);
            }
        }
    }
    
    getFileType(filename) {
        const parts = filename.split('.');
        if (parts.length < 2) return '.file';
        
        // Handle compound extensions like .app.meta
        if (parts.length >= 3 && parts[parts.length - 2] === 'app') {
            return '.app.meta';
        }
        if (parts.length >= 3 && parts[parts.length - 2] === 'exe') {
            return '.exe.meta';
        }
        if (parts.length >= 3 && parts[parts.length - 2] === 'key') {
            return '.key.meta';
        }
        if (parts.length >= 3 && parts[parts.length - 2] === 'psi') {
            return '.psi.meta';
        }
        
        return '.' + parts[parts.length - 1];
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }
    
    setupEventListeners() {
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (!this.selectedNode) return;
            
            switch (e.key) {
                case 'ArrowUp':
                    e.preventDefault();
                    this.navigateUp();
                    break;
                case 'ArrowDown':
                    e.preventDefault();
                    this.navigateDown();
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    this.expandSelected();
                    break;
                case 'ArrowLeft':
                    e.preventDefault();
                    this.collapseSelected();
                    break;
                case 'Enter':
                    e.preventDefault();
                    this.activateSelected();
                    break;
            }
        });
    }
    
    navigateUp() {
        const allNodes = Array.from(this.treeContainer.querySelectorAll('.file-tree-item'));
        const currentIndex = allNodes.indexOf(this.selectedNode);
        if (currentIndex > 0) {
            const prevNode = allNodes[currentIndex - 1];
            prevNode.click();
        }
    }
    
    navigateDown() {
        const allNodes = Array.from(this.treeContainer.querySelectorAll('.file-tree-item'));
        const currentIndex = allNodes.indexOf(this.selectedNode);
        if (currentIndex < allNodes.length - 1) {
            const nextNode = allNodes[currentIndex + 1];
            nextNode.click();
        }
    }
    
    expandSelected() {
        if (this.selectedNode && this.selectedNode.dataset.type === 'directory') {
            const fullPath = this.selectedNode.dataset.path;
            if (!this.expandedNodes.has(fullPath)) {
                this.selectedNode.click();
            }
        }
    }
    
    collapseSelected() {
        if (this.selectedNode && this.selectedNode.dataset.type === 'directory') {
            const fullPath = this.selectedNode.dataset.path;
            if (this.expandedNodes.has(fullPath)) {
                this.selectedNode.click();
            }
        }
    }
    
    activateSelected() {
        if (this.selectedNode) {
            this.selectedNode.click();
        }
    }
    
    // Public methods
    setFileSelectHandler(handler) {
        this.onFileSelect = handler;
    }
    
    setDirectorySelectHandler(handler) {
        this.onDirectorySelect = handler;
    }
    
    expandPath(path) {
        const pathParts = path.split('/');
        let currentPath = '';
        
        pathParts.forEach((part, index) => {
            currentPath = index === 0 ? part : `${currentPath}/${part}`;
            this.expandedNodes.add(currentPath);
        });
        
        this.renderTree();
    }
    
    selectPath(path) {
        this.expandPath(path);
        
        // Wait for render to complete, then select the node
        setTimeout(() => {
            const targetNode = this.treeContainer.querySelector(`[data-path="${path}"]`);
            if (targetNode) {
                targetNode.click();
                targetNode.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }, 100);
    }
    
    refresh() {
        this.renderTree();
    }
    
    getSelectedPath() {
        return this.selectedNode ? this.selectedNode.dataset.path : null;
    }
    
    getExpandedPaths() {
        return Array.from(this.expandedNodes);
    }
    
    // Search functionality
    search(query) {
        const results = [];
        const searchRecursive = (data, currentPath = '') => {
            Object.entries(data).forEach(([name, item]) => {
                const fullPath = currentPath ? `${currentPath}/${name}` : name;
                
                if (name.toLowerCase().includes(query.toLowerCase())) {
                    results.push({
                        path: fullPath,
                        name: name,
                        type: typeof item === 'object' && !item.type ? 'directory' : 'file',
                        data: item
                    });
                }
                
                if (typeof item === 'object' && !item.type) {
                    searchRecursive(item, fullPath);
                }
            });
        };
        
        searchRecursive(window.AGIOS_DATA.structure.structure);
        return results;
    }
    
    highlightSearchResults(results) {
        // Remove existing highlights
        this.treeContainer.querySelectorAll('.search-highlight').forEach(el => {
            el.classList.remove('search-highlight');
        });
        
        // Add highlights to search results
        results.forEach(result => {
            const node = this.treeContainer.querySelector(`[data-path="${result.path}"]`);
            if (node) {
                node.classList.add('search-highlight');
                // Expand parent directories to show the result
                this.expandPath(result.path);
            }
        });
        
        this.renderTree();
    }
    
    clearSearchHighlights() {
        this.treeContainer.querySelectorAll('.search-highlight').forEach(el => {
            el.classList.remove('search-highlight');
        });
    }
}

// Export for use in other modules
window.FileTreeManager = FileTreeManager;