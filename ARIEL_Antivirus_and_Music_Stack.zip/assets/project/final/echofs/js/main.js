// ECHOFS Main Application Module
// Initializes and coordinates all components

// Ensure required classes are available
/* global FileTreeManager, ContentDisplayManager, ModalsManager */

class ECHOFSApplication {
    constructor() {
        this.fileTree = null;
        this.contentDisplay = null;
        this.modals = null;
        this.searchTimeout = null;
        
        this.init();
    }
    
    init() {
        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.initializeComponents();
            });
        } else {
            this.initializeComponents();
        }
    }
    
    initializeComponents() {
        try {
            // Initialize core components
            this.contentDisplay = new ContentDisplayManager();
            this.modals = new ModalsManager();
            this.fileTree = new FileTreeManager();
            
            // Set up component interactions
            this.setupComponentInteractions();
            
            // Set up additional event listeners
            this.setupEventListeners();
            
            // Initialize search functionality
            this.setupSearchFunctionality();
            
            // Set up keyboard shortcuts
            this.setupKeyboardShortcuts();
            
            // Make components globally available
            window.fileTree = this.fileTree;
            window.contentDisplay = this.contentDisplay;
            window.modals = this.modals;
            window.echofs = this;
            
            console.log('ECHOFS initialized successfully');
            
            // Show welcome message
            this.showWelcomeMessage();
            
        } catch (error) {
            console.error('Failed to initialize ECHOFS:', error);
            this.showErrorMessage('Failed to initialize ECHOFS application');
        }
    }
    
    setupComponentInteractions() {
        // File tree selection handlers
        this.fileTree.setFileSelectHandler((path, data) => {
            this.contentDisplay.showFileContent(path, data);
        });
        
        this.fileTree.setDirectorySelectHandler((path, data) => {
            this.contentDisplay.showDirectoryContent(path, data);
        });
    }
    
    setupEventListeners() {
        // Handle browser back/forward buttons
        window.addEventListener('popstate', (e) => {
            if (e.state && e.state.path) {
                this.fileTree.selectPath(e.state.path);
            }
        });
        
        // Handle window resize
        window.addEventListener('resize', () => {
            this.handleResize();
        });
        
        // Handle visibility change (tab switching)
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                this.refreshData();
            }
        });
        
        // Handle online/offline status
        window.addEventListener('online', () => {
            this.showNotification('Connection restored', 'success');
        });
        
        window.addEventListener('offline', () => {
            this.showNotification('Working offline', 'warning');
        });
    }
    
    setupSearchFunctionality() {
        // Create search input if it doesn't exist
        const header = document.querySelector('header .flex');
        if (header && !document.getElementById('searchInput')) {
            const searchContainer = document.createElement('div');
            searchContainer.className = 'flex items-center space-x-2';
            searchContainer.innerHTML = `
                <div class="relative">
                    <input type="text" 
                           id="searchInput" 
                           placeholder="Search files..." 
                           class="bg-gray-700 text-white px-3 py-1 rounded text-sm w-64 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <button id="clearSearch" 
                            class="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white hidden">
                        <i class="fas fa-times text-xs"></i>
                    </button>
                </div>
            `;
            
            // Insert before the system info section
            const systemInfo = header.querySelector('.flex.items-center.space-x-4:last-child');
            header.insertBefore(searchContainer, systemInfo);
            
            // Set up search event listeners
            const searchInput = document.getElementById('searchInput');
            const clearSearch = document.getElementById('clearSearch');
            
            searchInput.addEventListener('input', (e) => {
                this.handleSearch(e.target.value);
            });
            
            clearSearch.addEventListener('click', () => {
                this.clearSearch();
            });
            
            searchInput.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    this.clearSearch();
                }
            });
        }
    }
    
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + F for search
            if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
                e.preventDefault();
                const searchInput = document.getElementById('searchInput');
                if (searchInput) {
                    searchInput.focus();
                }
            }
            
            // Ctrl/Cmd + K for command palette (future feature)
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                this.showNotification('Command palette coming soon!', 'info');
            }
            
            // F1 for help
            if (e.key === 'F1') {
                e.preventDefault();
                this.modals.showSystemInfoModal();
            }
            
            // F2 for applications
            if (e.key === 'F2') {
                e.preventDefault();
                this.modals.showApplicationsModal();
            }
            
            // F3 for layers
            if (e.key === 'F3') {
                e.preventDefault();
                this.modals.showLayersModal();
            }
        });
    }
    
    handleSearch(query) {
        clearTimeout(this.searchTimeout);
        
        const clearButton = document.getElementById('clearSearch');
        
        if (query.trim() === '') {
            this.clearSearch();
            return;
        }
        
        clearButton.classList.remove('hidden');
        
        // Debounce search
        this.searchTimeout = setTimeout(() => {
            const results = this.fileTree.search(query);
            this.fileTree.highlightSearchResults(results);
            
            if (results.length > 0) {
                this.showNotification(`Found ${results.length} result(s)`, 'success');
            } else {
                this.showNotification('No results found', 'warning');
            }
        }, 300);
    }
    
    clearSearch() {
        const searchInput = document.getElementById('searchInput');
        const clearButton = document.getElementById('clearSearch');
        
        if (searchInput) {
            searchInput.value = '';
        }
        
        if (clearButton) {
            clearButton.classList.add('hidden');
        }
        
        this.fileTree.clearSearchHighlights();
        clearTimeout(this.searchTimeout);
    }
    
    handleResize() {
        // Handle responsive layout changes
        const sidebar = document.querySelector('.w-1\\/3');
        
        if (window.innerWidth < 768) {
            // Mobile layout adjustments
            if (sidebar) {
                sidebar.style.maxHeight = '40vh';
            }
        } else {
            // Desktop layout
            if (sidebar) {
                sidebar.style.maxHeight = '';
            }
        }
    }
    
    refreshData() {
        // Refresh file tree and content if needed
        try {
            this.fileTree.refresh();
            this.contentDisplay.updateSystemStats();
        } catch (error) {
            console.error('Failed to refresh data:', error);
        }
    }
    
    showWelcomeMessage() {
        // Show a brief welcome notification
        setTimeout(() => {
            this.showNotification('Welcome to ECHOFS - AGI-OS File System Explorer', 'info', 3000);
        }, 1000);
    }
    
    showErrorMessage(message) {
        this.showNotification(message, 'error', 5000);
    }
    
    showNotification(message, type = 'info', duration = 2000) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 z-50 px-4 py-2 rounded-lg text-white text-sm font-medium transition-all duration-300 transform translate-x-full`;
        
        // Set notification style based on type
        switch (type) {
            case 'success':
                notification.classList.add('bg-green-600');
                break;
            case 'warning':
                notification.classList.add('bg-yellow-600');
                break;
            case 'error':
                notification.classList.add('bg-red-600');
                break;
            default:
                notification.classList.add('bg-blue-600');
        }
        
        notification.innerHTML = `
            <div class="flex items-center space-x-2">
                <i class="fas ${this.getNotificationIcon(type)}"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.classList.remove('translate-x-full');
        }, 100);
        
        // Animate out and remove
        setTimeout(() => {
            notification.classList.add('translate-x-full');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, duration);
    }
    
    getNotificationIcon(type) {
        switch (type) {
            case 'success':
                return 'fa-check-circle';
            case 'warning':
                return 'fa-exclamation-triangle';
            case 'error':
                return 'fa-times-circle';
            default:
                return 'fa-info-circle';
        }
    }
    
    // Public API methods
    navigateToPath(path) {
        this.fileTree.selectPath(path);
        
        // Update browser history
        if (window.history && window.history.pushState) {
            window.history.pushState({ path }, '', `#${path}`);
        }
    }
    
    expandAllDirectories() {
        // Expand all directories in the file tree
        const allDirectories = document.querySelectorAll('.file-tree-item.directory');
        allDirectories.forEach(dir => {
            const path = dir.dataset.path;
            if (!this.fileTree.expandedNodes.has(path)) {
                dir.click();
            }
        });
    }
    
    collapseAllDirectories() {
        // Collapse all directories in the file tree
        const allDirectories = document.querySelectorAll('.file-tree-item.directory');
        allDirectories.forEach(dir => {
            const path = dir.dataset.path;
            if (this.fileTree.expandedNodes.has(path)) {
                dir.click();
            }
        });
    }
    
    exportSystemInfo() {
        // Export system information as JSON
        const systemInfo = {
            timestamp: new Date().toISOString(),
            version: 'AGI-OS v1.0',
            structure: window.AGIOS_DATA.structure,
            layers: window.AGIOS_DATA.layers,
            applications: window.AGIOS_DATA.applications,
            fileTypes: window.AGIOS_DATA.fileTypes,
            expandedPaths: this.fileTree.getExpandedPaths(),
            selectedPath: this.fileTree.getSelectedPath()
        };
        
        const blob = new Blob([JSON.stringify(systemInfo, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = 'agios-system-info.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showNotification('System information exported', 'success');
    }
    
    // Debug methods
    getSystemState() {
        return {
            fileTree: {
                selectedPath: this.fileTree.getSelectedPath(),
                expandedPaths: this.fileTree.getExpandedPaths()
            },
            contentDisplay: {
                currentType: this.contentDisplay.currentDisplayType,
                currentData: this.contentDisplay.currentData
            },
            modals: {
                activeModals: Object.keys(this.modals.modals).filter(key => 
                    !this.modals.modals[key].classList.contains('hidden')
                )
            }
        };
    }
    
    logSystemState() {
        console.log('ECHOFS System State:', this.getSystemState());
    }
}

// Initialize the application
const echofs = new ECHOFSApplication();

// Make it globally available for debugging
window.ECHOFS = echofs;

// Handle any uncaught errors
window.addEventListener('error', (e) => {
    console.error('ECHOFS Error:', e.error);
    if (window.echofs) {
        window.echofs.showNotification('An error occurred. Check console for details.', 'error');
    }
});

// Handle unhandled promise rejections
window.addEventListener('unhandledrejection', (e) => {
    console.error('ECHOFS Promise Rejection:', e.reason);
    if (window.echofs) {
        window.echofs.showNotification('An error occurred. Check console for details.', 'error');
    }
});

console.log('ECHOFS Main module loaded');