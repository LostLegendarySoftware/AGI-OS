// ECHOFS Modals Module
// Handles all modal dialogs and their content

class ModalsManager {
    constructor() {
        this.modals = {
            systemInfo: document.getElementById('systemInfoModal'),
            applications: document.getElementById('applicationsModal'),
            layers: document.getElementById('layersModal'),
            fileDetail: document.getElementById('fileDetailModal')
        };
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.setupModalContent();
    }
    
    setupEventListeners() {
        // System Info Modal
        document.getElementById('systemInfoBtn').addEventListener('click', () => {
            this.showSystemInfoModal();
        });
        document.getElementById('closeSystemInfo').addEventListener('click', () => {
            this.hideModal('systemInfo');
        });
        
        // Applications Modal
        document.getElementById('appsBtn').addEventListener('click', () => {
            this.showApplicationsModal();
        });
        document.getElementById('closeApplications').addEventListener('click', () => {
            this.hideModal('applications');
        });
        
        // Layers Modal
        document.getElementById('layersBtn').addEventListener('click', () => {
            this.showLayersModal();
        });
        document.getElementById('closeLayers').addEventListener('click', () => {
            this.hideModal('layers');
        });
        
        // File Detail Modal
        document.getElementById('closeFileDetail').addEventListener('click', () => {
            this.hideModal('fileDetail');
        });
        
        // Close modals on overlay click
        Object.values(this.modals).forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.hideAllModals();
                }
            });
        });
        
        // Close modals on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.hideAllModals();
            }
        });
    }
    
    setupModalContent() {
        this.setupSystemInfoContent();
        this.setupApplicationsContent();
        this.setupLayersContent();
    }
    
    showSystemInfoModal() {
        this.hideAllModals();
        this.modals.systemInfo.classList.remove('hidden');
        this.modals.systemInfo.classList.add('flex');
    }
    
    showApplicationsModal() {
        this.hideAllModals();
        this.modals.applications.classList.remove('hidden');
        this.modals.applications.classList.add('flex');
    }
    
    showLayersModal() {
        this.hideAllModals();
        this.modals.layers.classList.remove('hidden');
        this.modals.layers.classList.add('flex');
    }
    
    showFileDetailModal() {
        this.hideAllModals();
        this.modals.fileDetail.classList.remove('hidden');
        this.modals.fileDetail.classList.add('flex');
    }
    
    hideModal(modalName) {
        if (this.modals[modalName]) {
            this.modals[modalName].classList.add('hidden');
            this.modals[modalName].classList.remove('flex');
        }
    }
    
    hideAllModals() {
        Object.values(this.modals).forEach(modal => {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        });
    }
    
    setupSystemInfoContent() {
        const content = document.getElementById('systemInfoContent');
        
        content.innerHTML = `
            <div class="space-y-8">
                <!-- System Overview -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-gray-700 p-6 rounded-lg">
                        <h3 class="text-xl font-semibold text-white mb-4">System Overview</h3>
                        <div class="space-y-3 text-sm">
                            <div class="flex justify-between">
                                <span class="text-gray-400">Operating System:</span>
                                <span class="text-white font-semibold">AGI-OS v1.0</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Architecture:</span>
                                <span class="text-white">5-Layer Ternary System</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Logic System:</span>
                                <span class="text-white">Three-State Ternary (0, 1, 2)</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">File System:</span>
                                <span class="text-white">Symbolic Hierarchical</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Security Model:</span>
                                <span class="text-white">Guardian Protocol</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">AI Integration:</span>
                                <span class="text-white">Multi-Modal Assistance</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-gray-700 p-6 rounded-lg">
                        <h3 class="text-xl font-semibold text-white mb-4">System Statistics</h3>
                        <div class="space-y-3 text-sm">
                            <div class="flex justify-between">
                                <span class="text-gray-400">Total Files:</span>
                                <span class="text-white font-semibold">155</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Total Directories:</span>
                                <span class="text-white">60+</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Applications:</span>
                                <span class="text-white">9</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Symbolic Files:</span>
                                <span class="text-white">45+</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">System Layers:</span>
                                <span class="text-white">5</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Security Level:</span>
                                <span class="text-green-400">Guardian Protected</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Layer Architecture -->
                <div class="bg-gray-700 p-6 rounded-lg">
                    <h3 class="text-xl font-semibold text-white mb-4">5-Layer Architecture</h3>
                    <div class="space-y-4">
                        ${Object.entries(window.AGIOS_DATA.layers).map(([key, layer]) => `
                            <div class="flex items-center space-x-4 p-4 bg-gray-800 rounded-lg">
                                <div class="w-4 h-4 ${layer.bgColor} rounded"></div>
                                <div class="flex-1">
                                    <div class="flex items-center space-x-2">
                                        <span class="font-semibold text-white">${key}</span>
                                        <span class="text-xs text-gray-400">Level ${layer.level}</span>
                                    </div>
                                    <div class="text-sm text-gray-300">${layer.name}</div>
                                    <div class="text-xs text-gray-400 mt-1">${layer.description}</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <!-- Key Features -->
                <div class="bg-gray-700 p-6 rounded-lg">
                    <h3 class="text-xl font-semibold text-white mb-4">Key Features</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="space-y-3">
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-cube text-blue-400"></i>
                                <span class="text-white">Ternary Logic Processing</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-layer-group text-purple-400"></i>
                                <span class="text-white">5-Layer Modular Architecture</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-folder text-yellow-400"></i>
                                <span class="text-white">Symbolic File System</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-robot text-green-400"></i>
                                <span class="text-white">AI-Assisted Applications</span>
                            </div>
                        </div>
                        <div class="space-y-3">
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-terminal text-cyan-400"></i>
                                <span class="text-white">Natural Language Interface</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-shield-alt text-red-400"></i>
                                <span class="text-white">Guardian Protocol Security</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-sync text-lime-400"></i>
                                <span class="text-white">Real-time Synchronization</span>
                            </div>
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-brain text-violet-400"></i>
                                <span class="text-white">Symbolic Logic Integration</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Technical Specifications -->
                <div class="bg-gray-700 p-6 rounded-lg">
                    <h3 class="text-xl font-semibold text-white mb-4">Technical Specifications</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
                        <div>
                            <h4 class="font-semibold text-white mb-2">Core System</h4>
                            <ul class="space-y-1 text-gray-300">
                                <li>• Ternary Kernel</li>
                                <li>• Entropy Engine</li>
                                <li>• Symbolic Execution</li>
                                <li>• Guardian Protocol</li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-white mb-2">AI Integration</h4>
                            <ul class="space-y-1 text-gray-300">
                                <li>• Natural Language Processing</li>
                                <li>• Computer Vision</li>
                                <li>• Machine Learning</li>
                                <li>• Symbolic Reasoning</li>
                            </ul>
                        </div>
                        <div>
                            <h4 class="font-semibold text-white mb-2">File Types</h4>
                            <ul class="space-y-1 text-gray-300">
                                <li>• .guard (Security)</li>
                                <li>• .sigil (Symbolic ID)</li>
                                <li>• .spell (Scripts)</li>
                                <li>• .meta (Metadata)</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    setupApplicationsContent() {
        const content = document.getElementById('applicationsContent');
        const applications = window.AGIOS_DATA.applications;
        
        content.innerHTML = `
            <div class="space-y-6">
                <div class="text-center mb-8">
                    <h3 class="text-2xl font-bold text-white mb-2">AGI-OS Application Suite</h3>
                    <p class="text-gray-400">9 AI-powered applications for enhanced productivity and creativity</p>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    ${Object.entries(applications).map(([appKey, app]) => `
                        <div class="app-card" onclick="modals.showApplicationDetail('${appKey}')">
                            <div class="app-icon ${app.color}">
                                <i class="${app.icon}"></i>
                            </div>
                            <h4 class="text-lg font-semibold text-white mb-2">${app.name}</h4>
                            <p class="text-sm text-gray-400 mb-3">${app.category}</p>
                            <p class="text-sm text-gray-300 mb-4 line-clamp-3">${app.description}</p>
                            
                            <div class="space-y-2">
                                <div class="text-xs text-gray-400">Key Features:</div>
                                <ul class="text-xs text-gray-300 space-y-1">
                                    ${app.features.slice(0, 3).map(feature => `
                                        <li class="flex items-start space-x-1">
                                            <span class="text-green-400 mt-0.5">•</span>
                                            <span>${feature}</span>
                                        </li>
                                    `).join('')}
                                </ul>
                            </div>
                            
                            <div class="mt-4 pt-4 border-t border-gray-600">
                                <div class="flex items-center justify-between text-xs">
                                    <span class="text-gray-400">Memory:</span>
                                    <span class="text-white">${app.systemRequirements.memory}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
                
                <!-- Application Categories -->
                <div class="mt-8 bg-gray-700 p-6 rounded-lg">
                    <h3 class="text-xl font-semibold text-white mb-4">Application Categories</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div class="bg-gray-800 p-4 rounded-lg">
                            <h4 class="font-semibold text-white mb-2">Creative Tools</h4>
                            <ul class="text-sm text-gray-300 space-y-1">
                                <li>• DarkPaint - AI Drawing</li>
                            </ul>
                        </div>
                        <div class="bg-gray-800 p-4 rounded-lg">
                            <h4 class="font-semibold text-white mb-2">Productivity</h4>
                            <ul class="text-sm text-gray-300 space-y-1">
                                <li>• PsiWord - AI Writing</li>
                                <li>• ChronoPulse - Scheduling</li>
                                <li>• SpellFile - File Management</li>
                            </ul>
                        </div>
                        <div class="bg-gray-800 p-4 rounded-lg">
                            <h4 class="font-semibold text-white mb-2">Development</h4>
                            <ul class="text-sm text-gray-300 space-y-1">
                                <li>• HelixLab - AI Development</li>
                                <li>• DaemonStudio - Daemon Tools</li>
                                <li>• PersonaForge - AI Agents</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    setupLayersContent() {
        const content = document.getElementById('layersContent');
        const layers = window.AGIOS_DATA.layers;
        
        content.innerHTML = `
            <div class="space-y-6">
                <div class="text-center mb-8">
                    <h3 class="text-2xl font-bold text-white mb-2">AGI-OS 5-Layer Architecture</h3>
                    <p class="text-gray-400">Hierarchical system design with specialized layer functions</p>
                </div>
                
                <div class="space-y-6">
                    ${Object.entries(layers).map(([key, layer]) => `
                        <div class="layer-card ${key.toLowerCase()}">
                            <div class="flex items-start space-x-4">
                                <div class="flex-shrink-0">
                                    <div class="w-12 h-12 ${layer.bgColor} rounded-lg flex items-center justify-center">
                                        <span class="text-white font-bold text-lg">${layer.level}</span>
                                    </div>
                                </div>
                                <div class="flex-1">
                                    <div class="flex items-center space-x-2 mb-2">
                                        <h4 class="text-xl font-semibold text-white">${key}</h4>
                                        <span class="text-xs px-2 py-1 bg-gray-600 rounded text-gray-300">Level ${layer.level}</span>
                                    </div>
                                    <h5 class="text-lg ${layer.color} mb-3">${layer.name}</h5>
                                    <p class="text-gray-300 mb-4">${layer.description}</p>
                                    
                                    <div class="bg-gray-800 p-4 rounded-lg">
                                        <h6 class="font-semibold text-white mb-2">Key Components:</h6>
                                        <div class="grid grid-cols-1 md:grid-cols-3 gap-2">
                                            ${layer.components.map(component => `
                                                <div class="flex items-center space-x-2">
                                                    <div class="w-2 h-2 ${layer.bgColor} rounded"></div>
                                                    <span class="text-sm text-gray-300">${component}</span>
                                                </div>
                                            `).join('')}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
                
                <!-- Layer Interaction Diagram -->
                <div class="bg-gray-700 p-6 rounded-lg">
                    <h3 class="text-xl font-semibold text-white mb-4">Layer Interaction Flow</h3>
                    <div class="flex flex-col space-y-4">
                        ${Object.entries(layers).map(([key, layer], index) => `
                            <div class="flex items-center space-x-4">
                                <div class="w-8 h-8 ${layer.bgColor} rounded flex items-center justify-center">
                                    <span class="text-white font-bold text-sm">${layer.level}</span>
                                </div>
                                <div class="flex-1">
                                    <div class="text-white font-semibold">${key}</div>
                                    <div class="text-sm text-gray-400">${layer.name}</div>
                                </div>
                                ${index < Object.keys(layers).length - 1 ? `
                                    <div class="text-gray-400">
                                        <i class="fas fa-arrow-down"></i>
                                    </div>
                                ` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <!-- Technical Details -->
                <div class="bg-gray-700 p-6 rounded-lg">
                    <h3 class="text-xl font-semibold text-white mb-4">Technical Implementation</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h4 class="font-semibold text-white mb-3">Ternary Logic System</h4>
                            <div class="space-y-2 text-sm">
                                <div class="flex items-center space-x-2">
                                    <div class="ternary-indicator ternary-0">State 0</div>
                                    <span class="text-gray-300">False/Inactive</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <div class="ternary-indicator ternary-1">State 1</div>
                                    <span class="text-gray-300">True/Active</span>
                                </div>
                                <div class="flex items-center space-x-2">
                                    <div class="ternary-indicator ternary-2">State 2</div>
                                    <span class="text-gray-300">Unknown/Conditional</span>
                                </div>
                            </div>
                        </div>
                        <div>
                            <h4 class="font-semibold text-white mb-3">Layer Communication</h4>
                            <ul class="text-sm text-gray-300 space-y-1">
                                <li>• Inter-layer message passing</li>
                                <li>• Ternary state synchronization</li>
                                <li>• Guardian protocol validation</li>
                                <li>• Symbolic data exchange</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    showApplicationDetail(appKey) {
        const app = window.AGIOS_DATA.applications[appKey];
        if (!app) return;
        
        const modal = document.getElementById('fileDetailModal');
        const title = document.getElementById('fileDetailTitle');
        const content = document.getElementById('fileDetailContent');
        
        title.textContent = app.fullName;
        
        content.innerHTML = `
            <div class="space-y-6">
                <!-- App Header -->
                <div class="flex items-start space-x-4">
                    <div class="app-icon ${app.color} flex-shrink-0">
                        <i class="${app.icon}"></i>
                    </div>
                    <div class="flex-1">
                        <h3 class="text-2xl font-bold text-white mb-2">${app.name}</h3>
                        <p class="text-lg ${window.AGIOS_DATA.layers.DOM0.color} mb-2">${app.category}</p>
                        <p class="text-gray-300">${app.description}</p>
                    </div>
                </div>
                
                <!-- Features -->
                <div class="bg-gray-700 p-6 rounded-lg">
                    <h4 class="text-xl font-semibold text-white mb-4">Key Features</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        ${app.features.map(feature => `
                            <div class="flex items-start space-x-2">
                                <i class="fas fa-check text-green-400 mt-1 flex-shrink-0"></i>
                                <span class="text-gray-300">${feature}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <!-- AI Integration -->
                <div class="bg-gray-700 p-6 rounded-lg">
                    <h4 class="text-xl font-semibold text-white mb-4">AI Integration</h4>
                    <div class="space-y-3">
                        ${Object.entries(app.aiIntegration).map(([type, description]) => `
                            <div class="flex items-start space-x-3">
                                <div class="w-2 h-2 bg-blue-400 rounded mt-2 flex-shrink-0"></div>
                                <div>
                                    <div class="font-semibold text-white">${type}</div>
                                    <div class="text-sm text-gray-300">${description}</div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <!-- Technical Details -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-gray-700 p-6 rounded-lg">
                        <h4 class="text-xl font-semibold text-white mb-4">File Types</h4>
                        <div class="space-y-2">
                            ${app.fileTypes.map(fileType => {
                                const typeInfo = window.AGIOS_DATA.fileTypes[fileType] || { icon: 'fas fa-file', color: 'text-gray-400', description: 'File' };
                                return `
                                    <div class="flex items-center space-x-2">
                                        <i class="${typeInfo.icon} ${typeInfo.color}"></i>
                                        <span class="text-gray-300">${fileType}</span>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                    
                    <div class="bg-gray-700 p-6 rounded-lg">
                        <h4 class="text-xl font-semibold text-white mb-4">System Requirements</h4>
                        <div class="space-y-2 text-sm">
                            ${Object.entries(app.systemRequirements).map(([req, value]) => `
                                <div class="flex justify-between">
                                    <span class="text-gray-400 capitalize">${req.replace(/([A-Z])/g, ' $1')}:</span>
                                    <span class="text-white">${value}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
                
                <!-- Launch Button -->
                <div class="text-center pt-4">
                    <button class="px-6 py-3 bg-green-600 hover:bg-green-700 rounded-lg text-white font-semibold transition-colors">
                        <i class="${app.icon} mr-2"></i>Launch ${app.name}
                    </button>
                    <p class="text-xs text-gray-400 mt-2">Application would launch in AGI-OS environment</p>
                </div>
            </div>
        `;
        
        this.hideAllModals();
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }
}

// Export for use in other modules
window.ModalsManager = ModalsManager;