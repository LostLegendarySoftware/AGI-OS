# ARIEL Antivirus System - API Reference for Developers

**Version:** 1.0.0  
**Date:** 2025-07-12  
**Audience:** Developers and Integration Engineers

## API Overview

The ARIEL Antivirus System provides a comprehensive RESTful API for integration with external systems, custom applications, and management tools. The API supports JSON request/response format and uses token-based authentication.

## Base Configuration

### API Endpoints
- **Production:** `https://localhost:8080/api/v1`
- **Development:** `http://localhost:8080/api/v1`

### Authentication
All API requests require authentication using Bearer tokens.

```bash
# Generate API token
sudo ariel-api --generate-token --name "MyApp" --permissions "read,write"

# Example token usage
curl -H "Authorization: Bearer YOUR_TOKEN_HERE" \
     -H "Content-Type: application/json" \
     https://localhost:8080/api/v1/status
```

## Authentication API

### Generate Token
```http
POST /api/v1/auth/token
Content-Type: application/json

{
  "username": "admin",
  "password": "secure_password",
  "permissions": ["read", "write", "admin"],
  "expires_in": 3600
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expires_at": "2024-07-12T12:00:00Z",
  "permissions": ["read", "write", "admin"]
}
```

### Revoke Token
```http
DELETE /api/v1/auth/token/{token_id}
Authorization: Bearer YOUR_TOKEN
```

## System Status API

### Get System Status
```http
GET /api/v1/status
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "status": "running",
  "version": "1.0.0",
  "uptime": 86400,
  "components": {
    "phiguard_core": {
      "status": "active",
      "cpu_usage": 2.5,
      "memory_usage": 134217728
    },
    "warden_monitor": {
      "status": "active",
      "monitored_processes": 1247,
      "alerts_count": 0
    },
    "rehab_scanner": {
      "status": "active",
      "last_scan": "2024-07-12T10:30:00Z",
      "threats_detected": 0
    }
  },
  "protection_status": {
    "realtime_protection": true,
    "last_update": "2024-07-12T09:00:00Z",
    "signature_version": "20240712.001"
  }
}
```

### Get Component Health
```http
GET /api/v1/status/health
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "overall_health": "healthy",
  "components": [
    {
      "name": "PhiGuard_Core",
      "status": "healthy",
      "last_check": "2024-07-12T10:45:00Z",
      "metrics": {
        "cpu_usage": 2.1,
        "memory_usage": 128000000,
        "disk_usage": 1024000000
      }
    }
  ],
  "alerts": []
}
```

## Scanning API

### Initiate Scan
```http
POST /api/v1/scan
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "type": "quick|full|custom",
  "paths": ["/home/user/Downloads"],
  "options": {
    "deep_scan": true,
    "heuristic_analysis": true,
    "max_file_size": 104857600
  },
  "priority": "high|normal|low",
  "callback_url": "https://your-app.com/scan-complete"
}
```

**Response:**
```json
{
  "scan_id": "scan_123456789",
  "status": "initiated",
  "estimated_duration": 300,
  "created_at": "2024-07-12T10:45:00Z"
}
```

### Get Scan Status
```http
GET /api/v1/scan/{scan_id}
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "scan_id": "scan_123456789",
  "status": "running|completed|failed|cancelled",
  "progress": 65.5,
  "files_scanned": 12847,
  "threats_found": 2,
  "started_at": "2024-07-12T10:45:00Z",
  "estimated_completion": "2024-07-12T10:50:00Z",
  "results": {
    "clean_files": 12845,
    "infected_files": 2,
    "suspicious_files": 0,
    "errors": 0
  }
}
```

### Cancel Scan
```http
DELETE /api/v1/scan/{scan_id}
Authorization: Bearer YOUR_TOKEN
```

### Get Scan History
```http
GET /api/v1/scan/history?limit=50&offset=0
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "scans": [
    {
      "scan_id": "scan_123456789",
      "type": "quick",
      "status": "completed",
      "started_at": "2024-07-12T10:45:00Z",
      "completed_at": "2024-07-12T10:50:00Z",
      "threats_found": 0,
      "files_scanned": 5432
    }
  ],
  "total": 127,
  "limit": 50,
  "offset": 0
}
```

## Threat Management API

### List Threats
```http
GET /api/v1/threats?status=active&limit=50
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "threats": [
    {
      "threat_id": "threat_987654321",
      "name": "Trojan.Generic.12345",
      "severity": "high|medium|low",
      "status": "quarantined|removed|active",
      "file_path": "/home/user/Downloads/malware.exe",
      "detected_at": "2024-07-12T10:30:00Z",
      "detection_method": "signature|heuristic|behavioral|ai",
      "hash": {
        "md5": "d41d8cd98f00b204e9800998ecf8427e",
        "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
      }
    }
  ],
  "total": 15,
  "active": 2,
  "quarantined": 13
}
```

### Get Threat Details
```http
GET /api/v1/threats/{threat_id}
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "threat_id": "threat_987654321",
  "name": "Trojan.Generic.12345",
  "description": "Generic trojan detected by heuristic analysis",
  "severity": "high",
  "status": "quarantined",
  "file_info": {
    "path": "/home/user/Downloads/malware.exe",
    "size": 2048576,
    "created": "2024-07-12T09:00:00Z",
    "modified": "2024-07-12T09:00:00Z"
  },
  "detection_info": {
    "method": "heuristic",
    "confidence": 0.95,
    "engine": "ReHabScanner",
    "signature": "Heur.Trojan.Generic"
  },
  "actions_taken": [
    {
      "action": "quarantine",
      "timestamp": "2024-07-12T10:30:00Z",
      "success": true
    }
  ]
}
```

### Remove Threat
```http
DELETE /api/v1/threats/{threat_id}
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "action": "delete|restore|quarantine",
  "confirm": true
}
```

### Restore from Quarantine
```http
POST /api/v1/threats/{threat_id}/restore
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "destination": "/home/user/restored_files/",
  "confirm": true
}
```

## Configuration API

### Get Configuration
```http
GET /api/v1/config
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "engine": {
    "realtime_protection": true,
    "scan_on_access": true,
    "update_interval": 3600
  },
  "scanning": {
    "quick_scan": {
      "enabled": true,
      "schedule": "daily"
    }
  },
  "biometric": {
    "enabled": true,
    "heart_rate_monitoring": {
      "enabled": true
    }
  }
}
```

### Update Configuration
```http
PUT /api/v1/config
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "engine": {
    "realtime_protection": false,
    "update_interval": 7200
  }
}
```

### Get Specific Configuration Section
```http
GET /api/v1/config/engine
Authorization: Bearer YOUR_TOKEN
```

### Validate Configuration
```http
POST /api/v1/config/validate
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "config": {
    "engine": {
      "realtime_protection": true,
      "invalid_setting": "invalid_value"
    }
  }
}
```

**Response:**
```json
{
  "valid": false,
  "errors": [
    {
      "field": "engine.invalid_setting",
      "message": "Unknown configuration option",
      "code": "UNKNOWN_OPTION"
    }
  ]
}
```

## Biometric API

### Get Biometric Status
```http
GET /api/v1/biometric/status
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "enabled": true,
  "components": {
    "heart_rate": {
      "enabled": true,
      "device_connected": true,
      "last_reading": {
        "bpm": 72,
        "timestamp": "2024-07-12T10:45:00Z"
      }
    },
    "voice_recognition": {
      "enabled": true,
      "model_loaded": true,
      "last_authentication": "2024-07-12T10:30:00Z"
    },
    "gesture_recognition": {
      "enabled": false,
      "camera_available": true
    }
  }
}
```

### Authenticate with Biometrics
```http
POST /api/v1/biometric/authenticate
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "methods": ["heart_rate", "voice"],
  "timeout": 30,
  "required_factors": 2
}
```

**Response:**
```json
{
  "authentication_id": "auth_123456",
  "status": "pending",
  "required_methods": ["heart_rate", "voice"],
  "completed_methods": [],
  "expires_at": "2024-07-12T11:00:00Z"
}
```

### Check Authentication Status
```http
GET /api/v1/biometric/authenticate/{authentication_id}
Authorization: Bearer YOUR_TOKEN
```

## Updates API

### Check for Updates
```http
GET /api/v1/updates/check
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "updates_available": true,
  "current_version": "1.0.0",
  "latest_version": "1.0.1",
  "signature_updates": {
    "current": "20240712.001",
    "latest": "20240712.003",
    "count": 2847
  },
  "engine_updates": {
    "available": false
  }
}
```

### Download Updates
```http
POST /api/v1/updates/download
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "types": ["signatures", "engine"],
  "auto_install": false
}
```

### Install Updates
```http
POST /api/v1/updates/install
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "update_id": "update_123456",
  "restart_service": true
}
```

## Logs API

### Get Recent Logs
```http
GET /api/v1/logs?level=INFO&limit=100&component=PhiGuard_Core
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "logs": [
    {
      "timestamp": "2024-07-12T10:45:00Z",
      "level": "INFO",
      "component": "PhiGuard_Core",
      "message": "Real-time protection enabled",
      "details": {
        "process_id": 1234,
        "thread_id": 5678
      }
    }
  ],
  "total": 1247,
  "has_more": true
}
```

### Search Logs
```http
POST /api/v1/logs/search
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "query": "threat detected",
  "start_time": "2024-07-12T00:00:00Z",
  "end_time": "2024-07-12T23:59:59Z",
  "components": ["ReHabScanner", "SigStrat"],
  "levels": ["WARNING", "ERROR"]
}
```

## Statistics API

### Get System Statistics
```http
GET /api/v1/stats
Authorization: Bearer YOUR_TOKEN
```

**Response:**
```json
{
  "period": "24h",
  "scans": {
    "total": 15,
    "completed": 14,
    "failed": 1,
    "files_scanned": 125847,
    "threats_found": 3
  },
  "threats": {
    "detected": 3,
    "quarantined": 3,
    "removed": 0,
    "false_positives": 0
  },
  "performance": {
    "avg_cpu_usage": 3.2,
    "avg_memory_usage": 256000000,
    "scan_throughput": 1247.5
  },
  "updates": {
    "signature_updates": 2,
    "last_update": "2024-07-12T09:00:00Z"
  }
}
```

## Webhooks API

### Register Webhook
```http
POST /api/v1/webhooks
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "url": "https://your-app.com/webhook",
  "events": ["threat_detected", "scan_completed", "update_available"],
  "secret": "your_webhook_secret",
  "active": true
}
```

### Webhook Event Examples

#### Threat Detected Event
```json
{
  "event": "threat_detected",
  "timestamp": "2024-07-12T10:30:00Z",
  "data": {
    "threat_id": "threat_987654321",
    "name": "Trojan.Generic.12345",
    "severity": "high",
    "file_path": "/home/user/Downloads/malware.exe",
    "action_taken": "quarantined"
  }
}
```

#### Scan Completed Event
```json
{
  "event": "scan_completed",
  "timestamp": "2024-07-12T10:50:00Z",
  "data": {
    "scan_id": "scan_123456789",
    "type": "quick",
    "duration": 300,
    "files_scanned": 5432,
    "threats_found": 0
  }
}
```

## Error Handling

### Standard Error Response
```json
{
  "error": {
    "code": "INVALID_REQUEST",
    "message": "The request is invalid",
    "details": "Missing required field: scan_type",
    "timestamp": "2024-07-12T10:45:00Z",
    "request_id": "req_123456789"
  }
}
```

### Common Error Codes
- `UNAUTHORIZED` (401): Invalid or missing authentication token
- `FORBIDDEN` (403): Insufficient permissions
- `NOT_FOUND` (404): Resource not found
- `INVALID_REQUEST` (400): Malformed request
- `RATE_LIMITED` (429): Too many requests
- `INTERNAL_ERROR` (500): Server error

## Rate Limiting

The API implements rate limiting to prevent abuse:
- **Default:** 100 requests per minute per token
- **Burst:** Up to 200 requests in a 10-second window
- **Headers:** Rate limit information in response headers

```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1720785600
```

## SDK Examples

### Python SDK Example
```python
import requests
import json

class ArielAVAPI:
    def __init__(self, base_url, token):
        self.base_url = base_url
        self.headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }

    def get_status(self):
        response = requests.get(f'{self.base_url}/status', headers=self.headers)
        return response.json()

    def start_scan(self, scan_type, paths):
        data = {
            'type': scan_type,
            'paths': paths
        }
        response = requests.post(f'{self.base_url}/scan', 
                               headers=self.headers, 
                               json=data)
        return response.json()

# Usage
api = ArielAVAPI('https://localhost:8080/api/v1', 'your_token_here')
status = api.get_status()
scan = api.start_scan('quick', ['/home/user/Downloads'])
```

### JavaScript SDK Example
```javascript
class ArielAVAPI {
    constructor(baseUrl, token) {
        this.baseUrl = baseUrl;
        this.headers = {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        };
    }

    async getStatus() {
        const response = await fetch(`${this.baseUrl}/status`, {
            headers: this.headers
        });
        return await response.json();
    }

    async startScan(scanType, paths) {
        const response = await fetch(`${this.baseUrl}/scan`, {
            method: 'POST',
            headers: this.headers,
            body: JSON.stringify({
                type: scanType,
                paths: paths
            })
        });
        return await response.json();
    }
}

// Usage
const api = new ArielAVAPI('https://localhost:8080/api/v1', 'your_token_here');
const status = await api.getStatus();
const scan = await api.startScan('quick', ['/home/user/Downloads']);
```

## Testing and Development

### API Testing with curl
```bash
# Set your token
TOKEN="your_token_here"
BASE_URL="https://localhost:8080/api/v1"

# Test authentication
curl -H "Authorization: Bearer $TOKEN" "$BASE_URL/status"

# Start a scan
curl -X POST -H "Authorization: Bearer $TOKEN" \
     -H "Content-Type: application/json" \
     -d '{"type":"quick","paths":["/tmp"]}' \
     "$BASE_URL/scan"
```

### Development Environment Setup
1. **Enable API in development mode:**
   ```bash
   sudo ariel-config --set api.enabled=true
   sudo ariel-config --set api.ssl_enabled=false  # For development only
   ```

2. **Generate development token:**
   ```bash
   sudo ariel-api --generate-token --name "Development" --expires-in 86400
   ```

3. **Enable CORS for web development:**
   ```bash
   sudo ariel-config --set api.cors_enabled=true
   ```

This API reference provides comprehensive documentation for integrating with the ARIEL Antivirus System. For additional examples and advanced usage, refer to the SDK documentation and sample applications.
