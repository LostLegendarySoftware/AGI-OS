# ARIEL Antivirus System - Configuration Reference Guide

**Version:** 1.0.0  
**Date:** 2025-07-12  
**Audience:** System Administrators and Advanced Users

## Configuration Overview

The ARIEL Antivirus System uses JSON-based configuration files for all components. Configuration files are organized hierarchically and support environment-specific overrides.

## Configuration File Locations

### Linux
- **Main Config:** `/etc/ariel_antivirus/main.json`
- **Daemon Config:** `/etc/ariel_antivirus/daemon.json`
- **Logging Config:** `/etc/ariel_antivirus/logging.json`
- **Biometric Config:** `/etc/ariel_antivirus/biometric.json`
- **Module Configs:** `/etc/ariel_antivirus/modules/`

### Windows
- **Main Config:** `C:\Program Files\ARIEL_Antivirus\config\main.json`
- **Service Config:** `C:\Program Files\ARIEL_Antivirus\config\service.json`
- **Logging Config:** `C:\Program Files\ARIEL_Antivirus\config\logging.json`
- **Biometric Config:** `C:\Program Files\ARIEL_Antivirus\config\biometric.json`
- **Module Configs:** `C:\Program Files\ARIEL_Antivirus\config\modules\`

## Main Configuration (main.json)

### Complete Configuration Schema
```json
{
  "version": "1.0.0",
  "engine": {
    "realtime_protection": true,
    "scan_on_access": true,
    "scan_on_write": true,
    "quarantine_threats": true,
    "auto_clean": false,
    "update_interval": 3600,
    "signature_update_url": "https://updates.ariel-av.com/signatures",
    "cloud_intelligence": true,
    "heuristic_analysis": true,
    "behavioral_analysis": true,
    "max_scan_threads": 4,
    "scan_timeout": 300,
    "max_file_size": 104857600,
    "scan_archives": true,
    "scan_compressed": true,
    "scan_email": true
  },
  "scanning": {
    "quick_scan": {
      "enabled": true,
      "paths": [
        "/home",
        "/tmp",
        "/var/tmp"
      ],
      "schedule": "daily",
      "time": "02:00"
    },
    "full_scan": {
      "enabled": true,
      "paths": ["/"],
      "schedule": "weekly",
      "day": "sunday",
      "time": "03:00",
      "exclude_paths": [
        "/proc",
        "/sys",
        "/dev"
      ]
    },
    "custom_scans": [
      {
        "name": "Downloads Scan",
        "paths": ["/home/*/Downloads"],
        "schedule": "hourly",
        "deep_scan": true
      }
    ]
  },
  "quarantine": {
    "enabled": true,
    "path": "/var/quarantine/ariel",
    "max_size": 1073741824,
    "retention_days": 30,
    "encrypt_files": true,
    "auto_submit_samples": false
  },
  "exclusions": {
    "paths": [
      "/opt/safe_software",
      "/home/user/trusted_files"
    ],
    "extensions": [
      ".log",
      ".tmp",
      ".cache"
    ],
    "processes": [
      "backup_process",
      "system_updater"
    ],
    "hash_whitelist": [
      "sha256:abcd1234...",
      "md5:efgh5678..."
    ]
  },
  "biometric": {
    "enabled": true,
    "heart_rate_monitoring": {
      "enabled": true,
      "device": "/dev/ttyUSB0",
      "threshold_min": 60,
      "threshold_max": 100,
      "sampling_rate": 1000,
      "authentication_window": 30
    },
    "voice_approval": {
      "enabled": true,
      "microphone_device": "default",
      "voice_model": "/opt/ariel/models/voice_model.bin",
      "confidence_threshold": 0.85,
      "phrase_timeout": 5
    },
    "gesture_recognition": {
      "enabled": false,
      "camera_device": "/dev/video0",
      "model_path": "/opt/ariel/models/gesture_model.bin",
      "recognition_threshold": 0.9
    },
    "multi_factor": {
      "required_factors": 2,
      "timeout": 300,
      "max_attempts": 3
    }
  },
  "audio": {
    "protect_plugins": true,
    "scan_audio_files": true,
    "monitor_daw_processes": true,
    "supported_formats": [
      "wav", "mp3", "flac", "aiff", "ogg"
    ],
    "plugin_paths": [
      "/usr/lib/vst",
      "/usr/lib/lv2",
      "~/.vst"
    ],
    "daw_processes": [
      "ardour",
      "reaper",
      "cubase",
      "protools"
    ],
    "real_time_protection": true,
    "latency_optimization": true
  },
  "network": {
    "firewall_integration": true,
    "traffic_monitoring": true,
    "threat_blocking": true,
    "dns_filtering": true,
    "intrusion_detection": true,
    "allowed_ports": [80, 443, 22, 53],
    "blocked_ips": [],
    "threat_feeds": [
      "https://feeds.ariel-av.com/malware-ips",
      "https://feeds.ariel-av.com/phishing-domains"
    ],
    "proxy_settings": {
      "enabled": false,
      "host": "",
      "port": 8080,
      "username": "",
      "password": ""
    }
  },
  "performance": {
    "cpu_limit": 50,
    "memory_limit": 1073741824,
    "io_priority": "low",
    "nice_level": 10,
    "scan_throttling": true,
    "background_scanning": true,
    "cache_size": 268435456,
    "thread_pool_size": 4
  },
  "logging": {
    "level": "INFO",
    "file_logging": true,
    "syslog_logging": true,
    "remote_logging": false,
    "log_rotation": true,
    "max_log_size": 10485760,
    "backup_count": 5
  },
  "updates": {
    "automatic": true,
    "check_interval": 3600,
    "download_timeout": 300,
    "retry_attempts": 3,
    "update_server": "https://updates.ariel-av.com",
    "verify_signatures": true,
    "backup_before_update": true
  },
  "api": {
    "enabled": true,
    "host": "127.0.0.1",
    "port": 8080,
    "ssl_enabled": true,
    "ssl_cert": "/etc/ariel/ssl/cert.pem",
    "ssl_key": "/etc/ariel/ssl/key.pem",
    "authentication": true,
    "rate_limiting": true,
    "cors_enabled": false
  }
}
```

## Module-Specific Configurations

### PhiGuard_Core Configuration
```json
{
  "kernel_hooks": {
    "file_system": true,
    "process_creation": true,
    "network_access": true,
    "registry_access": true
  },
  "memory_scanning": {
    "enabled": true,
    "scan_interval": 60,
    "deep_scan": false,
    "rootkit_detection": true
  },
  "boot_protection": {
    "enabled": true,
    "verify_boot_files": true,
    "secure_boot_check": true
  }
}
```

### WardenMonitor Configuration
```json
{
  "process_monitoring": {
    "track_all_processes": true,
    "monitor_child_processes": true,
    "detect_process_injection": true,
    "monitor_dll_loading": true
  },
  "behavior_analysis": {
    "enabled": true,
    "learning_mode": false,
    "sensitivity": "medium",
    "whitelist_known_good": true
  },
  "network_monitoring": {
    "monitor_connections": true,
    "track_dns_requests": true,
    "detect_suspicious_traffic": true
  }
}
```

### ReHabScanner Configuration
```json
{
  "ai_engine": {
    "model_path": "/opt/ariel/models/threat_detection.bin",
    "confidence_threshold": 0.8,
    "update_models": true,
    "cloud_analysis": true
  },
  "scanning_options": {
    "max_file_size": 104857600,
    "scan_timeout": 30,
    "deep_analysis": true,
    "emulation_enabled": true
  },
  "heuristics": {
    "enabled": true,
    "sensitivity": "medium",
    "custom_rules": "/etc/ariel/heuristic_rules.json"
  }
}
```

## Environment-Specific Configurations

### Development Environment
```json
{
  "engine": {
    "realtime_protection": false,
    "update_interval": 86400
  },
  "logging": {
    "level": "DEBUG",
    "file_logging": true
  },
  "performance": {
    "cpu_limit": 25
  }
}
```

### Production Environment
```json
{
  "engine": {
    "realtime_protection": true,
    "update_interval": 1800
  },
  "logging": {
    "level": "WARNING",
    "remote_logging": true
  },
  "performance": {
    "cpu_limit": 75
  }
}
```

## Configuration Management Commands

### Linux Commands
```bash
# View current configuration
sudo ariel-config --show

# Validate configuration
sudo ariel-config --validate

# Update specific setting
sudo ariel-config --set engine.realtime_protection=true

# Reset to defaults
sudo ariel-config --reset

# Backup configuration
sudo ariel-config --backup /backup/config.json

# Restore configuration
sudo ariel-config --restore /backup/config.json

# Reload configuration
sudo ariel-config --reload
```

### Windows Commands
```cmd
# View current configuration
ariel-config.exe --show

# Update setting
ariel-config.exe --set "engine.realtime_protection=true"

# Validate configuration
ariel-config.exe --validate

# Backup configuration
ariel-config.exe --backup "C:\Backup\config.json"
```

## Configuration Validation

### Schema Validation
All configuration files are validated against JSON schemas to ensure:
- Correct data types
- Required fields present
- Valid value ranges
- Proper format compliance

### Runtime Validation
- Configuration changes are validated before application
- Invalid configurations are rejected with detailed error messages
- Fallback to previous valid configuration on errors
- Configuration change logging for audit trails

## Security Considerations

### Configuration Security
- Configuration files have restricted permissions (600/640)
- Sensitive values can be encrypted
- Environment variable substitution supported
- Configuration change auditing enabled

### Best Practices
1. **Regular Backups:** Backup configurations before changes
2. **Version Control:** Track configuration changes
3. **Testing:** Test configuration changes in development first
4. **Documentation:** Document custom configuration changes
5. **Monitoring:** Monitor configuration-related errors

## Troubleshooting Configuration Issues

### Common Problems
1. **Invalid JSON syntax**
   - Use JSON validator to check syntax
   - Check for missing commas or brackets

2. **Permission errors**
   - Verify file permissions
   - Check user/group ownership

3. **Invalid values**
   - Check value ranges and types
   - Refer to schema documentation

4. **Service restart required**
   - Some changes require service restart
   - Use `--reload` when possible

### Diagnostic Commands
```bash
# Check configuration syntax
sudo ariel-config --validate --verbose

# Test configuration changes
sudo ariel-config --test-config /path/to/new/config.json

# View configuration diff
sudo ariel-config --diff /path/to/old/config.json

# Check configuration permissions
sudo ariel-config --check-permissions
```

## Configuration Templates

### Minimal Configuration
```json
{
  "engine": {
    "realtime_protection": true,
    "quarantine_threats": true
  },
  "logging": {
    "level": "INFO"
  }
}
```

### High-Security Configuration
```json
{
  "engine": {
    "realtime_protection": true,
    "scan_on_access": true,
    "scan_on_write": true,
    "heuristic_analysis": true,
    "behavioral_analysis": true,
    "cloud_intelligence": true
  },
  "biometric": {
    "enabled": true,
    "multi_factor": {
      "required_factors": 3
    }
  },
  "quarantine": {
    "encrypt_files": true,
    "auto_submit_samples": true
  }
}
```

### Performance-Optimized Configuration
```json
{
  "engine": {
    "max_scan_threads": 8,
    "scan_timeout": 60
  },
  "performance": {
    "cpu_limit": 80,
    "memory_limit": 2147483648,
    "cache_size": 536870912,
    "background_scanning": true
  },
  "scanning": {
    "quick_scan": {
      "schedule": "hourly"
    }
  }
}
```
