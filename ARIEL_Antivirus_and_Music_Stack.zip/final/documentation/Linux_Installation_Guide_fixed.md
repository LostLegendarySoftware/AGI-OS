# ARIEL Antivirus System - Linux Installation Guide

**Version:** 1.0.0  
**Date:** 2025-07-12  
**Platform:** Linux (Ubuntu/Debian/CentOS/RHEL)

## System Requirements

### Minimum Requirements
- **Operating System:** Ubuntu 18.04+, Debian 10+, CentOS 7+, RHEL 7+
- **Processor:** x86_64 architecture (2.0 GHz)
- **Memory:** 2 GB RAM
- **Storage:** 1 GB available disk space
- **Network:** Internet connection for updates
- **Python:** Python 3.7 or higher
- **Init System:** systemd

### Recommended Requirements
- **Operating System:** Ubuntu 22.04 LTS or equivalent
- **Processor:** Multi-core x86_64 (3.0 GHz)
- **Memory:** 4 GB RAM
- **Storage:** 2 GB available disk space
- **Network:** Broadband internet connection

## Installation Steps

### Step 1: Download and Prepare
```bash
# Download the installation package
wget https://www.facebook.com/groups/creality3dscanner2/posts/1231378840618553/

# Extract the package
tar -xzf ariel-antivirus-latest.tar.gz
cd ariel-antivirus/
```

### Step 2: Run the Installer
```bash
# Make the installer executable
chmod +x rehab_rehype_installer.sh

# Run the installer with sudo
sudo ./rehab_rehype_installer.sh
```

### Step 3: Installation Process
The installer will automatically:
- Check system requirements and dependencies
- Install required Python packages
- Create system user `ariel-av`
- Set up directory structure in `/opt/ariel_antivirus`
- Configure systemd service
- Initialize security modules
- Start the antivirus daemon

### Step 4: Post-Installation Verification
```bash
# Check service status
sudo systemctl status psiguard

# View service logs
sudo journalctl -u psiguard -f

# Run initial system scan
sudo /opt/ariel_antivirus/bin/scan --quick
```

## Service Management

### Systemd Commands
```bash
# Start the service
sudo systemctl start psiguard

# Stop the service
sudo systemctl stop psiguard

# Restart the service
sudo systemctl restart psiguard

# Enable auto-start on boot
sudo systemctl enable psiguard

# Disable auto-start
sudo systemctl disable psiguard

# Check service status
sudo systemctl status psiguard
```

### Configuration Files
- **Main Config:** `/etc/ariel_antivirus/main.json`
- **Daemon Config:** `/etc/ariel_antivirus/daemon.json`
- **Logging Config:** `/etc/ariel_antivirus/logging.json`
- **Biometric Config:** `/etc/ariel_antivirus/biometric.json`

## Command Line Usage

### Basic Scanning
```bash
# Quick scan
sudo ariel-scan --quick

# Full system scan
sudo ariel-scan --full

# Scan specific directory
sudo ariel-scan --path /home/user/Downloads

# Real-time monitoring status
sudo ariel-monitor --status
```

### Configuration Management
```bash
# View current configuration
sudo ariel-config --show

# Update scan settings
sudo ariel-config --set scan.realtime=true

# Reset to defaults
sudo ariel-config --reset
```

## Troubleshooting

### Common Issues
1. **Permission denied errors**
   - Solution: Ensure running with sudo privileges

2. **Python version incompatibility**
   - Solution: Install Python 3.7+ using package manager

3. **Service fails to start**
   - Solution: Check logs with `journalctl -u psiguard`

### Log Files
- **Installation Log:** `/var/log/ariel_antivirus/install.log`
- **Service Log:** `/var/log/ariel_antivirus/service.log`
- **Scan Log:** `/var/log/ariel_antivirus/scan.log`
- **System Log:** `journalctl -u psiguard`

## Uninstallation
```bash
# Stop and disable service
sudo systemctl stop psiguard
sudo systemctl disable psiguard

# Remove installation directory
sudo rm -rf /opt/ariel_antivirus

# Remove configuration files
sudo rm -rf /etc/ariel_antivirus

# Remove logs
sudo rm -rf /var/log/ariel_antivirus

# Remove systemd service file
sudo rm /etc/systemd/system/psiguard.service
sudo systemctl daemon-reload
```

## Support
For technical support, check the system logs and refer to the troubleshooting section.
