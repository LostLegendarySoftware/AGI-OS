# ARIEL Antivirus System - Troubleshooting and FAQ

**Version:** 1.0.0  
**Date:** 2025-07-12  
**Audience:** End Users and System Administrators

## Quick Troubleshooting Guide

### Service Status Check
```bash
# Linux
sudo systemctl status psiguard
sudo journalctl -u psiguard -n 50

# Windows
sc query PsiGuardService
Get-EventLog -LogName Application -Source "ARIEL Antivirus" -Newest 10
```

### Common Issues and Solutions

## Installation Issues

### Q: Installation fails with "Permission denied" error
**A:** This typically occurs when the installer is not run with administrator privileges.

**Solution:**
- **Linux:** Run with `sudo ./rehab_rehype_installer.sh`
- **Windows:** Right-click installer and select "Run as administrator"

### Q: "Python not found" error during installation
**A:** The system doesn't have Python 3.7+ installed or it's not in the system PATH.

**Solution:**
```bash
# Linux (Ubuntu/Debian)
sudo apt update && sudo apt install python3 python3-pip

# Linux (CentOS/RHEL)
sudo yum install python3 python3-pip

# Windows
# Download and install Python from https://python.org
# Ensure "Add Python to PATH" is checked during installation
```

### Q: Installation hangs or takes very long
**A:** This can happen due to network issues or dependency conflicts.

**Solution:**
1. Check internet connectivity
2. Verify system requirements
3. Clear Python package cache:
   ```bash
   pip3 cache purge
   ```
4. Run installer with verbose output:
   ```bash
   sudo ./rehab_rehype_installer.sh --verbose
   ```

## Service Issues

### Q: Service fails to start after installation
**A:** Multiple potential causes including configuration errors, permission issues, or missing dependencies.

**Diagnostic Steps:**
```bash
# Linux
sudo systemctl status psiguard
sudo journalctl -u psiguard -f

# Windows
sc query PsiGuardService
eventvwr.msc  # Check Application logs
```

**Common Solutions:**
1. **Configuration Error:**
   ```bash
   sudo ariel-config --validate
   sudo ariel-config --reset  # If validation fails
   ```

2. **Permission Issues:**
   ```bash
   sudo chown -R ariel-av:ariel-av /opt/ariel_antivirus
   sudo chmod -R 755 /opt/ariel_antivirus
   ```

3. **Missing Dependencies:**
   ```bash
   sudo /opt/ariel_antivirus/bin/check-dependencies.sh
   ```

### Q: Service starts but stops immediately
**A:** Usually indicates a critical error in the main process.

**Solution:**
1. Check detailed logs:
   ```bash
   sudo tail -f /var/log/ariel_antivirus/service.log
   ```
2. Run in debug mode:
   ```bash
   sudo /opt/ariel_antivirus/bin/psiguard --debug --foreground
   ```
3. Check system resources:
   ```bash
   free -h
   df -h
   ```

### Q: High CPU usage by antivirus service
**A:** Can occur during intensive scans or with misconfigured settings.

**Solution:**
1. Check current scan status:
   ```bash
   sudo ariel-scan --status
   ```
2. Adjust performance settings:
   ```bash
   sudo ariel-config --set performance.cpu_limit=25
   sudo ariel-config --set performance.scan_throttling=true
   ```
3. Schedule scans during off-hours:
   ```bash
   sudo ariel-config --set scanning.full_scan.time="03:00"
   ```

## Scanning Issues

### Q: Scans are very slow
**A:** Performance can be affected by system resources, file types, or configuration.

**Optimization Steps:**
1. **Exclude unnecessary paths:**
   ```bash
   sudo ariel-config --add-exclusion /path/to/large/directory
   ```

2. **Adjust thread count:**
   ```bash
   sudo ariel-config --set engine.max_scan_threads=2  # For slower systems
   sudo ariel-config --set engine.max_scan_threads=8  # For faster systems
   ```

3. **Enable scan caching:**
   ```bash
   sudo ariel-config --set performance.cache_size=536870912  # 512MB
   ```

### Q: False positive detections
**A:** Legitimate files being flagged as threats.

**Solution:**
1. **Add to whitelist:**
   ```bash
   sudo ariel-whitelist --add-file /path/to/safe/file
   sudo ariel-whitelist --add-hash sha256:file_hash_here
   ```

2. **Exclude file types:**
   ```bash
   sudo ariel-config --add-exclusion-ext .safe_extension
   ```

3. **Report false positive:**
   ```bash
   sudo ariel-report --false-positive /path/to/file
   ```

### Q: Real-time protection not working
**A:** Files are not being scanned when accessed.

**Diagnostic Steps:**
1. **Check real-time protection status:**
   ```bash
   sudo ariel-status --realtime
   ```

2. **Verify configuration:**
   ```bash
   sudo ariel-config --get engine.realtime_protection
   sudo ariel-config --get engine.scan_on_access
   ```

3. **Test real-time protection:**
   ```bash
   # Create test file
   echo "test" > /tmp/test_file.txt
   # Check if it was scanned
   sudo grep "test_file.txt" /var/log/ariel_antivirus/scan.log
   ```

## Biometric Authentication Issues

### Q: Heart rate monitor not detected
**A:** Device connection or driver issues.

**Solution:**
1. **Check device connection:**
   ```bash
   lsusb  # Look for heart rate device
   dmesg | grep -i heart
   ```

2. **Verify configuration:**
   ```bash
   sudo ariel-config --get biometric.heart_rate_monitoring.device
   ```

3. **Test device manually:**
   ```bash
   sudo ariel-biometric --test-heartrate
   ```

### Q: Voice recognition not working
**A:** Microphone or audio system issues.

**Solution:**
1. **Check microphone:**
   ```bash
   arecord -l  # List audio devices
   arecord -d 5 test.wav  # Test recording
   ```

2. **Verify voice model:**
   ```bash
   sudo ariel-biometric --test-voice
   sudo ariel-biometric --retrain-voice
   ```

### Q: Gesture recognition fails
**A:** Camera or computer vision issues.

**Solution:**
1. **Check camera:**
   ```bash
   lsusb | grep -i camera
   v4l2-ctl --list-devices
   ```

2. **Test camera:**
   ```bash
   sudo ariel-biometric --test-camera
   ```

## Network and Update Issues

### Q: Cannot download updates
**A:** Network connectivity or proxy configuration issues.

**Solution:**
1. **Test connectivity:**
   ```bash
   curl -I https://updates.ariel-av.com
   ```

2. **Configure proxy:**
   ```bash
   sudo ariel-config --set network.proxy_settings.enabled=true
   sudo ariel-config --set network.proxy_settings.host=proxy.company.com
   sudo ariel-config --set network.proxy_settings.port=8080
   ```

3. **Manual update:**
   ```bash
   sudo ariel-update --force --verbose
   ```

### Q: Network protection blocking legitimate traffic
**A:** Overly aggressive network filtering.

**Solution:**
1. **Check blocked connections:**
   ```bash
   sudo ariel-network --show-blocked
   ```

2. **Whitelist legitimate IPs:**
   ```bash
   sudo ariel-network --whitelist-ip 192.168.1.100
   ```

3. **Adjust sensitivity:**
   ```bash
   sudo ariel-config --set network.intrusion_detection=false
   ```

## Audio and Music Production Issues

### Q: DAW performance degraded after installation
**A:** Real-time audio processing conflicts with antivirus scanning.

**Solution:**
1. **Enable audio optimization:**
   ```bash
   sudo ariel-config --set audio.latency_optimization=true
   sudo ariel-config --set audio.real_time_protection=false
   ```

2. **Exclude DAW processes:**
   ```bash
   sudo ariel-config --add-exclusion-process ardour
   sudo ariel-config --add-exclusion-process reaper
   ```

3. **Exclude audio directories:**
   ```bash
   sudo ariel-config --add-exclusion /home/user/Music/Projects
   ```

### Q: VST plugins being quarantined
**A:** Legitimate audio plugins flagged as threats.

**Solution:**
1. **Whitelist plugin directory:**
   ```bash
   sudo ariel-config --add-exclusion ~/.vst
   sudo ariel-config --add-exclusion /usr/lib/vst
   ```

2. **Disable plugin scanning:**
   ```bash
   sudo ariel-config --set audio.protect_plugins=false
   ```

## Log Analysis and Debugging

### Q: How to enable debug logging
**A:** Increase logging verbosity for troubleshooting.

**Solution:**
```bash
# Enable debug logging
sudo ariel-config --set logging.level=DEBUG

# Restart service to apply changes
sudo systemctl restart psiguard

# View debug logs
sudo tail -f /var/log/ariel_antivirus/service.log
```

### Q: Logs are too large or filling disk
**A:** Log rotation not working properly.

**Solution:**
```bash
# Check current log sizes
sudo du -sh /var/log/ariel_antivirus/

# Configure log rotation
sudo ariel-config --set logging.max_log_size=10485760  # 10MB
sudo ariel-config --set logging.backup_count=3

# Manual log rotation
sudo logrotate -f /etc/logrotate.d/ariel_antivirus
```

## Recovery Procedures

### Q: System infected despite antivirus protection
**A:** Advanced threat bypassed protection or system was infected before installation.

**Recovery Steps:**
1. **Boot from PhiGuard.iso:**
   - Create bootable USB/DVD from PhiGuard.iso
   - Boot system from rescue media
   - Run offline scan

2. **Offline scanning:**
   ```bash
   # From rescue environment
   mount /dev/sda1 /mnt/infected_system
   /antivirus/ReHabScanner/main.py --offline-scan /mnt/infected_system
   ```

3. **System restoration:**
   ```bash
   # Restore from clean backup
   /antivirus/Setup/main.py --recovery-mode --restore-backup
   ```

### Q: Configuration corrupted or lost
**A:** Configuration files damaged or accidentally deleted.

**Solution:**
```bash
# Restore from backup
sudo ariel-config --restore /backup/config.json

# Reset to defaults if no backup
sudo ariel-config --reset --confirm

# Regenerate configuration
sudo /opt/ariel_antivirus/bin/setup.py --reconfigure
```

## Performance Optimization FAQ

### Q: How to optimize for low-end systems?
**A:** Reduce resource usage for older or slower hardware.

**Configuration:**
```bash
sudo ariel-config --set performance.cpu_limit=15
sudo ariel-config --set performance.memory_limit=268435456  # 256MB
sudo ariel-config --set engine.max_scan_threads=1
sudo ariel-config --set scanning.quick_scan.schedule=daily
sudo ariel-config --set scanning.full_scan.schedule=weekly
```

### Q: How to optimize for high-performance systems?
**A:** Maximize protection and performance on powerful hardware.

**Configuration:**
```bash
sudo ariel-config --set performance.cpu_limit=80
sudo ariel-config --set performance.memory_limit=2147483648  # 2GB
sudo ariel-config --set engine.max_scan_threads=16
sudo ariel-config --set scanning.quick_scan.schedule=hourly
sudo ariel-config --set engine.cloud_intelligence=true
sudo ariel-config --set engine.behavioral_analysis=true
```

## Emergency Contacts and Support

### Self-Help Resources
1. **Log Analysis:** Check `/var/log/ariel_antivirus/` for detailed error messages
2. **Configuration Validation:** Use `ariel-config --validate` to check settings
3. **System Health:** Run `ariel-health --all` for comprehensive status
4. **Documentation:** Refer to `/opt/ariel_antivirus/docs/` for detailed guides

### Professional Support
- **Technical Support:** Create support ticket with detailed logs
- **Security Incidents:** Report immediately with system state information
- **Bug Reports:** Include configuration, logs, and reproduction steps

### Community Resources
- **User Forums:** Community-driven troubleshooting and tips
- **Knowledge Base:** Searchable database of common issues and solutions
- **Video Tutorials:** Step-by-step visual guides for common tasks

## Preventive Maintenance

### Regular Maintenance Tasks
```bash
# Weekly maintenance script
#!/bin/bash
sudo ariel-health --all
sudo ariel-update --check
sudo ariel-config --validate
sudo logrotate -f /etc/logrotate.d/ariel_antivirus
sudo ariel-cleanup --temp-files
```

### Monitoring Recommendations
1. **Set up log monitoring:** Alert on critical errors
2. **Monitor resource usage:** Track CPU and memory consumption
3. **Check update status:** Ensure signatures are current
4. **Verify backup integrity:** Test configuration backups regularly

This troubleshooting guide covers the most common issues encountered with the ARIEL Antivirus System. For issues not covered here, consult the detailed logs and contact technical support with specific error messages and system information.
