# ARIEL Antivirus System - Windows Installation Guide

**Version:** 1.0.0  
**Date:** 2025-07-12  
**Platform:** Windows 10/11

## System Requirements

### Minimum Requirements
- **Operating System:** Windows 10 (64-bit) or Windows 11
- **Processor:** Intel Core i3 or AMD equivalent (2.0 GHz)
- **Memory:** 4 GB RAM
- **Storage:** 2 GB available disk space
- **Network:** Internet connection for updates
- **Python:** Python 3.7 or higher

### Recommended Requirements
- **Operating System:** Windows 11 (64-bit)
- **Processor:** Intel Core i5 or AMD equivalent (3.0 GHz)
- **Memory:** 8 GB RAM
- **Storage:** 4 GB available disk space
- **Network:** Broadband internet connection

## Installation Steps

### Step 1: Download and Prepare
1. Download the ARIEL Antivirus installation package
2. Extract all files to a temporary directory
3. Ensure you have administrator privileges

### Step 2: Run the Installer
1. Right-click on `rehab_rehype_installer.bat`
2. Select "Run as administrator"
3. Follow the installation prompts

### Step 3: Installation Process
The installer will automatically:
- Check system requirements
- Install Python dependencies
- Create system directories
- Configure Windows services
- Set up real-time protection
- Initialize biometric security modules

### Step 4: Post-Installation
1. The PsiGuardService will start automatically
2. Configure initial settings through the system tray
3. Run initial system scan
4. Set up biometric authentication (optional)

## Service Management

### Starting/Stopping the Service
```cmd
# Start the service
net start PsiGuardService

# Stop the service
net stop PsiGuardService

# Check service status
sc query PsiGuardService
```

### Configuration Files
- **Main Config:** `C:\Program Files\ARIEL_Antivirus\config\main.json`
- **Biometric Config:** `C:\Program Files\ARIEL_Antivirus\config\biometric.json`
- **Audio Config:** `C:\Program Files\ARIEL_Antivirus\config\audio.json`

## Troubleshooting

### Common Issues
1. **Installation fails with permission error**
   - Solution: Run installer as administrator

2. **Python not found error**
   - Solution: Install Python 3.7+ from python.org

3. **Service fails to start**
   - Solution: Check Windows Event Viewer for detailed errors

### Log Files
- **Installation Log:** `%TEMP%\ariel_install.log`
- **Service Log:** `C:\Program Files\ARIEL_Antivirus\logs\service.log`
- **Scan Log:** `C:\Program Files\ARIEL_Antivirus\logs\scan.log`

## Uninstallation
1. Stop the PsiGuardService
2. Run the uninstaller from Control Panel
3. Remove remaining configuration files if needed

## Support
For technical support, refer to the troubleshooting section or contact system administrator.
