#!/usr/bin/env python3
"""
BiometricCore - Central Biometric Security Coordinator
Integrates heart rate monitoring, voice approval, and gesture recognition
for comprehensive biometric security in the ARIEL antivirus system.
"""

import os
import sys
import json
import logging
import threading
import time
import asyncio
from typing import Dict, List, Any, Optional, Callable, Tuple
from datetime import datetime, timedelta
from collections import deque
import numpy as np

class BiometricCore:
    """Central coordinator for all biometric security features"""

    def __init__(self, config_path: str = "biometric_config.json"):
        self.config = self._load_config(config_path)
        self.heart_rate_monitor = None
        self.voice_approval = None
        self.gesture_recognition = None

        # Biometric state tracking
        self.current_stress_level = 0.0
        self.authentication_status = {
            'voice': False,
            'gesture': False,
            'heart_rate': 'normal'
        }

        # Security response callbacks
        self.security_callbacks = []
        self.stress_threshold = self.config.get('stress_threshold', 0.7)
        self.panic_threshold = self.config.get('panic_threshold', 0.9)

        # Monitoring threads
        self.monitoring_active = False
        self.monitor_thread = None

        # Integration with existing modules
        self.integration_manager = None

        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger('BiometricCore')

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load biometric configuration"""
        default_config = {
            "heart_rate_monitoring": {
                "enabled": True,
                "sampling_rate": 1.0,  # Hz
                "stress_detection": True,
                "hrv_analysis": True
            },
            "voice_approval": {
                "enabled": True,
                "confidence_threshold": 0.85,
                "timeout_seconds": 30,
                "required_phrases": ["approve security action", "confirm installation"]
            },
            "gesture_recognition": {
                "enabled": True,
                "confidence_threshold": 0.80,
                "timeout_seconds": 15,
                "approved_gestures": ["thumbs_up", "open_palm", "peace_sign"]
            },
            "stress_threshold": 0.7,
            "panic_threshold": 0.9,
            "integration": {
                "auto_lock_on_panic": True,
                "require_biometric_for_critical": True,
                "log_biometric_events": True
            }
        }

        try:
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    user_config = json.load(f)
                    default_config.update(user_config)
        except Exception as e:
            self.logger.warning(f"Could not load config: {e}, using defaults")

        return default_config

    def initialize(self) -> bool:
        """Initialize all biometric security components"""
        try:
            self.logger.info("Initializing BiometricCore...")

            # Initialize heart rate monitoring
            if self.config['heart_rate_monitoring']['enabled']:
                self._initialize_heart_rate_monitor()

            # Initialize voice approval system
            if self.config['voice_approval']['enabled']:
                self._initialize_voice_approval()

            # Initialize gesture recognition
            if self.config['gesture_recognition']['enabled']:
                self._initialize_gesture_recognition()

            # Start monitoring thread
            self._start_monitoring()

            self.logger.info("BiometricCore initialized successfully")
            return True

        except Exception as e:
            self.logger.error(f"Failed to initialize BiometricCore: {e}")
            return False

    def _initialize_heart_rate_monitor(self):
        """Initialize heart rate monitoring with HRV-based stress detection"""
        self.logger.info("Initializing heart rate monitoring...")

        # Import heart rate monitor (will be implemented next)
        try:
            from HeartRateMonitor.main import HeartRateMonitor
            self.heart_rate_monitor = HeartRateMonitor(self.config['heart_rate_monitoring'])
            self.heart_rate_monitor.set_stress_callback(self._handle_stress_detection)
        except ImportError:
            self.logger.warning("HeartRateMonitor module not available")

    def _initialize_voice_approval(self):
        """Initialize voice recognition for security approvals"""
        self.logger.info("Initializing voice approval system...")

        try:
            from VoiceApproval.main import VoiceApproval
            self.voice_approval = VoiceApproval(self.config['voice_approval'])
        except ImportError:
            self.logger.warning("VoiceApproval module not available")

    def _initialize_gesture_recognition(self):
        """Initialize gesture recognition for authentication"""
        self.logger.info("Initializing gesture recognition...")

        try:
            from GestureRecognition.main import GestureRecognition
            self.gesture_recognition = GestureRecognition(self.config['gesture_recognition'])
        except ImportError:
            self.logger.warning("GestureRecognition module not available")

    def _start_monitoring(self):
        """Start continuous biometric monitoring"""
        self.monitoring_active = True
        self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitor_thread.start()
        self.logger.info("Biometric monitoring started")

    def _monitoring_loop(self):
        """Main monitoring loop for biometric data"""
        while self.monitoring_active:
            try:
                # Update biometric status
                self._update_biometric_status()

                # Check for security triggers
                self._check_security_triggers()

                # Sleep based on sampling rate
                time.sleep(1.0 / self.config['heart_rate_monitoring']['sampling_rate'])

            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(1.0)

    def _update_biometric_status(self):
        """Update current biometric authentication status"""
        if self.heart_rate_monitor:
            hr_data = self.heart_rate_monitor.get_current_data()
            if hr_data:
                self.current_stress_level = hr_data.get('stress_level', 0.0)
                self.authentication_status['heart_rate'] = hr_data.get('status', 'normal')

    def _check_security_triggers(self):
        """Check for biometric-triggered security responses"""
        # Panic detection based on stress level
        if self.current_stress_level >= self.panic_threshold:
            self._trigger_panic_response()
        elif self.current_stress_level >= self.stress_threshold:
            self._trigger_stress_response()

    def _handle_stress_detection(self, stress_data: Dict[str, Any]):
        """Handle stress detection from heart rate monitor"""
        self.current_stress_level = stress_data.get('level', 0.0)

        if stress_data.get('panic_detected', False):
            self._trigger_panic_response()
        elif stress_data.get('stress_detected', False):
            self._trigger_stress_response()

    def _trigger_panic_response(self):
        """Trigger security response for panic situation"""
        self.logger.warning("PANIC DETECTED - Triggering security lockdown")

        if self.config['integration']['auto_lock_on_panic']:
            self._notify_integration_manager('panic_lockdown', {
                'stress_level': self.current_stress_level,
                'timestamp': datetime.now().isoformat(),
                'action': 'system_lockdown'
            })

    def _trigger_stress_response(self):
        """Trigger security response for elevated stress"""
        self.logger.info("Elevated stress detected - Increasing security monitoring")

        self._notify_integration_manager('stress_detected', {
            'stress_level': self.current_stress_level,
            'timestamp': datetime.now().isoformat(),
            'action': 'enhanced_monitoring'
        })

    def _notify_integration_manager(self, event_type: str, data: Dict[str, Any]):
        """Notify the integration manager of biometric events"""
        if self.integration_manager:
            try:
                self.integration_manager.handle_biometric_event(event_type, data)
            except Exception as e:
                self.logger.error(f"Failed to notify integration manager: {e}")

    def request_voice_approval(self, action_description: str, timeout: int = 30) -> bool:
        """Request voice approval for a critical action"""
        if not self.voice_approval:
            self.logger.warning("Voice approval not available")
            return False

        self.logger.info(f"Requesting voice approval for: {action_description}")
        return self.voice_approval.request_approval(action_description, timeout)

    def request_gesture_approval(self, action_description: str, timeout: int = 15) -> bool:
        """Request gesture approval for authentication"""
        if not self.gesture_recognition:
            self.logger.warning("Gesture recognition not available")
            return False

        self.logger.info(f"Requesting gesture approval for: {action_description}")
        return self.gesture_recognition.request_approval(action_description, timeout)

    def get_biometric_status(self) -> Dict[str, Any]:
        """Get current biometric authentication status"""
        return {
            'stress_level': self.current_stress_level,
            'authentication_status': self.authentication_status.copy(),
            'monitoring_active': self.monitoring_active,
            'timestamp': datetime.now().isoformat()
        }

    def register_security_callback(self, callback: Callable):
        """Register callback for security events"""
        self.security_callbacks.append(callback)

    def set_integration_manager(self, integration_manager):
        """Set reference to integration manager for coordination"""
        self.integration_manager = integration_manager
        self.logger.info("Integration manager reference set")

    def shutdown(self):
        """Shutdown biometric monitoring"""
        self.monitoring_active = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5.0)

        if self.heart_rate_monitor:
            self.heart_rate_monitor.shutdown()
        if self.voice_approval:
            self.voice_approval.shutdown()
        if self.gesture_recognition:
            self.gesture_recognition.shutdown()

        self.logger.info("BiometricCore shutdown complete")

# Main execution for testing
if __name__ == "__main__":
    biometric_core = BiometricCore()
    if biometric_core.initialize():
        print("BiometricCore initialized successfully")

        # Test biometric status
        status = biometric_core.get_biometric_status()
        print(f"Biometric Status: {json.dumps(status, indent=2)}")

        # Keep running for demonstration
        try:
            time.sleep(10)
        except KeyboardInterrupt:
            pass
        finally:
            biometric_core.shutdown()
    else:
        print("Failed to initialize BiometricCore")
