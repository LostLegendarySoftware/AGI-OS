#!/usr/bin/env python3
"""
GestureRecognition - Keypoint-Based Gesture Authentication
Implements gesture recognition for security authentication using keypoint models.
Based on research: Multi-modal biometric systems with keypoint-based gesture identification.
"""

import os
import sys
import json
import logging
import threading
import time
import cv2
import numpy as np
from typing import Dict, List, Any, Optional, Callable, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
import mediapipe as mp
from collections import deque

@dataclass
class GestureTemplate:
    """Gesture template for recognition"""
    gesture_name: str
    keypoints: List[List[float]]  # Normalized keypoint coordinates
    confidence_threshold: float
    created_date: datetime

@dataclass
class GestureRecognitionResult:
    """Result of gesture recognition"""
    gesture_name: str
    confidence: float
    keypoints: List[List[float]]
    timestamp: datetime
    recognized: bool

class HandKeypointExtractor:
    """Extract hand keypoints using MediaPipe"""

    def __init__(self):
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.5
        )
        self.mp_drawing = mp.solutions.drawing_utils
        self.logger = logging.getLogger('HandKeypointExtractor')

    def extract_keypoints(self, image: np.ndarray) -> List[List[float]]:
        """Extract hand keypoints from image"""
        try:
            # Convert BGR to RGB
            rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

            # Process the image
            results = self.hands.process(rgb_image)

            keypoints = []

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    hand_keypoints = []
                    for landmark in hand_landmarks.landmark:
                        # Normalize coordinates
                        hand_keypoints.extend([landmark.x, landmark.y, landmark.z])
                    keypoints.append(hand_keypoints)

            return keypoints

        except Exception as e:
            self.logger.error(f"Keypoint extraction failed: {e}")
            return []

    def draw_keypoints(self, image: np.ndarray, keypoints: List[List[float]]) -> np.ndarray:
        """Draw keypoints on image for visualization"""
        try:
            # This would draw the keypoints for debugging
            annotated_image = image.copy()

            # Convert BGR to RGB for processing
            rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            results = self.hands.process(rgb_image)

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    self.mp_drawing.draw_landmarks(
                        annotated_image, hand_landmarks, self.mp_hands.HAND_CONNECTIONS)

            return annotated_image

        except Exception as e:
            self.logger.error(f"Drawing keypoints failed: {e}")
            return image

class GestureClassifier:
    """Classify gestures based on keypoint patterns"""

    def __init__(self):
        self.gesture_templates = {}
        self.logger = logging.getLogger('GestureClassifier')

        # Initialize with common security gestures
        self._initialize_default_gestures()

    def _initialize_default_gestures(self):
        """Initialize default gesture templates"""
        # These are simplified gesture patterns based on hand keypoint analysis
        # In production, these would be trained from real gesture data

        default_gestures = {
            'thumbs_up': {
                'description': 'Thumb extended upward, other fingers closed',
                'keypoint_pattern': 'thumb_up_pattern',
                'confidence_threshold': 0.8
            },
            'open_palm': {
                'description': 'All fingers extended, palm facing camera',
                'keypoint_pattern': 'open_palm_pattern', 
                'confidence_threshold': 0.75
            },
            'peace_sign': {
                'description': 'Index and middle finger extended in V shape',
                'keypoint_pattern': 'peace_sign_pattern',
                'confidence_threshold': 0.8
            },
            'ok_sign': {
                'description': 'Thumb and index finger forming circle',
                'keypoint_pattern': 'ok_sign_pattern',
                'confidence_threshold': 0.8
            },
            'fist': {
                'description': 'All fingers closed into fist',
                'keypoint_pattern': 'fist_pattern',
                'confidence_threshold': 0.75
            }
        }

        self.logger.info(f"Initialized {len(default_gestures)} default gesture templates")

    def _analyze_finger_states(self, keypoints: List[float]) -> Dict[str, bool]:
        """Analyze finger extension states from keypoints"""
        if len(keypoints) < 63:  # 21 landmarks * 3 coordinates
            return {}

        # MediaPipe hand landmark indices
        # Thumb: 1-4, Index: 5-8, Middle: 9-12, Ring: 13-16, Pinky: 17-20
        finger_states = {}

        try:
            # Thumb (compare tip with MCP joint)
            thumb_tip_y = keypoints[4*3 + 1]  # Landmark 4, Y coordinate
            thumb_mcp_y = keypoints[2*3 + 1]  # Landmark 2, Y coordinate
            finger_states['thumb'] = thumb_tip_y < thumb_mcp_y  # Extended if tip is above MCP

            # Index finger
            index_tip_y = keypoints[8*3 + 1]
            index_pip_y = keypoints[6*3 + 1]
            finger_states['index'] = index_tip_y < index_pip_y

            # Middle finger
            middle_tip_y = keypoints[12*3 + 1]
            middle_pip_y = keypoints[10*3 + 1]
            finger_states['middle'] = middle_tip_y < middle_pip_y

            # Ring finger
            ring_tip_y = keypoints[16*3 + 1]
            ring_pip_y = keypoints[14*3 + 1]
            finger_states['ring'] = ring_tip_y < ring_pip_y

            # Pinky
            pinky_tip_y = keypoints[20*3 + 1]
            pinky_pip_y = keypoints[18*3 + 1]
            finger_states['pinky'] = pinky_tip_y < pinky_pip_y

        except Exception as e:
            self.logger.error(f"Finger state analysis failed: {e}")

        return finger_states

    def classify_gesture(self, keypoints: List[List[float]]) -> GestureRecognitionResult:
        """Classify gesture from keypoints"""
        if not keypoints or len(keypoints) == 0:
            return GestureRecognitionResult(
                gesture_name="none",
                confidence=0.0,
                keypoints=[],
                timestamp=datetime.now(),
                recognized=False
            )

        # Use first hand for classification
        hand_keypoints = keypoints[0]
        finger_states = self._analyze_finger_states(hand_keypoints)

        # Classify based on finger states
        gesture_name, confidence = self._match_gesture_pattern(finger_states)

        return GestureRecognitionResult(
            gesture_name=gesture_name,
            confidence=confidence,
            keypoints=keypoints,
            timestamp=datetime.now(),
            recognized=confidence >= 0.7
        )

    def _match_gesture_pattern(self, finger_states: Dict[str, bool]) -> Tuple[str, float]:
        """Match finger states to gesture patterns"""
        if not finger_states:
            return "none", 0.0

        # Thumbs up: thumb extended, others closed
        if (finger_states.get('thumb', False) and 
            not finger_states.get('index', True) and
            not finger_states.get('middle', True) and
            not finger_states.get('ring', True) and
            not finger_states.get('pinky', True)):
            return "thumbs_up", 0.9

        # Open palm: all fingers extended
        if (finger_states.get('thumb', False) and
            finger_states.get('index', False) and
            finger_states.get('middle', False) and
            finger_states.get('ring', False) and
            finger_states.get('pinky', False)):
            return "open_palm", 0.85

        # Peace sign: index and middle extended
        if (not finger_states.get('thumb', True) and
            finger_states.get('index', False) and
            finger_states.get('middle', False) and
            not finger_states.get('ring', True) and
            not finger_states.get('pinky', True)):
            return "peace_sign", 0.85

        # OK sign: thumb and index forming circle (simplified detection)
        if (finger_states.get('thumb', False) and
            finger_states.get('index', False) and
            not finger_states.get('middle', True) and
            not finger_states.get('ring', True) and
            not finger_states.get('pinky', True)):
            return "ok_sign", 0.8

        # Fist: all fingers closed
        if (not finger_states.get('thumb', True) and
            not finger_states.get('index', True) and
            not finger_states.get('middle', True) and
            not finger_states.get('ring', True) and
            not finger_states.get('pinky', True)):
            return "fist", 0.8

        return "unknown", 0.3

class CameraManager:
    """Manage camera for gesture capture"""

    def __init__(self, camera_index: int = 0):
        self.camera_index = camera_index
        self.cap = None
        self.is_active = False
        self.logger = logging.getLogger('CameraManager')

    def initialize_camera(self) -> bool:
        """Initialize camera"""
        try:
            self.cap = cv2.VideoCapture(self.camera_index)
            if not self.cap.isOpened():
                self.logger.error("Failed to open camera")
                return False

            # Set camera properties
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.cap.set(cv2.CAP_PROP_FPS, 30)

            self.is_active = True
            self.logger.info("Camera initialized successfully")
            return True

        except Exception as e:
            self.logger.error(f"Camera initialization failed: {e}")
            return False

    def capture_frame(self) -> Optional[np.ndarray]:
        """Capture a single frame"""
        if not self.is_active or not self.cap:
            return None

        try:
            ret, frame = self.cap.read()
            if ret:
                return frame
            else:
                self.logger.warning("Failed to capture frame")
                return None

        except Exception as e:
            self.logger.error(f"Frame capture failed: {e}")
            return None

    def release_camera(self):
        """Release camera resources"""
        if self.cap:
            self.cap.release()
            self.is_active = False
            self.logger.info("Camera released")

class GestureRecognition:
    """Main gesture recognition system"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.keypoint_extractor = HandKeypointExtractor()
        self.gesture_classifier = GestureClassifier()
        self.camera_manager = CameraManager(config.get('camera_index', 0))

        # Recognition state
        self.is_monitoring = False
        self.monitor_thread = None
        self.gesture_history = deque(maxlen=50)

        # Approval system
        self.active_approval_requests = {}
        self.request_counter = 0

        # Setup logging
        self.logger = logging.getLogger('GestureRecognition')

    def initialize(self) -> bool:
        """Initialize gesture recognition system"""
        try:
            if not self.camera_manager.initialize_camera():
                self.logger.error("Failed to initialize camera")
                return False

            self.logger.info("Gesture recognition system initialized")
            return True

        except Exception as e:
            self.logger.error(f"Initialization failed: {e}")
            return False

    def start_monitoring(self) -> bool:
        """Start continuous gesture monitoring"""
        if self.is_monitoring:
            return True

        try:
            self.is_monitoring = True
            self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
            self.monitor_thread.start()
            self.logger.info("Gesture monitoring started")
            return True

        except Exception as e:
            self.logger.error(f"Failed to start monitoring: {e}")
            return False

    def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.is_monitoring:
            try:
                # Capture frame
                frame = self.camera_manager.capture_frame()
                if frame is None:
                    time.sleep(0.1)
                    continue

                # Extract keypoints
                keypoints = self.keypoint_extractor.extract_keypoints(frame)

                if keypoints:
                    # Classify gesture
                    result = self.gesture_classifier.classify_gesture(keypoints)

                    # Store in history
                    self.gesture_history.append(result)

                    # Check for approval requests
                    self._check_approval_requests(result)

                # Control frame rate
                time.sleep(1.0 / self.config.get('fps', 10))

            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(0.1)

    def request_approval(self, action_description: str, timeout: int = 15) -> bool:
        """Request gesture approval for authentication"""
        request_id = f"gesture_req_{self.request_counter}"
        self.request_counter += 1

        approved_gestures = self.config.get('approved_gestures', ['thumbs_up', 'open_palm'])

        self.logger.info(f"Gesture approval requested for: {action_description}")

        # Start monitoring if not already active
        if not self.is_monitoring:
            if not self.start_monitoring():
                return False

        # Create approval request
        approval_request = {
            'request_id': request_id,
            'action_description': action_description,
            'approved_gestures': approved_gestures,
            'timeout': timeout,
            'start_time': datetime.now(),
            'status': 'pending'
        }

        self.active_approval_requests[request_id] = approval_request

        # Wait for approval or timeout
        return self._wait_for_approval(request_id, timeout)

    def _wait_for_approval(self, request_id: str, timeout: int) -> bool:
        """Wait for gesture approval"""
        start_time = time.time()

        print(f"\nGESTURE APPROVAL REQUIRED")
        print(f"Action: {self.active_approval_requests[request_id]['action_description']}")
        print("Please perform one of these gestures:")
        for gesture in self.active_approval_requests[request_id]['approved_gestures']:
            print(f"  - {gesture}")
        print(f"Timeout: {timeout} seconds")
        print("Monitoring for gestures...")

        while time.time() - start_time < timeout:
            if request_id in self.active_approval_requests:
                request = self.active_approval_requests[request_id]
                if request['status'] == 'approved':
                    self.logger.info("Gesture approval granted")
                    return True
                elif request['status'] == 'denied':
                    self.logger.warning("Gesture approval denied")
                    return False

            time.sleep(0.1)

        # Timeout
        if request_id in self.active_approval_requests:
            self.active_approval_requests[request_id]['status'] = 'timeout'
            del self.active_approval_requests[request_id]

        self.logger.warning("Gesture approval timeout")
        return False

    def _check_approval_requests(self, gesture_result: GestureRecognitionResult):
        """Check if gesture matches any pending approval requests"""
        if not gesture_result.recognized:
            return

        for request_id, request in list(self.active_approval_requests.items()):
            if request['status'] != 'pending':
                continue

            # Check if gesture is approved for this request
            if gesture_result.gesture_name in request['approved_gestures']:
                confidence_threshold = self.config.get('confidence_threshold', 0.8)

                if gesture_result.confidence >= confidence_threshold:
                    request['status'] = 'approved'
                    self.logger.info(f"Gesture '{gesture_result.gesture_name}' approved request {request_id}")
                    print(f"✓ Gesture '{gesture_result.gesture_name}' recognized - APPROVED")

                    # Clean up request after short delay
                    threading.Timer(1.0, lambda: self.active_approval_requests.pop(request_id, None)).start()
                    break

    def get_recent_gestures(self, seconds: int = 10) -> List[Dict[str, Any]]:
        """Get recent gesture recognition results"""
        cutoff_time = datetime.now() - timedelta(seconds=seconds)
        recent_gestures = []

        for result in self.gesture_history:
            if result.timestamp >= cutoff_time:
                recent_gestures.append({
                    'gesture_name': result.gesture_name,
                    'confidence': result.confidence,
                    'timestamp': result.timestamp.isoformat(),
                    'recognized': result.recognized
                })

        return recent_gestures

    def capture_gesture_sample(self, gesture_name: str, duration: float = 3.0) -> bool:
        """Capture a gesture sample for training"""
        self.logger.info(f"Capturing gesture sample for: {gesture_name}")

        if not self.camera_manager.is_active:
            if not self.camera_manager.initialize_camera():
                return False

        print(f"Prepare to perform gesture: {gesture_name}")
        print(f"Capture will start in 3 seconds...")

        for i in range(3, 0, -1):
            print(f"{i}...")
            time.sleep(1)

        print("Performing gesture now!")

        start_time = time.time()
        samples = []

        while time.time() - start_time < duration:
            frame = self.camera_manager.capture_frame()
            if frame is not None:
                keypoints = self.keypoint_extractor.extract_keypoints(frame)
                if keypoints:
                    samples.append(keypoints)

            time.sleep(0.1)

        if samples:
            self.logger.info(f"Captured {len(samples)} samples for gesture: {gesture_name}")
            return True
        else:
            self.logger.warning(f"No samples captured for gesture: {gesture_name}")
            return False

    def shutdown(self):
        """Shutdown gesture recognition system"""
        self.is_monitoring = False

        if self.monitor_thread:
            self.monitor_thread.join(timeout=5.0)

        self.camera_manager.release_camera()
        self.logger.info("Gesture recognition system shutdown")

# Main execution for testing
if __name__ == "__main__":
    # Test configuration
    test_config = {
        "confidence_threshold": 0.8,
        "timeout_seconds": 15,
        "approved_gestures": ["thumbs_up", "open_palm", "peace_sign"],
        "camera_index": 0,
        "fps": 10
    }

    # Initialize gesture recognition
    gesture_recognition = GestureRecognition(test_config)

    if gesture_recognition.initialize():
        print("Gesture Recognition System Test")
        print("1. Start monitoring")
        print("2. Test approval request")
        print("3. Capture gesture sample")

        choice = input("Enter choice (1, 2, or 3): ")

        if choice == "1":
            gesture_recognition.start_monitoring()
            print("Monitoring started. Press Ctrl+C to stop.")
            try:
                while True:
                    time.sleep(1)
                    recent = gesture_recognition.get_recent_gestures(5)
                    if recent:
                        latest = recent[-1]
                        if latest['recognized']:
                            print(f"Recognized: {latest['gesture_name']} (confidence: {latest['confidence']:.2f})")
            except KeyboardInterrupt:
                pass

        elif choice == "2":
            action = input("Enter action description: ")
            approved = gesture_recognition.request_approval(action)
            print(f"Approval {'granted' if approved else 'denied'}")

        elif choice == "3":
            gesture_name = input("Enter gesture name: ")
            success = gesture_recognition.capture_gesture_sample(gesture_name)
            print(f"Capture {'successful' if success else 'failed'}")

        gesture_recognition.shutdown()
    else:
        print("Failed to initialize gesture recognition system")
