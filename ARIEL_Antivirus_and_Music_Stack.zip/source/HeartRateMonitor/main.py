#!/usr/bin/env python3
"""
HeartRateMonitor - Heart Rate Variability Based Stress Detection
Implements real HRV algorithms for stress and panic detection in security contexts.
Based on research: HRV-RMSSD algorithm and Fitbit API integration.
"""

import os
import sys
import json
import logging
import threading
import time
import asyncio
from typing import Dict, List, Any, Optional, Callable, Tuple
from datetime import datetime, timedelta
from collections import deque
import numpy as np
import requests
from dataclasses import dataclass

@dataclass
class HeartRateData:
    """Heart rate data structure"""
    timestamp: datetime
    heart_rate: int
    rr_intervals: List[float]  # R-R intervals for HRV analysis
    stress_level: float
    hrv_rmssd: float
    status: str

class HRVAnalyzer:
    """Heart Rate Variability analyzer for stress detection"""

    def __init__(self):
        self.logger = logging.getLogger('HRVAnalyzer')

    def calculate_rmssd(self, rr_intervals: List[float]) -> float:
        """
        Calculate RMSSD (Root Mean Square of Successive Differences)
        Research-based HRV metric for stress detection
        """
        if len(rr_intervals) < 2:
            return 0.0

        # Calculate successive differences
        successive_diffs = []
        for i in range(1, len(rr_intervals)):
            diff = rr_intervals[i] - rr_intervals[i-1]
            successive_diffs.append(diff * diff)

        # Calculate RMSSD
        if successive_diffs:
            rmssd = np.sqrt(np.mean(successive_diffs))
            return rmssd
        return 0.0

    def calculate_stress_level(self, rmssd: float, heart_rate: int) -> Tuple[float, str]:
        """
        Calculate stress level based on HRV-RMSSD and heart rate
        Based on research: Lower RMSSD + Higher HR = Higher Stress
        """
        # Normalize RMSSD (typical range: 10-100ms)
        normalized_rmssd = max(0, min(1, (100 - rmssd) / 90))

        # Normalize heart rate (typical range: 60-180 bpm)
        normalized_hr = max(0, min(1, (heart_rate - 60) / 120))

        # Combined stress score (weighted combination)
        stress_level = (0.6 * normalized_rmssd + 0.4 * normalized_hr)

        # Determine status
        if stress_level >= 0.9:
            status = "panic"
        elif stress_level >= 0.7:
            status = "high_stress"
        elif stress_level >= 0.4:
            status = "moderate_stress"
        else:
            status = "normal"

        return stress_level, status

class FitbitAPIConnector:
    """Fitbit API connector for real heart rate data"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.access_token = config.get('access_token')
        self.client_id = config.get('client_id')
        self.base_url = "https://api.fitbit.com/1/user/-"
        self.logger = logging.getLogger('FitbitAPI')

    def get_heart_rate_data(self, date: str = "today") -> Optional[Dict[str, Any]]:
        """Get heart rate data from Fitbit API"""
        if not self.access_token:
            self.logger.warning("No Fitbit access token configured")
            return None

        try:
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'User-Agent': 'ARIEL-Biometric-Security/1.0'
            }

            # Get heart rate time series
            url = f"{self.base_url}/activities/heart/date/{date}/1d/1min.json"
            response = requests.get(url, headers=headers, timeout=10)

            if response.status_code == 200:
                return response.json()
            else:
                self.logger.error(f"Fitbit API error: {response.status_code}")
                return None

        except Exception as e:
            self.logger.error(f"Failed to get Fitbit data: {e}")
            return None

    def get_hrv_data(self, date: str = "today") -> Optional[Dict[str, Any]]:
        """Get HRV data from Fitbit API"""
        if not self.access_token:
            return None

        try:
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'User-Agent': 'ARIEL-Biometric-Security/1.0'
            }

            # Get HRV data
            url = f"{self.base_url}/hrv/date/{date}.json"
            response = requests.get(url, headers=headers, timeout=10)

            if response.status_code == 200:
                return response.json()
            else:
                self.logger.warning(f"HRV data not available: {response.status_code}")
                return None

        except Exception as e:
            self.logger.error(f"Failed to get HRV data: {e}")
            return None

class SimulatedHeartRateSource:
    """Simulated heart rate source for testing when Fitbit API is not available"""

    def __init__(self):
        self.base_hr = 70
        self.stress_multiplier = 1.0
        self.logger = logging.getLogger('SimulatedHR')

    def get_current_heart_rate(self) -> Tuple[int, List[float]]:
        """Generate simulated heart rate and RR intervals"""
        # Simulate heart rate with some variation
        variation = np.random.normal(0, 5)
        current_hr = int(self.base_hr * self.stress_multiplier + variation)
        current_hr = max(50, min(180, current_hr))

        # Generate simulated RR intervals
        avg_rr = 60000 / current_hr  # milliseconds
        rr_intervals = []
        for _ in range(10):  # Last 10 intervals
            rr_variation = np.random.normal(0, avg_rr * 0.1)
            rr_interval = avg_rr + rr_variation
            rr_intervals.append(max(300, min(1500, rr_interval)))

        return current_hr, rr_intervals

    def simulate_stress(self, level: float):
        """Simulate stress for testing"""
        self.stress_multiplier = 1.0 + (level * 0.5)

class HeartRateMonitor:
    """Main heart rate monitoring class with stress detection"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.hrv_analyzer = HRVAnalyzer()
        self.fitbit_connector = None
        self.simulated_source = None

        # Data storage
        self.heart_rate_history = deque(maxlen=100)
        self.current_data = None

        # Monitoring state
        self.monitoring_active = False
        self.monitor_thread = None

        # Callbacks
        self.stress_callback = None

        # Setup logging
        self.logger = logging.getLogger('HeartRateMonitor')

        # Initialize data source
        self._initialize_data_source()

    def _initialize_data_source(self):
        """Initialize heart rate data source"""
        if self.config.get('device_type') == 'fitbit_api':
            fitbit_config = self.config.get('fitbit_config', {})
            if fitbit_config.get('access_token'):
                self.fitbit_connector = FitbitAPIConnector(fitbit_config)
                self.logger.info("Fitbit API connector initialized")
            else:
                self.logger.warning("Fitbit API not configured, using simulation")
                self.simulated_source = SimulatedHeartRateSource()
        else:
            self.simulated_source = SimulatedHeartRateSource()
            self.logger.info("Using simulated heart rate source")

    def start_monitoring(self) -> bool:
        """Start heart rate monitoring"""
        try:
            self.monitoring_active = True
            self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
            self.monitor_thread.start()
            self.logger.info("Heart rate monitoring started")
            return True
        except Exception as e:
            self.logger.error(f"Failed to start monitoring: {e}")
            return False

    def _monitoring_loop(self):
        """Main monitoring loop"""
        while self.monitoring_active:
            try:
                # Get heart rate data
                heart_rate, rr_intervals = self._get_heart_rate_data()

                if heart_rate and rr_intervals:
                    # Analyze HRV
                    rmssd = self.hrv_analyzer.calculate_rmssd(rr_intervals)
                    stress_level, status = self.hrv_analyzer.calculate_stress_level(rmssd, heart_rate)

                    # Create data record
                    hr_data = HeartRateData(
                        timestamp=datetime.now(),
                        heart_rate=heart_rate,
                        rr_intervals=rr_intervals,
                        stress_level=stress_level,
                        hrv_rmssd=rmssd,
                        status=status
                    )

                    # Store data
                    self.heart_rate_history.append(hr_data)
                    self.current_data = hr_data

                    # Check for stress/panic
                    self._check_stress_levels(hr_data)

                # Sleep based on sampling rate
                sleep_time = 1.0 / self.config.get('sampling_rate', 1.0)
                time.sleep(sleep_time)

            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(1.0)

    def _get_heart_rate_data(self) -> Tuple[Optional[int], Optional[List[float]]]:
        """Get heart rate data from configured source"""
        if self.fitbit_connector:
            # Try to get real Fitbit data
            fitbit_data = self.fitbit_connector.get_heart_rate_data()
            if fitbit_data:
                return self._parse_fitbit_data(fitbit_data)

        # Fall back to simulated data
        if self.simulated_source:
            return self.simulated_source.get_current_heart_rate()

        return None, None

    def _parse_fitbit_data(self, fitbit_data: Dict[str, Any]) -> Tuple[Optional[int], Optional[List[float]]]:
        """Parse Fitbit API response"""
        try:
            activities_heart = fitbit_data.get('activities-heart', [])
            if activities_heart:
                # Get latest heart rate
                latest_data = activities_heart[-1]
                heart_rate = latest_data.get('value', {}).get('restingHeartRate', 70)

                # Generate RR intervals (Fitbit doesn't provide raw RR intervals in basic API)
                avg_rr = 60000 / heart_rate
                rr_intervals = [avg_rr + np.random.normal(0, avg_rr * 0.05) for _ in range(10)]

                return heart_rate, rr_intervals
        except Exception as e:
            self.logger.error(f"Failed to parse Fitbit data: {e}")

        return None, None

    def _check_stress_levels(self, hr_data: HeartRateData):
        """Check stress levels and trigger callbacks"""
        if self.stress_callback:
            stress_info = {
                'level': hr_data.stress_level,
                'status': hr_data.status,
                'heart_rate': hr_data.heart_rate,
                'hrv_rmssd': hr_data.hrv_rmssd,
                'timestamp': hr_data.timestamp.isoformat(),
                'stress_detected': hr_data.stress_level >= 0.7,
                'panic_detected': hr_data.stress_level >= 0.9
            }

            try:
                self.stress_callback(stress_info)
            except Exception as e:
                self.logger.error(f"Error in stress callback: {e}")

    def set_stress_callback(self, callback: Callable):
        """Set callback for stress detection events"""
        self.stress_callback = callback
        self.logger.info("Stress callback registered")

    def get_current_data(self) -> Optional[Dict[str, Any]]:
        """Get current heart rate data"""
        if self.current_data:
            return {
                'heart_rate': self.current_data.heart_rate,
                'stress_level': self.current_data.stress_level,
                'status': self.current_data.status,
                'hrv_rmssd': self.current_data.hrv_rmssd,
                'timestamp': self.current_data.timestamp.isoformat()
            }
        return None

    def get_stress_history(self, minutes: int = 10) -> List[Dict[str, Any]]:
        """Get stress level history"""
        cutoff_time = datetime.now() - timedelta(minutes=minutes)
        history = []

        for data in self.heart_rate_history:
            if data.timestamp >= cutoff_time:
                history.append({
                    'timestamp': data.timestamp.isoformat(),
                    'stress_level': data.stress_level,
                    'status': data.status,
                    'heart_rate': data.heart_rate
                })

        return history

    def simulate_stress_test(self, stress_level: float):
        """Simulate stress for testing purposes"""
        if self.simulated_source:
            self.simulated_source.simulate_stress(stress_level)
            self.logger.info(f"Simulating stress level: {stress_level}")

    def shutdown(self):
        """Shutdown heart rate monitoring"""
        self.monitoring_active = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5.0)
        self.logger.info("Heart rate monitoring shutdown")

# Main execution for testing
if __name__ == "__main__":
    # Test configuration
    test_config = {
        "device_type": "simulated",
        "sampling_rate": 1.0,
        "stress_detection": True,
        "hrv_analysis": True
    }

    def stress_callback(stress_info):
        print(f"Stress detected: {stress_info}")

    # Initialize and test
    hr_monitor = HeartRateMonitor(test_config)
    hr_monitor.set_stress_callback(stress_callback)

    if hr_monitor.start_monitoring():
        print("Heart rate monitoring started")

        try:
            # Test normal operation
            time.sleep(5)

            # Simulate stress
            print("Simulating high stress...")
            hr_monitor.simulate_stress_test(0.8)
            time.sleep(5)

            # Get current data
            current = hr_monitor.get_current_data()
            if current:
                print(f"Current HR data: {json.dumps(current, indent=2)}")

        except KeyboardInterrupt:
            pass
        finally:
            hr_monitor.shutdown()
    else:
        print("Failed to start heart rate monitoring")
