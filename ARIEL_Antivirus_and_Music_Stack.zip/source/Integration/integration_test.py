#!/usr/bin/env python3
"""
ARIEL Enhanced Integration Test and Demonstration
Comprehensive testing of biometric security features and music production integration.
"""

import os
import sys
import json
import logging
import time
import threading
from datetime import datetime
from typing import Dict, List, Any, Optional

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('ARIELIntegrationTest')

class IntegrationTester:
    """Test the complete ARIEL integration with biometric and music features"""

    def __init__(self):
        self.integration_manager = None
        self.test_results = {}
        self.test_session_id = None

    def initialize_test_environment(self) -> bool:
        """Initialize the test environment"""
        try:
            logger.info("Initializing ARIEL Integration Test Environment...")

            # Import the enhanced integration manager
            sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'Integration'))
            from main import ARIELIntegrationManager

            # Initialize integration manager
            self.integration_manager = ARIELIntegrationManager()

            if self.integration_manager.initialize_system():
                logger.info("Integration manager initialized successfully")
                return True
            else:
                logger.error("Failed to initialize integration manager")
                return False

        except Exception as e:
            logger.error(f"Test environment initialization failed: {e}")
            return False

    def run_comprehensive_tests(self) -> Dict[str, Any]:
        """Run comprehensive integration tests"""
        logger.info("Starting comprehensive ARIEL integration tests...")

        test_suite = [
            ("Core Module Integration", self.test_core_modules),
            ("Biometric Security Integration", self.test_biometric_integration),
            ("Music Production Integration", self.test_music_production),
            ("Cross-Module Communication", self.test_cross_module_communication),
            ("Threat Response Coordination", self.test_threat_response),
            ("Biometric Event Handling", self.test_biometric_events),
            ("Voice Approval Workflow", self.test_voice_approval),
            ("Gesture Recognition Integration", self.test_gesture_recognition),
            ("Stress Detection Response", self.test_stress_detection),
            ("Secure Audio Session Management", self.test_secure_audio_sessions)
        ]

        results = {}

        for test_name, test_function in test_suite:
            logger.info(f"Running test: {test_name}")
            try:
                result = test_function()
                results[test_name] = {
                    'status': 'PASSED' if result else 'FAILED',
                    'timestamp': datetime.now().isoformat(),
                    'details': result if isinstance(result, dict) else {}
                }
                logger.info(f"Test {test_name}: {'PASSED' if result else 'FAILED'}")
            except Exception as e:
                results[test_name] = {
                    'status': 'ERROR',
                    'timestamp': datetime.now().isoformat(),
                    'error': str(e)
                }
                logger.error(f"Test {test_name} ERROR: {e}")

        return results

    def test_core_modules(self) -> bool:
        """Test core antivirus module integration"""
        try:
            if not self.integration_manager:
                return False

            core_modules = ['PhiGuard_Core', 'WardenMonitor', 'ReHabScanner', 'SigStrat']
            loaded_modules = list(self.integration_manager.modules.keys())

            # Check if core modules are loaded
            core_loaded = all(module in loaded_modules for module in core_modules)

            if core_loaded:
                logger.info("All core modules loaded successfully")

                # Test module status
                system_status = self.integration_manager.get_system_status()
                modules_active = all(
                    system_status['modules'].get(module, {}).get('status') in ['active', 'loaded']
                    for module in core_modules
                )

                return modules_active

            return False

        except Exception as e:
            logger.error(f"Core module test failed: {e}")
            return False

    def test_biometric_integration(self) -> bool:
        """Test biometric security integration"""
        try:
            biometric_modules = ['BiometricCore', 'HeartRateMonitor', 'VoiceApproval', 'GestureRecognition']
            loaded_modules = list(self.integration_manager.modules.keys())

            # Check if biometric modules are loaded
            biometric_loaded = all(module in loaded_modules for module in biometric_modules)

            if biometric_loaded:
                logger.info("All biometric modules loaded successfully")

                # Test biometric core functionality
                if 'BiometricCore' in self.integration_manager.modules:
                    biometric_core = self.integration_manager.modules['BiometricCore']
                    if biometric_core.module_instance:
                        # Test getting biometric status
                        status = biometric_core.module_instance.get_biometric_status()
                        if status and 'stress_level' in status:
                            logger.info("Biometric status retrieval successful")
                            return True

            return False

        except Exception as e:
            logger.error(f"Biometric integration test failed: {e}")
            return False

    def test_music_production(self) -> bool:
        """Test music production stack integration"""
        try:
            if 'rehab_rehype_ai' not in self.integration_manager.modules:
                logger.error("Music production module not loaded")
                return False

            music_module = self.integration_manager.modules['rehab_rehype_ai']
            if not music_module.module_instance:
                logger.error("Music production module not initialized")
                return False

            # Test creating an audio session
            session_id = music_module.module_instance.create_audio_session("test_user", "integration_test")

            if session_id:
                self.test_session_id = session_id
                logger.info(f"Audio session created successfully: {session_id}")

                # Test session status
                session_status = music_module.module_instance.get_session_status(session_id)
                if session_status:
                    logger.info("Session status retrieval successful")
                    return True

            return False

        except Exception as e:
            logger.error(f"Music production test failed: {e}")
            return False

    def test_cross_module_communication(self) -> bool:
        """Test communication between modules"""
        try:
            # Test biometric-music integration
            if ('BiometricCore' in self.integration_manager.modules and 
                'rehab_rehype_ai' in self.integration_manager.modules):

                biometric_core = self.integration_manager.modules['BiometricCore']
                music_module = self.integration_manager.modules['rehab_rehype_ai']

                # Check if biometric core is connected to music module
                if (music_module.module_instance and 
                    hasattr(music_module.module_instance, 'biometric_core') and
                    music_module.module_instance.biometric_core is not None):
                    logger.info("Biometric-Music integration verified")
                    return True

            return False

        except Exception as e:
            logger.error(f"Cross-module communication test failed: {e}")
            return False

    def test_threat_response(self) -> bool:
        """Test threat response coordination"""
        try:
            # Simulate a threat report
            test_threat = {
                'id': 'test_threat_001',
                'type': 'plugin_threat',
                'severity': 'medium',
                'source': 'AVxSentinel',
                'description': 'Suspicious audio plugin detected',
                'timestamp': datetime.now().isoformat()
            }

            # Report threat to integration manager
            self.integration_manager.report_threat(test_threat)

            # Wait for processing
            time.sleep(2)

            # Check if threat was processed
            stats = self.integration_manager.integration_statistics
            if stats.get('threats_processed', 0) > 0:
                logger.info("Threat response coordination successful")
                return True

            return False

        except Exception as e:
            logger.error(f"Threat response test failed: {e}")
            return False

    def test_biometric_events(self) -> bool:
        """Test biometric event handling"""
        try:
            # Simulate biometric events
            test_events = [
                {
                    'type': 'stress_detected',
                    'data': {
                        'stress_level': 0.8,
                        'timestamp': datetime.now().isoformat(),
                        'action': 'enhanced_monitoring'
                    }
                },
                {
                    'type': 'biometric_authentication',
                    'data': {
                        'user_id': 'test_user',
                        'authenticated': True,
                        'timestamp': datetime.now().isoformat()
                    }
                }
            ]

            for event in test_events:
                self.integration_manager.handle_biometric_event(event['type'], event['data'])

            # Wait for processing
            time.sleep(1)

            # Check if events were processed
            stats = self.integration_manager.integration_statistics
            if stats.get('biometric_events', 0) >= len(test_events):
                logger.info("Biometric event handling successful")
                return True

            return False

        except Exception as e:
            logger.error(f"Biometric event test failed: {e}")
            return False

    def test_voice_approval(self) -> bool:
        """Test voice approval workflow"""
        try:
            if 'VoiceApproval' not in self.integration_manager.modules:
                logger.warning("VoiceApproval module not available for testing")
                return True  # Skip test if module not available

            voice_module = self.integration_manager.modules['VoiceApproval']
            if voice_module.module_instance:
                # Test voice approval status (without actual audio)
                logger.info("Voice approval module available and initialized")
                return True

            return False

        except Exception as e:
            logger.error(f"Voice approval test failed: {e}")
            return False

    def test_gesture_recognition(self) -> bool:
        """Test gesture recognition integration"""
        try:
            if 'GestureRecognition' not in self.integration_manager.modules:
                logger.warning("GestureRecognition module not available for testing")
                return True  # Skip test if module not available

            gesture_module = self.integration_manager.modules['GestureRecognition']
            if gesture_module.module_instance:
                # Test gesture recognition status (without actual camera)
                logger.info("Gesture recognition module available and initialized")
                return True

            return False

        except Exception as e:
            logger.error(f"Gesture recognition test failed: {e}")
            return False

    def test_stress_detection(self) -> bool:
        """Test stress detection and response"""
        try:
            # Simulate high stress event
            stress_event = {
                'type': 'panic_lockdown',
                'data': {
                    'stress_level': 0.95,
                    'timestamp': datetime.now().isoformat(),
                    'action': 'system_lockdown'
                }
            }

            self.integration_manager.handle_biometric_event(stress_event['type'], stress_event['data'])

            # Wait for processing
            time.sleep(1)

            logger.info("Stress detection response test completed")
            return True

        except Exception as e:
            logger.error(f"Stress detection test failed: {e}")
            return False

    def test_secure_audio_sessions(self) -> bool:
        """Test secure audio session management"""
        try:
            if not self.test_session_id:
                logger.warning("No test session available for secure audio test")
                return True

            if 'rehab_rehype_ai' in self.integration_manager.modules:
                music_module = self.integration_manager.modules['rehab_rehype_ai']

                # Test session management
                session_status = music_module.module_instance.get_session_status(self.test_session_id)

                if session_status and session_status.get('biometric_verified'):
                    logger.info("Secure audio session management verified")

                    # Clean up test session
                    music_module.module_instance.close_session(self.test_session_id)
                    return True

            return False

        except Exception as e:
            logger.error(f"Secure audio session test failed: {e}")
            return False

    def generate_test_report(self, results: Dict[str, Any]) -> str:
        """Generate comprehensive test report"""
        report = []
        report.append("="*80)
        report.append("ARIEL ENHANCED INTEGRATION TEST REPORT")
        report.append("="*80)
        report.append(f"Test Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append(f"Total Tests: {len(results)}")

        passed_tests = sum(1 for r in results.values() if r['status'] == 'PASSED')
        failed_tests = sum(1 for r in results.values() if r['status'] == 'FAILED')
        error_tests = sum(1 for r in results.values() if r['status'] == 'ERROR')

        report.append(f"Passed: {passed_tests}")
        report.append(f"Failed: {failed_tests}")
        report.append(f"Errors: {error_tests}")
        report.append("")

        # System status
        if self.integration_manager:
            system_status = self.integration_manager.get_system_status()
            report.append("SYSTEM STATUS:")
            report.append(f"  Overall Status: {system_status.get('system_status', 'unknown')}")
            report.append(f"  Modules Loaded: {len(system_status.get('modules', {}))}")
            report.append(f"  Active Threats: {system_status.get('active_threats', 0)}")
            report.append(f"  Biometric Events: {system_status.get('recent_biometric_events', 0)}")
            report.append("")

        # Detailed test results
        report.append("DETAILED TEST RESULTS:")
        report.append("-" * 40)

        for test_name, result in results.items():
            status_symbol = "✓" if result['status'] == 'PASSED' else "✗" if result['status'] == 'FAILED' else "!"
            report.append(f"{status_symbol} {test_name}: {result['status']}")

            if result['status'] == 'ERROR':
                report.append(f"    Error: {result.get('error', 'Unknown error')}")

            if result.get('details'):
                report.append(f"    Details: {result['details']}")

            report.append("")

        # Integration statistics
        if self.integration_manager:
            stats = self.integration_manager.integration_statistics
            report.append("INTEGRATION STATISTICS:")
            report.append("-" * 40)
            report.append(f"Modules Loaded: {stats.get('modules_loaded', 0)}")
            report.append(f"Threats Processed: {stats.get('threats_processed', 0)}")
            report.append(f"Responses Coordinated: {stats.get('responses_coordinated', 0)}")
            report.append(f"Correlations Found: {stats.get('correlations_found', 0)}")
            report.append(f"Biometric Events: {stats.get('biometric_events', 0)}")
            report.append("")

        # Module status
        if self.integration_manager:
            system_status = self.integration_manager.get_system_status()
            modules = system_status.get('modules', {})

            report.append("MODULE STATUS:")
            report.append("-" * 40)

            module_categories = {
                'Core Modules': ['PhiGuard_Core', 'WardenMonitor', 'ReHabScanner', 'SigStrat'],
                'Specialized Modules': ['AVxSentinel', 'ReDriverAI', 'PsiPlayGuard', 'PsiShield'],
                'Biometric Modules': ['BiometricCore', 'HeartRateMonitor', 'VoiceApproval', 'GestureRecognition'],
                'Music Production': ['rehab_rehype_ai']
            }

            for category, module_list in module_categories.items():
                report.append(f"{category}:")
                for module_name in module_list:
                    if module_name in modules:
                        status = modules[module_name].get('status', 'unknown')
                        status_symbol = "✓" if status in ['active', 'loaded'] else "✗"
                        report.append(f"  {status_symbol} {module_name}: {status}")
                    else:
                        report.append(f"  ✗ {module_name}: not loaded")
                report.append("")

        report.append("="*80)

        return "\n".join(report)

    def cleanup(self):
        """Cleanup test environment"""
        try:
            if self.integration_manager:
                self.integration_manager.shutdown_system()
                logger.info("Test environment cleanup completed")
        except Exception as e:
            logger.error(f"Cleanup failed: {e}")

def main():
    """Main test execution"""
    tester = IntegrationTester()

    try:
        # Initialize test environment
        if not tester.initialize_test_environment():
            print("Failed to initialize test environment")
            return

        # Run comprehensive tests
        results = tester.run_comprehensive_tests()

        # Generate and display report
        report = tester.generate_test_report(results)
        print(report)

        # Save report to file
        report_filename = f"ariel_integration_test_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        with open(report_filename, 'w') as f:
            f.write(report)

        print(f"\nTest report saved to: {report_filename}")

        # Summary
        passed_tests = sum(1 for r in results.values() if r['status'] == 'PASSED')
        total_tests = len(results)

        print(f"\nTEST SUMMARY: {passed_tests}/{total_tests} tests passed")

        if passed_tests == total_tests:
            print("🎉 ALL TESTS PASSED - ARIEL Enhanced Integration is working correctly!")
        else:
            print("⚠️  Some tests failed - Check the detailed report above")

    except KeyboardInterrupt:
        print("\nTest interrupted by user")
    except Exception as e:
        print(f"Test execution failed: {e}")
    finally:
        tester.cleanup()

if __name__ == "__main__":
    main()
