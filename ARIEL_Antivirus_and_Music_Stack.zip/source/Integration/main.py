#!/usr/bin/env python3
"""
ARIEL Antivirus Integration Manager - Enhanced with Biometric Security
Central coordination system for all antivirus modules with real-time communication,
threat correlation, unified response management, and biometric security integration.
"""

import os
import sys
import json
import logging
import threading
import time
import asyncio
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime, timedelta
from collections import defaultdict, deque
import importlib.util

# Add source directory to path for module imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('ARIELIntegration')

class ModuleInterface:
    """Base interface for all antivirus modules"""

    def __init__(self, module_name: str, module_path: str):
        self.module_name = module_name
        self.module_path = module_path
        self.module_instance = None
        self.is_initialized = False
        self.last_heartbeat = None
        self.status = 'inactive'

    def load_module(self) -> bool:
        """Load and initialize the module"""
        try:
            spec = importlib.util.spec_from_file_location(self.module_name, self.module_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Get the main class from the module
            class_name = self._get_main_class_name()
            if hasattr(module, class_name):
                self.module_instance = getattr(module, class_name)()
                self.is_initialized = True
                self.status = 'loaded'
                logger.info(f"Module {self.module_name} loaded successfully")
                return True
            else:
                logger.error(f"Main class {class_name} not found in {self.module_name}")
                return False

        except Exception as e:
            logger.error(f"Failed to load module {self.module_name}: {e}")
            return False

    def _get_main_class_name(self) -> str:
        """Get the expected main class name for the module"""
        class_mapping = {
            'PhiGuard_Core': 'PhiGuardCore',
            'WardenMonitor': 'WardenMonitor',
            'ReHabScanner': 'ReHabScanner',
            'SigStrat': 'SigStrat',
            'AVxSentinel': 'AVxSentinel',
            'ReDriverAI': 'ReDriverAI',
            'PsiPlayGuard': 'PsiPlayGuard',
            'PsiShield': 'PsiShield',
            'BiometricCore': 'BiometricCore',
            'HeartRateMonitor': 'HeartRateMonitor',
            'VoiceApproval': 'VoiceApproval',
            'GestureRecognition': 'GestureRecognition',
            'rehab_rehype_ai': 'RehabRehypeAI'
        }
        return class_mapping.get(self.module_name, self.module_name)

    def initialize_module(self) -> bool:
        """Initialize the loaded module"""
        try:
            if self.module_instance and hasattr(self.module_instance, 'initialize'):
                result = self.module_instance.initialize()
                if result:
                    self.status = 'active'
                    self.last_heartbeat = datetime.now()
                    logger.info(f"Module {self.module_name} initialized successfully")
                return result
            return False
        except Exception as e:
            logger.error(f"Failed to initialize module {self.module_name}: {e}")
            return False

    def send_command(self, command: str, data: Dict[str, Any] = None) -> Any:
        """Send command to the module"""
        try:
            if self.module_instance and hasattr(self.module_instance, 'handle_command'):
                return self.module_instance.handle_command(command, data or {})
            return None
        except Exception as e:
            logger.error(f"Command failed for {self.module_name}: {e}")
            return None

    def get_status(self) -> Dict[str, Any]:
        """Get module status"""
        try:
            if self.module_instance and hasattr(self.module_instance, 'get_status'):
                return self.module_instance.get_status()
            return {'status': self.status, 'last_heartbeat': self.last_heartbeat}
        except Exception as e:
            logger.error(f"Status check failed for {self.module_name}: {e}")
            return {'status': 'error', 'error': str(e)}

class BiometricEventHandler:
    """Handle biometric security events and coordinate responses"""

    def __init__(self, integration_manager):
        self.integration_manager = integration_manager
        self.biometric_events = deque(maxlen=100)
        self.stress_threshold = 0.7
        self.panic_threshold = 0.9
        self.logger = logging.getLogger('BiometricEventHandler')

    def handle_biometric_event(self, event_type: str, data: Dict[str, Any]):
        """Handle biometric security events"""
        try:
            event = {
                'type': event_type,
                'data': data,
                'timestamp': datetime.now(),
                'processed': False
            }

            self.biometric_events.append(event)
            self.logger.info(f"Biometric event received: {event_type}")

            # Process event based on type
            if event_type == 'panic_lockdown':
                self._handle_panic_lockdown(data)
            elif event_type == 'stress_detected':
                self._handle_stress_detection(data)
            elif event_type == 'voice_approval_request':
                self._handle_voice_approval(data)
            elif event_type == 'gesture_approval_request':
                self._handle_gesture_approval(data)
            elif event_type == 'biometric_authentication':
                self._handle_biometric_auth(data)

            event['processed'] = True

        except Exception as e:
            self.logger.error(f"Biometric event handling failed: {e}")

    def _handle_panic_lockdown(self, data: Dict[str, Any]):
        """Handle panic situation - immediate system lockdown"""
        self.logger.critical("PANIC DETECTED - Initiating emergency lockdown")

        # Notify all security modules
        lockdown_command = {
            'action': 'emergency_lockdown',
            'reason': 'biometric_panic_detected',
            'stress_level': data.get('stress_level', 1.0),
            'timestamp': data.get('timestamp')
        }

        # Lock down all modules
        for module_name, module in self.integration_manager.modules.items():
            try:
                if module_name in ['PhiGuard_Core', 'WardenMonitor', 'PsiShield']:
                    module.send_command('emergency_lockdown', lockdown_command)
            except Exception as e:
                self.logger.error(f"Lockdown command failed for {module_name}: {e}")

        # Stop music production if active
        if 'rehab_rehype_ai' in self.integration_manager.modules:
            try:
                self.integration_manager.modules['rehab_rehype_ai'].send_command('emergency_stop', lockdown_command)
            except Exception as e:
                self.logger.error(f"Music production emergency stop failed: {e}")

    def _handle_stress_detection(self, data: Dict[str, Any]):
        """Handle elevated stress detection"""
        stress_level = data.get('stress_level', 0.0)
        self.logger.warning(f"Elevated stress detected: {stress_level}")

        # Increase monitoring sensitivity
        monitoring_command = {
            'action': 'increase_sensitivity',
            'stress_level': stress_level,
            'duration': 300  # 5 minutes
        }

        # Notify monitoring modules
        for module_name in ['WardenMonitor', 'ReHabScanner', 'PsiShield']:
            if module_name in self.integration_manager.modules:
                try:
                    self.integration_manager.modules[module_name].send_command('adjust_monitoring', monitoring_command)
                except Exception as e:
                    self.logger.error(f"Stress response failed for {module_name}: {e}")

    def _handle_voice_approval(self, data: Dict[str, Any]):
        """Handle voice approval requests"""
        action = data.get('action', 'unknown')
        self.logger.info(f"Voice approval requested for: {action}")

        # Log approval request
        approval_event = {
            'type': 'voice_approval',
            'action': action,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }

        self.integration_manager.log_security_event(approval_event)

    def _handle_gesture_approval(self, data: Dict[str, Any]):
        """Handle gesture approval requests"""
        action = data.get('action', 'unknown')
        self.logger.info(f"Gesture approval requested for: {action}")

        # Log approval request
        approval_event = {
            'type': 'gesture_approval',
            'action': action,
            'timestamp': datetime.now().isoformat(),
            'status': 'pending'
        }

        self.integration_manager.log_security_event(approval_event)

    def _handle_biometric_auth(self, data: Dict[str, Any]):
        """Handle biometric authentication events"""
        auth_result = data.get('authenticated', False)
        user_id = data.get('user_id', 'unknown')

        if auth_result:
            self.logger.info(f"Biometric authentication successful for user: {user_id}")
        else:
            self.logger.warning(f"Biometric authentication failed for user: {user_id}")

            # Increase security monitoring on failed auth
            self._handle_stress_detection({'stress_level': 0.8})

class ThreatCorrelationEngine:
    """Enhanced threat correlation with biometric context"""

    def __init__(self):
        self.threat_patterns = {}
        self.correlation_rules = {}
        self.biometric_context = {}
        self.active_correlations = {}
        self.logger = logging.getLogger('ThreatCorrelationEngine')

    def initialize_correlation(self) -> bool:
        """Initialize threat correlation engine with biometric awareness"""
        try:
            # Load enhanced correlation rules
            self.correlation_rules = {
                'file_system_anomaly': {
                    'modules': ['PhiGuard_Core', 'WardenMonitor'],
                    'threshold': 2,
                    'biometric_factor': True
                },
                'network_intrusion': {
                    'modules': ['PsiShield', 'WardenMonitor'],
                    'threshold': 2,
                    'biometric_factor': True
                },
                'plugin_threat': {
                    'modules': ['AVxSentinel', 'ReHabScanner'],
                    'threshold': 1,
                    'biometric_factor': False
                },
                'driver_compromise': {
                    'modules': ['ReDriverAI', 'PhiGuard_Core'],
                    'threshold': 2,
                    'biometric_factor': True
                },
                'media_exploit': {
                    'modules': ['PsiPlayGuard', 'ReHabScanner'],
                    'threshold': 1,
                    'biometric_factor': False
                },
                'biometric_anomaly': {
                    'modules': ['BiometricCore', 'WardenMonitor'],
                    'threshold': 1,
                    'biometric_factor': True
                }
            }

            self.logger.info("Enhanced threat correlation engine initialized")
            return True

        except Exception as e:
            self.logger.error(f"Correlation engine initialization failed: {e}")
            return False

    def correlate_threat(self, threat_data: Dict[str, Any], biometric_context: Dict[str, Any] = None) -> Optional[Dict[str, Any]]:
        """Correlate threats with biometric context"""
        try:
            threat_type = threat_data.get('type', 'unknown')
            source_module = threat_data.get('source', 'unknown')

            # Store biometric context if provided
            if biometric_context:
                self.biometric_context[threat_data.get('id', 'unknown')] = biometric_context

            # Check for correlation patterns
            for pattern_name, pattern_config in self.correlation_rules.items():
                if source_module in pattern_config['modules']:
                    correlation = self._analyze_correlation(threat_data, pattern_config, biometric_context)
                    if correlation:
                        return correlation

            return None

        except Exception as e:
            self.logger.error(f"Threat correlation failed: {e}")
            return None

    def _analyze_correlation(self, threat_data: Dict[str, Any], pattern_config: Dict[str, Any], 
                           biometric_context: Dict[str, Any] = None) -> Optional[Dict[str, Any]]:
        """Analyze threat correlation with biometric factors"""
        try:
            correlation_score = 1.0

            # Factor in biometric context if available and relevant
            if pattern_config.get('biometric_factor', False) and biometric_context:
                stress_level = biometric_context.get('stress_level', 0.0)

                # High stress increases correlation score (user might be under duress)
                if stress_level > 0.8:
                    correlation_score *= 1.5
                    self.logger.warning("High stress detected during threat - increasing correlation score")

                # Authentication failures increase correlation score
                if not biometric_context.get('authenticated', True):
                    correlation_score *= 1.3

            # Check threat severity
            severity = threat_data.get('severity', 'low')
            severity_multiplier = {'low': 1.0, 'medium': 1.2, 'high': 1.5, 'critical': 2.0}
            correlation_score *= severity_multiplier.get(severity, 1.0)

            if correlation_score >= pattern_config.get('threshold', 1.0):
                return {
                    'correlation_id': f"corr_{int(time.time())}",
                    'threat_data': threat_data,
                    'correlation_score': correlation_score,
                    'biometric_context': biometric_context,
                    'pattern_matched': True,
                    'timestamp': datetime.now().isoformat()
                }

            return None

        except Exception as e:
            self.logger.error(f"Correlation analysis failed: {e}")
            return None

class ResponseCoordinator:
    """Enhanced response coordination with biometric integration"""

    def __init__(self):
        self.response_strategies = {}
        self.active_responses = {}
        self.biometric_responses = {}
        self.logger = logging.getLogger('ResponseCoordinator')

    def initialize_coordinator(self) -> bool:
        """Initialize response coordinator with biometric strategies"""
        try:
            # Enhanced response strategies including biometric responses
            self.response_strategies = {
                'isolate_threat': ['PhiGuard_Core', 'PsiShield'],
                'quarantine_file': ['SigStrat', 'PhiGuard_Core'],
                'block_network': ['PsiShield'],
                'increase_monitoring': ['WardenMonitor', 'ReHabScanner'],
                'scan_system': ['ReHabScanner', 'SigStrat'],
                'validate_plugins': ['AVxSentinel'],
                'secure_drivers': ['ReDriverAI'],
                'protect_media': ['PsiPlayGuard'],
                'biometric_lockdown': ['BiometricCore', 'PhiGuard_Core'],
                'voice_verification': ['VoiceApproval'],
                'gesture_verification': ['GestureRecognition'],
                'stress_response': ['BiometricCore', 'WardenMonitor'],
                'secure_audio_session': ['rehab_rehype_ai', 'AVxSentinel']
            }

            # Biometric-specific response strategies
            self.biometric_responses = {
                'panic_detected': ['biometric_lockdown', 'isolate_threat', 'block_network'],
                'stress_elevated': ['increase_monitoring', 'stress_response'],
                'auth_failed': ['voice_verification', 'gesture_verification'],
                'audio_threat': ['secure_audio_session', 'validate_plugins']
            }

            self.logger.info("Enhanced response coordinator initialized")
            return True

        except Exception as e:
            self.logger.error(f"Response coordinator initialization failed: {e}")
            return False

    def coordinate_response(self, threat_data: Dict[str, Any], biometric_context: Dict[str, Any] = None) -> bool:
        """Coordinate response with biometric considerations"""
        try:
            threat_type = threat_data.get('type', 'unknown')
            severity = threat_data.get('severity', 'low')

            # Determine response strategy
            response_actions = self._determine_response_actions(threat_data, biometric_context)

            if not response_actions:
                self.logger.warning(f"No response strategy found for threat: {threat_type}")
                return False

            # Execute coordinated response
            response_id = f"resp_{int(time.time())}"
            self.active_responses[response_id] = {
                'threat_data': threat_data,
                'biometric_context': biometric_context,
                'actions': response_actions,
                'start_time': datetime.now(),
                'status': 'executing'
            }

            success = self._execute_response_actions(response_id, response_actions)

            self.active_responses[response_id]['status'] = 'completed' if success else 'failed'
            self.active_responses[response_id]['end_time'] = datetime.now()

            return success

        except Exception as e:
            self.logger.error(f"Response coordination failed: {e}")
            return False

    def _determine_response_actions(self, threat_data: Dict[str, Any], 
                                  biometric_context: Dict[str, Any] = None) -> List[str]:
        """Determine appropriate response actions including biometric responses"""
        try:
            actions = []
            threat_type = threat_data.get('type', 'unknown')
            severity = threat_data.get('severity', 'low')

            # Check for biometric-specific responses
            if biometric_context:
                stress_level = biometric_context.get('stress_level', 0.0)

                if stress_level >= 0.9:
                    actions.extend(self.biometric_responses.get('panic_detected', []))
                elif stress_level >= 0.7:
                    actions.extend(self.biometric_responses.get('stress_elevated', []))

                if not biometric_context.get('authenticated', True):
                    actions.extend(self.biometric_responses.get('auth_failed', []))

            # Standard threat responses
            if threat_type in ['malware', 'virus']:
                actions.extend(['quarantine_file', 'scan_system'])
            elif threat_type in ['network_intrusion', 'suspicious_connection']:
                actions.extend(['block_network', 'increase_monitoring'])
            elif threat_type in ['plugin_threat', 'audio_exploit']:
                actions.extend(['validate_plugins', 'secure_audio_session'])
            elif threat_type in ['driver_compromise']:
                actions.extend(['secure_drivers', 'isolate_threat'])
            elif threat_type in ['media_exploit']:
                actions.extend(['protect_media', 'quarantine_file'])

            # Escalate response based on severity
            if severity in ['high', 'critical']:
                actions.extend(['isolate_threat', 'increase_monitoring'])

            return list(set(actions))  # Remove duplicates

        except Exception as e:
            self.logger.error(f"Response action determination failed: {e}")
            return []

    def _execute_response_actions(self, response_id: str, actions: List[str]) -> bool:
        """Execute coordinated response actions"""
        try:
            success_count = 0
            total_actions = len(actions)

            for action in actions:
                if action in self.response_strategies:
                    modules = self.response_strategies[action]
                    action_success = self._execute_action_on_modules(action, modules)
                    if action_success:
                        success_count += 1

                    self.logger.info(f"Action '{action}' {'succeeded' if action_success else 'failed'}")

            success_rate = success_count / total_actions if total_actions > 0 else 0
            return success_rate >= 0.7  # Consider successful if 70% of actions succeed

        except Exception as e:
            self.logger.error(f"Response action execution failed: {e}")
            return False

    def _execute_action_on_modules(self, action: str, modules: List[str]) -> bool:
        """Execute action on specified modules"""
        # This would be implemented to send commands to the actual modules
        # For now, we'll simulate the execution
        self.logger.info(f"Executing action '{action}' on modules: {modules}")
        return True

class ARIELIntegrationManager:
    """Enhanced main integration manager for ARIEL antivirus system with biometric security"""

    def __init__(self):
        self.modules = {}
        self.correlation_engine = ThreatCorrelationEngine()
        self.response_coordinator = ResponseCoordinator()
        self.biometric_handler = BiometricEventHandler(self)
        self.system_status = 'initializing'
        self.threat_reports = deque(maxlen=1000)
        self.security_events = deque(maxlen=500)
        self.biometric_events = deque(maxlen=200)

        self.integration_statistics = {
            'modules_loaded': 0,
            'threats_processed': 0,
            'responses_coordinated': 0,
            'correlations_found': 0,
            'biometric_events': 0,
            'start_time': datetime.now().isoformat()
        }

    def initialize_system(self) -> bool:
        """Initialize the complete enhanced ARIEL antivirus system"""
        logger.info("Initializing Enhanced ARIEL Antivirus Integration System...")

        try:
            # Initialize core components
            if not self.correlation_engine.initialize_correlation():
                logger.error("Failed to initialize threat correlation engine")
                return False

            if not self.response_coordinator.initialize_coordinator():
                logger.error("Failed to initialize response coordinator")
                return False

            # Load and initialize core antivirus modules
            core_modules = {
                'PhiGuard_Core': '../PhiGuard_Core/main.py',
                'WardenMonitor': '../WardenMonitor/main.py',
                'ReHabScanner': '../ReHabScanner/main.py',
                'SigStrat': '../SigStrat/main.py'
            }

            # Load and initialize specialized protection modules
            specialized_modules = {
                'AVxSentinel': '../AVxSentinel/main.py',
                'ReDriverAI': '../ReDriverAI/main.py',
                'PsiPlayGuard': '../PsiPlayGuard/main.py',
                'PsiShield': '../PsiShield/main.py'
            }

            # Load and initialize biometric security modules
            biometric_modules = {
                'BiometricCore': '../BiometricCore/main.py',
                'HeartRateMonitor': '../HeartRateMonitor/main.py',
                'VoiceApproval': '../VoiceApproval/main.py',
                'GestureRecognition': '../GestureRecognition/main.py'
            }

            # Load and initialize enhanced music production stack
            music_modules = {
                'rehab_rehype_ai': '../rehab_rehype_ai/main.py'
            }

            # Combine all modules for loading
            all_modules = {**core_modules, **specialized_modules, **biometric_modules, **music_modules}

            # Load modules in priority order
            module_priority = [
                # Core security first
                'PhiGuard_Core', 'WardenMonitor', 'ReHabScanner', 'SigStrat',
                # Biometric security
                'BiometricCore', 'HeartRateMonitor', 'VoiceApproval', 'GestureRecognition',
                # Specialized protection
                'AVxSentinel', 'ReDriverAI', 'PsiPlayGuard', 'PsiShield',
                # Music production
                'rehab_rehype_ai'
            ]

            for module_name in module_priority:
                if module_name in all_modules:
                    success = self._load_and_initialize_module(module_name, all_modules[module_name])
                    if success:
                        self.integration_statistics['modules_loaded'] += 1
                        logger.info(f"Module {module_name} loaded and initialized successfully")
                    else:
                        logger.warning(f"Failed to load module {module_name}")

            # Setup biometric integration
            self._setup_biometric_integration()

            # Setup music production integration
            self._setup_music_production_integration()

            # Start monitoring threads
            self._start_monitoring_threads()

            self.system_status = 'active'
            logger.info(f"Enhanced ARIEL system initialized with {len(self.modules)} modules")
            return True

        except Exception as e:
            logger.error(f"System initialization failed: {e}")
            self.system_status = 'failed'
            return False

    def _load_and_initialize_module(self, module_name: str, module_path: str) -> bool:
        """Load and initialize a single module"""
        try:
            # Check if module file exists
            full_path = os.path.join(os.path.dirname(__file__), module_path)
            if not os.path.exists(full_path):
                logger.warning(f"Module file not found: {full_path}")
                return False

            # Create module interface
            module_interface = ModuleInterface(module_name, full_path)

            # Load module
            if not module_interface.load_module():
                return False

            # Initialize module
            if not module_interface.initialize_module():
                return False

            # Store module
            self.modules[module_name] = module_interface
            return True

        except Exception as e:
            logger.error(f"Module loading failed for {module_name}: {e}")
            return False

    def _setup_biometric_integration(self):
        """Setup biometric security integration"""
        try:
            # Connect biometric core to integration manager
            if 'BiometricCore' in self.modules:
                biometric_core = self.modules['BiometricCore']
                if biometric_core.module_instance:
                    biometric_core.module_instance.set_integration_manager(self)
                    logger.info("Biometric integration established")

            # Setup biometric event handling
            self.biometric_handler = BiometricEventHandler(self)

        except Exception as e:
            logger.error(f"Biometric integration setup failed: {e}")

    def _setup_music_production_integration(self):
        """Setup music production stack integration"""
        try:
            if 'rehab_rehype_ai' in self.modules:
                music_stack = self.modules['rehab_rehype_ai']
                if music_stack.module_instance:
                    music_stack.module_instance.set_integration_manager(self)
                    logger.info("Music production integration established")

                    # Connect biometric security to music production
                    if 'BiometricCore' in self.modules:
                        biometric_core = self.modules['BiometricCore'].module_instance
                        music_stack.module_instance.biometric_core = biometric_core
                        logger.info("Biometric-music production integration established")

        except Exception as e:
            logger.error(f"Music production integration setup failed: {e}")

    def _start_monitoring_threads(self):
        """Start system monitoring threads"""
        try:
            # Start heartbeat monitoring
            heartbeat_thread = threading.Thread(target=self._heartbeat_monitor, daemon=True)
            heartbeat_thread.start()

            # Start threat correlation monitoring
            correlation_thread = threading.Thread(target=self._correlation_monitor, daemon=True)
            correlation_thread.start()

            logger.info("Monitoring threads started")

        except Exception as e:
            logger.error(f"Failed to start monitoring threads: {e}")

    def _heartbeat_monitor(self):
        """Monitor module heartbeats"""
        while self.system_status == 'active':
            try:
                for module_name, module in self.modules.items():
                    status = module.get_status()
                    if status.get('status') == 'error':
                        logger.warning(f"Module {module_name} reported error: {status.get('error')}")

                time.sleep(30)  # Check every 30 seconds

            except Exception as e:
                logger.error(f"Heartbeat monitoring error: {e}")
                time.sleep(30)

    def _correlation_monitor(self):
        """Monitor for threat correlations"""
        while self.system_status == 'active':
            try:
                # Process pending threat reports
                if self.threat_reports:
                    threat_data = self.threat_reports.popleft()

                    # Get biometric context if available
                    biometric_context = self._get_current_biometric_context()

                    # Correlate threat
                    correlation = self.correlation_engine.correlate_threat(threat_data, biometric_context)

                    if correlation:
                        self.integration_statistics['correlations_found'] += 1

                        # Coordinate response
                        self.response_coordinator.coordinate_response(threat_data, biometric_context)
                        self.integration_statistics['responses_coordinated'] += 1

                time.sleep(1)  # Process every second

            except Exception as e:
                logger.error(f"Correlation monitoring error: {e}")
                time.sleep(1)

    def _get_current_biometric_context(self) -> Dict[str, Any]:
        """Get current biometric context"""
        try:
            if 'BiometricCore' in self.modules:
                biometric_core = self.modules['BiometricCore']
                if biometric_core.module_instance:
                    return biometric_core.module_instance.get_biometric_status()
            return {}
        except Exception as e:
            logger.error(f"Failed to get biometric context: {e}")
            return {}

    def handle_biometric_event(self, event_type: str, data: Dict[str, Any]):
        """Handle biometric security events"""
        try:
            self.integration_statistics['biometric_events'] += 1
            self.biometric_events.append({
                'type': event_type,
                'data': data,
                'timestamp': datetime.now().isoformat()
            })

            # Delegate to biometric event handler
            self.biometric_handler.handle_biometric_event(event_type, data)

        except Exception as e:
            logger.error(f"Biometric event handling failed: {e}")

    def report_threat(self, threat_data: Dict[str, Any]):
        """Report threat from modules"""
        try:
            self.integration_statistics['threats_processed'] += 1
            self.threat_reports.append(threat_data)
            logger.info(f"Threat reported: {threat_data.get('type', 'unknown')}")

        except Exception as e:
            logger.error(f"Threat reporting failed: {e}")

    def log_security_event(self, event: Dict[str, Any]):
        """Log security events"""
        try:
            self.security_events.append(event)
            logger.info(f"Security event logged: {event.get('type', 'unknown')}")

        except Exception as e:
            logger.error(f"Security event logging failed: {e}")

    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status"""
        try:
            module_status = {}
            for module_name, module in self.modules.items():
                module_status[module_name] = module.get_status()

            return {
                'system_status': self.system_status,
                'modules': module_status,
                'statistics': self.integration_statistics,
                'active_threats': len(self.threat_reports),
                'recent_biometric_events': len([e for e in self.biometric_events 
                                              if datetime.fromisoformat(e['timestamp']) > datetime.now() - timedelta(minutes=5)]),
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            logger.error(f"Status retrieval failed: {e}")
            return {'error': str(e)}

    def shutdown_system(self):
        """Shutdown the entire system"""
        try:
            logger.info("Shutting down Enhanced ARIEL Integration System...")

            self.system_status = 'shutting_down'

            # Shutdown modules in reverse order
            shutdown_order = list(reversed(list(self.modules.keys())))

            for module_name in shutdown_order:
                try:
                    module = self.modules[module_name]
                    if module.module_instance and hasattr(module.module_instance, 'shutdown'):
                        module.module_instance.shutdown()
                        logger.info(f"Module {module_name} shutdown complete")
                except Exception as e:
                    logger.error(f"Module {module_name} shutdown failed: {e}")

            self.system_status = 'shutdown'
            logger.info("Enhanced ARIEL Integration System shutdown complete")

        except Exception as e:
            logger.error(f"System shutdown failed: {e}")

# Main execution
if __name__ == "__main__":
    integration_manager = ARIELIntegrationManager()

    try:
        if integration_manager.initialize_system():
            logger.info("Enhanced ARIEL system running...")

            # Keep system running
            while integration_manager.system_status == 'active':
                time.sleep(10)

                # Print status every minute
                status = integration_manager.get_system_status()
                logger.info(f"System Status: {status['system_status']}, "
                          f"Modules: {len(status['modules'])}, "
                          f"Threats: {status['active_threats']}")

        else:
            logger.error("Failed to initialize Enhanced ARIEL system")

    except KeyboardInterrupt:
        logger.info("Shutdown requested by user")
    except Exception as e:
        logger.error(f"System error: {e}")
    finally:
        integration_manager.shutdown_system()
