#!/usr/bin/env python3
"""
PsiPlayGuard - Media Playback Protection System
Secure multimedia consumption with threat detection
"""

import os
import sys
import json
import logging
import mimetypes
from typing import Dict, List, Any, Optional
from datetime import datetime

class PsiPlayGuard:
    def __init__(self, config_path: str = "config.json"):
        """Initialize PsiPlayGuard media protection"""
        self.config = self._load_config(config_path)
        self.media_registry = {}
        self.codec_whitelist = set()
        self.quarantined_media = set()
        self.streaming_monitors = {}

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        try:
            with open(config_path, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return {"error": "Config file not found"}

    def initialize_media_protection(self):
        """Initialize media playback protection systems"""
        logging.info("Initializing PsiPlayGuard media protection...")
        self._setup_codec_validation()
        self._initialize_media_scanners()
        self._setup_streaming_monitors()
        self._load_trusted_codecs()

    def _setup_codec_validation(self):
        """Setup codec validation system"""
        logging.info("Setting up codec validation...")

        # Common safe codecs
        safe_codecs = [
            "h264", "h265", "vp8", "vp9", "av1",  # Video
            "aac", "mp3", "opus", "vorbis", "flac"  # Audio
        ]

        self.codec_whitelist.update(safe_codecs)

    def _initialize_media_scanners(self):
        """Initialize media file scanners"""
        logging.info("Initializing media scanners...")

        self.scanner_config = {
            "deep_scan": True,
            "metadata_analysis": True,
            "embedded_content_check": True,
            "codec_verification": True
        }

    def _setup_streaming_monitors(self):
        """Setup streaming media monitors"""
        logging.info("Setting up streaming monitors...")

        self.streaming_monitors = {
            "active_streams": {},
            "blocked_streams": set(),
            "suspicious_patterns": []
        }

    def _load_trusted_codecs(self):
        """Load list of trusted media codecs"""
        # In real implementation, this would load from a database
        trusted_codecs = [
            {"name": "H.264", "type": "video", "trust_level": "high"},
            {"name": "AAC", "type": "audio", "trust_level": "high"},
            {"name": "VP9", "type": "video", "trust_level": "medium"}
        ]

        for codec in trusted_codecs:
            self.codec_whitelist.add(codec["name"].lower())

    def scan_media_file(self, file_path: str) -> Dict[str, Any]:
        """Scan media file for security threats"""
        if not os.path.exists(file_path):
            return {"error": "Media file not found", "safe": False}

        scan_result = {
            "file_path": file_path,
            "file_type": self._identify_media_type(file_path),
            "file_size": os.path.getsize(file_path),
            "timestamp": datetime.now().isoformat(),
            "safe": True,
            "threats_found": [],
            "codec_analysis": {},
            "metadata_analysis": {},
            "container_analysis": {}
        }

        # Perform comprehensive media analysis
        scan_result["codec_analysis"] = self._analyze_codecs(file_path)
        scan_result["metadata_analysis"] = self._analyze_metadata(file_path)
        scan_result["container_analysis"] = self._analyze_container(file_path)

        # Check for threats
        threats = []

        if not scan_result["codec_analysis"].get("safe", True):
            threats.extend(scan_result["codec_analysis"].get("threats", []))

        if not scan_result["metadata_analysis"].get("safe", True):
            threats.extend(scan_result["metadata_analysis"].get("threats", []))

        if not scan_result["container_analysis"].get("safe", True):
            threats.extend(scan_result["container_analysis"].get("threats", []))

        scan_result["threats_found"] = threats
        scan_result["safe"] = len(threats) == 0

        if not scan_result["safe"]:
            self.quarantined_media.add(file_path)

        return scan_result

    def _identify_media_type(self, file_path: str) -> str:
        """Identify media file type"""
        mime_type, _ = mimetypes.guess_type(file_path)

        if mime_type:
            if mime_type.startswith('video/'):
                return "video"
            elif mime_type.startswith('audio/'):
                return "audio"

        # Check by extension
        ext = os.path.splitext(file_path)[1].lower()

        video_exts = ['.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm']
        audio_exts = ['.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a']

        if ext in video_exts:
            return "video"
        elif ext in audio_exts:
            return "audio"
        else:
            return "unknown"

    def _analyze_codecs(self, file_path: str) -> Dict[str, Any]:
        """Analyze media codecs for security based on real CVE intelligence"""
        analysis = {
            "detected_codecs": [],
            "safe": True,
            "threats": [],
            "unknown_codecs": [],
            "cve_vulnerabilities": [],
            "codec_specific_risks": []
        }

        # Simulate codec detection (in real implementation, would use ffprobe or similar)
        file_ext = os.path.splitext(file_path)[1].lower()

        # Enhanced codec mappings with vulnerability awareness
        codec_mappings = {
            '.mp4': ['h264', 'aac'],
            '.avi': ['xvid', 'mp3'],
            '.mkv': ['h264', 'ac3'],
            '.mp3': ['mp3'],
            '.flac': ['flac'],
            '.ape': ['ape'],  # Monkey's Audio - known vulnerability
            '.wav': ['pcm'],
            '.m4a': ['aac'],
            '.ogg': ['vorbis']
        }

        detected_codecs = codec_mappings.get(file_ext, ['unknown'])
        analysis["detected_codecs"] = detected_codecs

        # Check for specific CVE vulnerabilities
        for codec in detected_codecs:
            # Check Monkey's Audio (APE) decoder vulnerability
            if codec == 'ape':
                analysis["cve_vulnerabilities"].append({
                    "codec": "ape",
                    "vulnerability": "Monkey's Audio decoder code execution",
                    "description": "Samsung smartphone APE decoder vulnerability allows code execution",
                    "severity": "high",
                    "mitigation": "Avoid processing APE files from untrusted sources"
                })
                analysis["threats"].append("APE codec vulnerability - potential code execution risk")
                analysis["safe"] = False

            # Check for MP3 ID3 tag vulnerabilities
            elif codec == 'mp3':
                if self._check_mp3_vulnerabilities(file_path):
                    analysis["codec_specific_risks"].append({
                        "codec": "mp3",
                        "risk": "Malformed ID3 tags",
                        "description": "Potential buffer overflow in ID3 tag parsing",
                        "severity": "medium"
                    })
                    analysis["threats"].append("MP3 ID3 tag parsing vulnerability detected")
                    analysis["safe"] = False

            # Check for FLAC metadata vulnerabilities
            elif codec == 'flac':
                if self._check_flac_vulnerabilities(file_path):
                    analysis["codec_specific_risks"].append({
                        "codec": "flac",
                        "risk": "Malformed metadata blocks",
                        "description": "Potential parsing vulnerability in FLAC metadata",
                        "severity": "medium"
                    })
                    analysis["threats"].append("FLAC metadata parsing vulnerability detected")
                    analysis["safe"] = False

            # Check for WAV chunk vulnerabilities
            elif codec == 'pcm' and file_ext == '.wav':
                if self._check_wav_vulnerabilities(file_path):
                    analysis["codec_specific_risks"].append({
                        "codec": "wav",
                        "risk": "Malformed WAV chunks",
                        "description": "Potential integer overflow in WAV chunk processing",
                        "severity": "medium"
                    })
                    analysis["threats"].append("WAV chunk processing vulnerability detected")
                    analysis["safe"] = False

            # Check against whitelist
            if codec not in self.codec_whitelist and codec != 'unknown':
                analysis["unknown_codecs"].append(codec)
                analysis["threats"].append(f"Unknown or untrusted codec: {codec}")
                analysis["safe"] = False

        return analysis

    def _check_mp3_vulnerabilities(self, file_path: str) -> bool:
        """Check for MP3-specific vulnerabilities based on CVE intelligence"""
        try:
            with open(file_path, 'rb') as f:
                header = f.read(128)  # Read ID3 header
                # Check for malformed ID3 tags
                if b'ID3' in header[:10]:
                    # Look for suspicious ID3 tag patterns
                    if len(header) > 10 and header[3:5] == b'\xff\xff':
                        return True
                    # Check for oversized ID3 tags
                    if len(header) > 10:
                        tag_size = int.from_bytes(header[6:10], 'big')
                        if tag_size > 0x7FFFFFFF:  # Suspiciously large
                            return True
        except Exception:
            pass
        return False

    def _check_flac_vulnerabilities(self, file_path: str) -> bool:
        """Check for FLAC-specific vulnerabilities"""
        try:
            with open(file_path, 'rb') as f:
                header = f.read(64)
                # Check FLAC signature and metadata blocks
                if b'fLaC' in header[:4]:
                    # Check for malformed metadata blocks
                    if len(header) > 8 and header[4] & 0x80 == 0 and header[5:8] == b'\xff\xff\xff':
                        return True
        except Exception:
            pass
        return False

    def _check_wav_vulnerabilities(self, file_path: str) -> bool:
        """Check for WAV-specific vulnerabilities"""
        try:
            with open(file_path, 'rb') as f:
                header = f.read(44)  # Standard WAV header size
                # Check WAV signature and chunks
                if b'RIFF' in header[:4] and b'WAVE' in header[8:12]:
                    # Check for malformed chunk sizes
                    if len(header) > 20:
                        chunk_size = int.from_bytes(header[16:20], 'little')
                        if chunk_size > 0x7FFFFFFF:  # Suspiciously large chunk
                            return True
        except Exception:
            pass
        return False

    def _analyze_metadata(self, file_path: str) -> Dict[str, Any]:
        """Analyze media metadata for threats"""
        analysis = {
            "metadata_found": {},
            "safe": True,
            "threats": [],
            "suspicious_fields": []
        }

        try:
            # Basic metadata analysis (in real implementation, would use proper media libraries)
            file_stats = os.stat(file_path)

            analysis["metadata_found"] = {
                "file_size": file_stats.st_size,
                "created": datetime.fromtimestamp(file_stats.st_ctime).isoformat(),
                "modified": datetime.fromtimestamp(file_stats.st_mtime).isoformat()
            }

            # Check for suspicious metadata patterns
            if file_stats.st_size > 2 * 1024 * 1024 * 1024:  # 2GB
                analysis["suspicious_fields"].append("Unusually large file size")

        except Exception as e:
            analysis["threats"].append(f"Error reading metadata: {str(e)}")
            analysis["safe"] = False

        return analysis

    def _analyze_container(self, file_path: str) -> Dict[str, Any]:
        """Analyze media container for embedded threats"""
        analysis = {
            "container_type": "",
            "safe": True,
            "threats": [],
            "embedded_content": []
        }

        try:
            # Analyze file header for container type
            with open(file_path, 'rb') as f:
                header = f.read(32)

            # Check for common container signatures
            if header.startswith(b'\x00\x00\x00\x20ftypmp4'):
                analysis["container_type"] = "MP4"
            elif header.startswith(b'RIFF'):
                analysis["container_type"] = "AVI/WAV"
            elif header.startswith(b'\x1aE\xdf\xa3'):
                analysis["container_type"] = "Matroska/WebM"
            else:
                analysis["container_type"] = "Unknown"
                analysis["threats"].append("Unknown container format")
                analysis["safe"] = False

            # Check for embedded executables or scripts
            with open(file_path, 'rb') as f:
                content_sample = f.read(8192)  # Read first 8KB

                # Look for executable signatures
                if b'MZ' in content_sample or b'\x7fELF' in content_sample:
                    analysis["threats"].append("Embedded executable detected")
                    analysis["safe"] = False

                # Look for script content
                script_patterns = [b'<script', b'javascript:', b'eval(']
                for pattern in script_patterns:
                    if pattern in content_sample:
                        analysis["threats"].append("Embedded script content detected")
                        analysis["safe"] = False
                        break

        except Exception as e:
            analysis["threats"].append(f"Container analysis error: {str(e)}")
            analysis["safe"] = False

        return analysis

    def monitor_streaming_session(self, stream_url: str) -> Dict[str, Any]:
        """Monitor streaming media session"""
        session_id = f"stream_{len(self.streaming_monitors['active_streams'])}"

        session_info = {
            "session_id": session_id,
            "stream_url": stream_url,
            "started": datetime.now().isoformat(),
            "status": "monitoring",
            "threats_detected": [],
            "data_transferred": 0
        }

        # Basic URL analysis
        if self._is_suspicious_stream_url(stream_url):
            session_info["threats_detected"].append("Suspicious streaming URL")
            session_info["status"] = "blocked"
            self.streaming_monitors["blocked_streams"].add(stream_url)
        else:
            self.streaming_monitors["active_streams"][session_id] = session_info

        return session_info

    def _is_suspicious_stream_url(self, url: str) -> bool:
        """Check if streaming URL is suspicious"""
        suspicious_patterns = [
            'temp', 'tmp', 'random', 'malware', 'exploit',
            'localhost', '127.0.0.1', 'file://'
        ]

        url_lower = url.lower()
        return any(pattern in url_lower for pattern in suspicious_patterns)

    def get_protection_status(self) -> Dict[str, Any]:
        """Get current media protection status"""
        return {
            "module": "PsiPlayGuard",
            "status": "active",
            "trusted_codecs": len(self.codec_whitelist),
            "quarantined_media": len(self.quarantined_media),
            "active_streams": len(self.streaming_monitors["active_streams"]),
            "blocked_streams": len(self.streaming_monitors["blocked_streams"]),
            "last_update": datetime.now().isoformat()
        }

if __name__ == "__main__":
    guard = PsiPlayGuard()
    guard.initialize_media_protection()

    status = guard.get_protection_status()
    print("PsiPlayGuard Status:")
    print(json.dumps(status, indent=2))
