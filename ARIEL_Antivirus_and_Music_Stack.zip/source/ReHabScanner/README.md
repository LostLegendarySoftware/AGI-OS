# ReHabScanner - AI Threat Detection Engine

## Overview
ReHabScanner provides advanced AI-powered threat detection integrated with AGI-OS AI systems.

## AGI-OS Integration
- **AI Models**: Uses models from `assets/etc/ai/models/`
- **Learning System**: Integrates with `assets/etc/ai/learning/`
- **Core AI**: Interfaces with `assets/bin/core/ai/`
- **AI Configuration**: Uses settings from `assets/etc/ai/config/`

## AI Detection Engines
- **Behavioral Analysis**: AI-powered behavior pattern recognition
- **Machine Learning Classification**: Neural network file classification
- **Heuristic Analysis**: Rule-based threat detection
- **Hash Analysis**: Signature-based malware detection

## Features
- Multi-layered AI threat detection
- Real-time learning and adaptation
- Integration with AGI-OS AI infrastructure
- Batch directory scanning
- Threat intelligence updates

## Usage
```python
from main import ReHabScanner

scanner = ReHabScanner()
scanner.initialize_ai_systems()
result = scanner.scan_file("suspicious_file.exe")
batch_result = scanner.batch_scan_directory("/path/to/scan")
```
