#!/usr/bin/env python3
"""
ReHabScanner - Advanced AI Threat Detection Engine
Implements modern AI/ML threat detection with neural networks, heuristic analysis,
and behavioral pattern recognition based on current antivirus AI techniques.
Integrates with AGI-OS AI systems for advanced threat detection.
"""

import os
import sys
import json
import logging
import threading
import time
import hashlib
import pickle
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
from collections import defaultdict, deque
from pathlib import Path
import struct

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('ReHabScanner')

class FeatureExtractor:
    """Advanced feature extraction for malware detection"""

    def __init__(self):
        self.pe_features = []
        self.behavioral_features = []
        self.static_features = []
        self.dynamic_features = []

    def extract_file_features(self, file_path: str) -> Dict[str, Any]:
        """Extract comprehensive features from file for AI analysis"""
        features = {
            'file_path': file_path,
            'static_features': {},
            'pe_features': {},
            'entropy_features': {},
            'string_features': {},
            'header_features': {}
        }

        try:
            if not os.path.exists(file_path):
                return {'error': 'File not found'}

            # Extract static features
            features['static_features'] = self._extract_static_features(file_path)

            # Extract PE features if Windows executable
            if file_path.lower().endswith(('.exe', '.dll', '.sys')):
                features['pe_features'] = self._extract_pe_features(file_path)

            # Extract entropy features
            features['entropy_features'] = self._extract_entropy_features(file_path)

            # Extract string features
            features['string_features'] = self._extract_string_features(file_path)

            # Extract header features
            features['header_features'] = self._extract_header_features(file_path)

        except Exception as e:
            logger.error(f"Feature extraction error for {file_path}: {e}")
            features['error'] = str(e)

        return features

    def _extract_static_features(self, file_path: str) -> Dict[str, Any]:
        """Extract static file features"""
        try:
            stat_info = os.stat(file_path)

            return {
                'file_size': stat_info.st_size,
                'creation_time': stat_info.st_ctime,
                'modification_time': stat_info.st_mtime,
                'access_time': stat_info.st_atime,
                'file_extension': Path(file_path).suffix.lower(),
                'file_name_length': len(os.path.basename(file_path)),
                'path_depth': len(Path(file_path).parts),
                'is_hidden': os.path.basename(file_path).startswith('.'),
                'permissions': oct(stat_info.st_mode)[-3:]
            }
        except Exception as e:
            logger.error(f"Static feature extraction error: {e}")
            return {}

    def _extract_pe_features(self, file_path: str) -> Dict[str, Any]:
        """Extract PE (Portable Executable) features"""
        pe_features = {
            'is_pe': False,
            'sections': [],
            'imports': [],
            'exports': [],
            'resources': []
        }

        try:
            with open(file_path, 'rb') as f:
                # Read DOS header
                dos_header = f.read(64)
                if len(dos_header) >= 2 and dos_header[:2] == b'MZ':
                    pe_features['is_pe'] = True
                    pe_features['dos_signature'] = 'MZ'

                    # Extract basic PE information
                    if len(dos_header) >= 60:
                        pe_offset = struct.unpack('<I', dos_header[60:64])[0]
                        f.seek(pe_offset)
                        pe_signature = f.read(4)

                        if pe_signature == b'PE\x00\x00':
                            pe_features['pe_signature'] = 'PE'

                            # Read COFF header
                            coff_header = f.read(20)
                            if len(coff_header) >= 20:
                                machine, num_sections, timestamp = struct.unpack('<HHI', coff_header[:8])
                                pe_features['machine_type'] = machine
                                pe_features['num_sections'] = num_sections
                                pe_features['timestamp'] = timestamp

                                # Read optional header
                                optional_header_size = struct.unpack('<H', coff_header[16:18])[0]
                                if optional_header_size > 0:
                                    optional_header = f.read(optional_header_size)
                                    if len(optional_header) >= 2:
                                        magic = struct.unpack('<H', optional_header[:2])[0]
                                        pe_features['pe_type'] = '32-bit' if magic == 0x10b else '64-bit'

        except Exception as e:
            logger.error(f"PE feature extraction error: {e}")

        return pe_features

    def _extract_entropy_features(self, file_path: str) -> Dict[str, Any]:
        """Extract entropy-based features"""
        entropy_features = {
            'overall_entropy': 0.0,
            'section_entropies': [],
            'high_entropy_sections': 0,
            'entropy_variance': 0.0
        }

        try:
            with open(file_path, 'rb') as f:
                data = f.read()

            if data:
                # Calculate overall entropy
                entropy_features['overall_entropy'] = self._calculate_entropy(data)

                # Calculate entropy for sections (1KB chunks)
                chunk_size = 1024
                section_entropies = []

                for i in range(0, len(data), chunk_size):
                    chunk = data[i:i + chunk_size]
                    if len(chunk) > 0:
                        entropy = self._calculate_entropy(chunk)
                        section_entropies.append(entropy)

                        # Count high entropy sections (potential packed/encrypted content)
                        if entropy > 7.5:  # High entropy threshold
                            entropy_features['high_entropy_sections'] += 1

                entropy_features['section_entropies'] = section_entropies

                # Calculate entropy variance
                if len(section_entropies) > 1:
                    mean_entropy = sum(section_entropies) / len(section_entropies)
                    variance = sum((e - mean_entropy) ** 2 for e in section_entropies) / len(section_entropies)
                    entropy_features['entropy_variance'] = variance

        except Exception as e:
            logger.error(f"Entropy feature extraction error: {e}")

        return entropy_features

    def _calculate_entropy(self, data: bytes) -> float:
        """Calculate Shannon entropy of data"""
        if not data:
            return 0.0

        # Count byte frequencies
        byte_counts = defaultdict(int)
        for byte in data:
            byte_counts[byte] += 1

        # Calculate entropy
        entropy = 0.0
        data_len = len(data)

        for count in byte_counts.values():
            probability = count / data_len
            if probability > 0:
                entropy -= probability * np.log2(probability)

        return entropy

    def _extract_string_features(self, file_path: str) -> Dict[str, Any]:
        """Extract string-based features"""
        string_features = {
            'printable_strings': [],
            'suspicious_strings': [],
            'url_count': 0,
            'ip_count': 0,
            'registry_key_count': 0,
            'api_call_count': 0
        }

        try:
            with open(file_path, 'rb') as f:
                data = f.read()

            # Extract printable strings
            strings = self._extract_printable_strings(data)
            string_features['printable_strings'] = strings[:100]  # Limit for performance

            # Analyze strings for suspicious patterns
            suspicious_patterns = [
                'cmd.exe', 'powershell', 'rundll32', 'regsvr32',
                'CreateProcess', 'WriteProcessMemory', 'VirtualAlloc',
                'GetProcAddress', 'LoadLibrary', 'ShellExecute',
                'http://', 'https://', 'ftp://', '.onion',
                'HKEY_', 'SOFTWARE\\', 'CurrentVersion\\Run',
                'temp', 'tmp', 'appdata', 'startup'
            ]

            for string in strings:
                string_lower = string.lower()
                for pattern in suspicious_patterns:
                    if pattern.lower() in string_lower:
                        string_features['suspicious_strings'].append(string)

                        # Count specific types
                        if pattern.lower() in ['http://', 'https://', 'ftp://']:
                            string_features['url_count'] += 1
                        elif pattern.lower().startswith('hkey_'):
                            string_features['registry_key_count'] += 1
                        elif pattern in ['CreateProcess', 'WriteProcessMemory', 'VirtualAlloc']:
                            string_features['api_call_count'] += 1

            # Count IP addresses (simple pattern)
            import re
            ip_pattern = r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'
            for string in strings:
                matches = re.findall(ip_pattern, string)
                string_features['ip_count'] += len(matches)

        except Exception as e:
            logger.error(f"String feature extraction error: {e}")

        return string_features

    def _extract_printable_strings(self, data: bytes, min_length: int = 4) -> List[str]:
        """Extract printable strings from binary data"""
        strings = []
        current_string = ""

        for byte in data:
            if 32 <= byte <= 126:  # Printable ASCII range
                current_string += chr(byte)
            else:
                if len(current_string) >= min_length:
                    strings.append(current_string)
                current_string = ""

        # Don't forget the last string
        if len(current_string) >= min_length:
            strings.append(current_string)

        return strings

    def _extract_header_features(self, file_path: str) -> Dict[str, Any]:
        """Extract file header features"""
        header_features = {
            'file_signature': '',
            'magic_bytes': '',
            'file_type': 'unknown'
        }

        try:
            with open(file_path, 'rb') as f:
                header = f.read(16)  # Read first 16 bytes

            if len(header) >= 2:
                magic_bytes = header[:4].hex().upper()
                header_features['magic_bytes'] = magic_bytes

                # Identify file type by magic bytes
                magic_signatures = {
                    'MZ': 'PE Executable',
                    '7F454C46': 'ELF Executable',
                    'CAFEBABE': 'Java Class',
                    '504B0304': 'ZIP Archive',
                    '52617221': 'RAR Archive',
                    '89504E47': 'PNG Image',
                    'FFD8FF': 'JPEG Image',
                    '25504446': 'PDF Document'
                }

                for signature, file_type in magic_signatures.items():
                    if magic_bytes.startswith(signature):
                        header_features['file_type'] = file_type
                        header_features['file_signature'] = signature
                        break

        except Exception as e:
            logger.error(f"Header feature extraction error: {e}")

        return header_features

class MLThreatClassifier:
    """Machine Learning-based threat classifier"""

    def __init__(self):
        self.model = None
        self.feature_scaler = None
        self.is_trained = False
        self.feature_names = []
        self.threat_categories = [
            'benign', 'trojan', 'virus', 'worm', 'adware', 
            'spyware', 'rootkit', 'backdoor', 'ransomware'
        ]

    def initialize_model(self):
        """Initialize ML model for threat classification"""
        try:
            # Create a simple neural network-like classifier
            self.model = SimpleNeuralNetwork()
            self.feature_scaler = FeatureScaler()

            # Define feature names for consistency
            self.feature_names = [
                'file_size', 'entropy', 'pe_sections', 'suspicious_strings',
                'api_calls', 'url_count', 'registry_keys', 'high_entropy_sections',
                'string_count', 'import_count', 'export_count', 'timestamp_anomaly'
            ]

            # Load pre-trained model if available
            self._load_pretrained_model()

            logger.info("ML threat classifier initialized")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize ML model: {e}")
            return False

    def _load_pretrained_model(self):
        """Load pre-trained model weights (simulated)"""
        # In a real implementation, this would load actual trained weights
        # For now, we'll simulate with random weights
        try:
            model_path = "../../assets/etc/ai/models/threat_classifier.pkl"
            if os.path.exists(model_path):
                # Simulate loading pre-trained model
                logger.info("Pre-trained model loaded")
                self.is_trained = True
            else:
                # Initialize with default parameters
                self._initialize_default_model()
                logger.info("Using default model parameters")
        except Exception as e:
            logger.warning(f"Model loading warning: {e}")
            self._initialize_default_model()

    def _initialize_default_model(self):
        """Initialize model with default parameters"""
        # Simulate trained model with default weights
        self.model.initialize_weights(len(self.feature_names), len(self.threat_categories))
        self.is_trained = True

    def extract_ml_features(self, file_features: Dict[str, Any]) -> List[float]:
        """Extract numerical features for ML model"""
        features = []

        try:
            # File size (normalized)
            file_size = file_features.get('static_features', {}).get('file_size', 0)
            features.append(min(file_size / 1000000, 100))  # Normalize to MB, cap at 100

            # Entropy
            entropy = file_features.get('entropy_features', {}).get('overall_entropy', 0)
            features.append(entropy)

            # PE sections count
            pe_sections = file_features.get('pe_features', {}).get('num_sections', 0)
            features.append(min(pe_sections, 50))  # Cap at 50

            # Suspicious strings count
            suspicious_count = len(file_features.get('string_features', {}).get('suspicious_strings', []))
            features.append(min(suspicious_count, 100))  # Cap at 100

            # API calls count
            api_count = file_features.get('string_features', {}).get('api_call_count', 0)
            features.append(min(api_count, 50))  # Cap at 50

            # URL count
            url_count = file_features.get('string_features', {}).get('url_count', 0)
            features.append(min(url_count, 20))  # Cap at 20

            # Registry keys count
            reg_count = file_features.get('string_features', {}).get('registry_key_count', 0)
            features.append(min(reg_count, 30))  # Cap at 30

            # High entropy sections
            high_entropy = file_features.get('entropy_features', {}).get('high_entropy_sections', 0)
            features.append(min(high_entropy, 20))  # Cap at 20

            # String count
            string_count = len(file_features.get('string_features', {}).get('printable_strings', []))
            features.append(min(string_count, 200))  # Cap at 200

            # Import/Export counts (simulated)
            import_count = len(file_features.get('pe_features', {}).get('imports', []))
            features.append(min(import_count, 100))  # Cap at 100

            export_count = len(file_features.get('pe_features', {}).get('exports', []))
            features.append(min(export_count, 50))  # Cap at 50

            # Timestamp anomaly (check if creation time is suspicious)
            creation_time = file_features.get('static_features', {}).get('creation_time', time.time())
            current_time = time.time()
            time_diff = abs(current_time - creation_time)
            # Anomaly if file is very new (< 1 hour) or very old (> 10 years)
            timestamp_anomaly = 1 if (time_diff < 3600 or time_diff > 315360000) else 0
            features.append(timestamp_anomaly)

            # Ensure we have the right number of features
            while len(features) < len(self.feature_names):
                features.append(0.0)

            return features[:len(self.feature_names)]

        except Exception as e:
            logger.error(f"ML feature extraction error: {e}")
            return [0.0] * len(self.feature_names)

    def classify_threat(self, file_features: Dict[str, Any]) -> Dict[str, Any]:
        """Classify threat using ML model"""
        if not self.is_trained:
            return {'error': 'Model not trained'}

        try:
            # Extract ML features
            ml_features = self.extract_ml_features(file_features)

            # Scale features
            scaled_features = self.feature_scaler.scale(ml_features)

            # Get prediction from model
            prediction = self.model.predict(scaled_features)

            # Convert to classification result
            max_prob_idx = prediction.index(max(prediction))
            predicted_class = self.threat_categories[max_prob_idx]
            confidence = max(prediction)

            return {
                'predicted_class': predicted_class,
                'confidence': confidence,
                'probabilities': dict(zip(self.threat_categories, prediction)),
                'is_malicious': predicted_class != 'benign',
                'risk_score': int(confidence * 100) if predicted_class != 'benign' else 0
            }

        except Exception as e:
            logger.error(f"Threat classification error: {e}")
            return {'error': str(e)}

class SimpleNeuralNetwork:
    """Simple neural network implementation for threat classification"""

    def __init__(self):
        self.weights_input_hidden = []
        self.weights_hidden_output = []
        self.bias_hidden = []
        self.bias_output = []

    def initialize_weights(self, input_size: int, output_size: int, hidden_size: int = 16):
        """Initialize network weights"""
        # Simulate weight initialization
        self.weights_input_hidden = [[0.1 * (i + j) % 1.0 for j in range(hidden_size)] 
                                   for i in range(input_size)]
        self.weights_hidden_output = [[0.1 * (i + j) % 1.0 for j in range(output_size)] 
                                    for i in range(hidden_size)]
        self.bias_hidden = [0.1] * hidden_size
        self.bias_output = [0.1] * output_size

    def sigmoid(self, x: float) -> float:
        """Sigmoid activation function"""
        try:
            return 1 / (1 + np.exp(-x))
        except OverflowError:
            return 0.0 if x < 0 else 1.0

    def predict(self, features: List[float]) -> List[float]:
        """Make prediction using the neural network"""
        try:
            # Forward pass through hidden layer
            hidden_layer = []
            for i in range(len(self.bias_hidden)):
                activation = self.bias_hidden[i]
                for j in range(len(features)):
                    activation += features[j] * self.weights_input_hidden[j][i]
                hidden_layer.append(self.sigmoid(activation))

            # Forward pass through output layer
            output_layer = []
            for i in range(len(self.bias_output)):
                activation = self.bias_output[i]
                for j in range(len(hidden_layer)):
                    activation += hidden_layer[j] * self.weights_hidden_output[j][i]
                output_layer.append(self.sigmoid(activation))

            # Normalize output to probabilities
            total = sum(output_layer)
            if total > 0:
                output_layer = [x / total for x in output_layer]

            return output_layer

        except Exception as e:
            logger.error(f"Neural network prediction error: {e}")
            return [0.1] * len(self.bias_output)  # Return uniform distribution

class FeatureScaler:
    """Simple feature scaler for ML preprocessing"""

    def __init__(self):
        self.feature_mins = []
        self.feature_maxs = []
        self.is_fitted = False

    def scale(self, features: List[float]) -> List[float]:
        """Scale features to [0, 1] range"""
        if not self.is_fitted:
            # Use default scaling ranges
            self._fit_default_ranges(features)

        scaled = []
        for i, feature in enumerate(features):
            if i < len(self.feature_mins) and i < len(self.feature_maxs):
                min_val = self.feature_mins[i]
                max_val = self.feature_maxs[i]
                if max_val > min_val:
                    scaled_val = (feature - min_val) / (max_val - min_val)
                    scaled.append(max(0, min(1, scaled_val)))  # Clamp to [0, 1]
                else:
                    scaled.append(0.5)  # Default middle value
            else:
                scaled.append(0.5)

        return scaled

    def _fit_default_ranges(self, features: List[float]):
        """Fit with default feature ranges"""
        # Default ranges based on typical malware analysis
        default_ranges = [
            (0, 100),    # file_size (MB)
            (0, 8),      # entropy
            (0, 50),     # pe_sections
            (0, 100),    # suspicious_strings
            (0, 50),     # api_calls
            (0, 20),     # url_count
            (0, 30),     # registry_keys
            (0, 20),     # high_entropy_sections
            (0, 200),    # string_count
            (0, 100),    # import_count
            (0, 50),     # export_count
            (0, 1)       # timestamp_anomaly
        ]

        self.feature_mins = [r[0] for r in default_ranges]
        self.feature_maxs = [r[1] for r in default_ranges]
        self.is_fitted = True

class HeuristicAnalysisEngine:
    """Advanced heuristic analysis engine"""

    def __init__(self):
        self.heuristic_rules = []
        self.behavior_patterns = {}
        self.suspicious_indicators = []

    def initialize_heuristics(self):
        """Initialize heuristic analysis rules"""
        try:
            self._setup_heuristic_rules()
            self._setup_behavior_patterns()
            self._setup_suspicious_indicators()
            logger.info("Heuristic analysis engine initialized")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize heuristics: {e}")
            return False

    def _setup_heuristic_rules(self):
        """Setup heuristic detection rules"""
        self.heuristic_rules = [
            {
                'name': 'high_entropy_executable',
                'description': 'Executable with unusually high entropy (possible packing/encryption)',
                'condition': lambda features: (
                    features.get('entropy_features', {}).get('overall_entropy', 0) > 7.5 and
                    features.get('pe_features', {}).get('is_pe', False)
                ),
                'severity': 'medium',
                'score': 30
            },
            {
                'name': 'suspicious_api_calls',
                'description': 'High number of suspicious API calls',
                'condition': lambda features: (
                    features.get('string_features', {}).get('api_call_count', 0) > 20
                ),
                'severity': 'high',
                'score': 50
            },
            {
                'name': 'network_indicators',
                'description': 'Contains network-related suspicious indicators',
                'condition': lambda features: (
                    features.get('string_features', {}).get('url_count', 0) > 5 or
                    features.get('string_features', {}).get('ip_count', 0) > 3
                ),
                'severity': 'medium',
                'score': 25
            },
            {
                'name': 'persistence_indicators',
                'description': 'Contains persistence mechanism indicators',
                'condition': lambda features: (
                    features.get('string_features', {}).get('registry_key_count', 0) > 5
                ),
                'severity': 'high',
                'score': 40
            },
            {
                'name': 'obfuscation_indicators',
                'description': 'Shows signs of code obfuscation',
                'condition': lambda features: (
                    features.get('entropy_features', {}).get('high_entropy_sections', 0) > 5 and
                    features.get('entropy_features', {}).get('entropy_variance', 0) > 2.0
                ),
                'severity': 'medium',
                'score': 35
            },
            {
                'name': 'suspicious_file_location',
                'description': 'File located in suspicious directory',
                'condition': lambda features: (
                    any(suspicious in features.get('file_path', '').lower() 
                        for suspicious in ['temp', 'tmp', 'appdata', 'startup'])
                ),
                'severity': 'low',
                'score': 15
            },
            {
                'name': 'unusual_file_size',
                'description': 'Unusual file size for file type',
                'condition': lambda features: (
                    features.get('static_features', {}).get('file_size', 0) < 1024 or  # Very small
                    features.get('static_features', {}).get('file_size', 0) > 100000000  # Very large (100MB)
                ),
                'severity': 'low',
                'score': 10
            },
            {
                'name': 'timestamp_anomaly',
                'description': 'Suspicious file timestamps',
                'condition': lambda features: self._check_timestamp_anomaly(features),
                'severity': 'low',
                'score': 20
            }
        ]

    def _check_timestamp_anomaly(self, features: Dict[str, Any]) -> bool:
        """Check for timestamp anomalies"""
        try:
            static_features = features.get('static_features', {})
            creation_time = static_features.get('creation_time', 0)
            modification_time = static_features.get('modification_time', 0)

            current_time = time.time()

            # Check if file is very new (created in last hour)
            if current_time - creation_time < 3600:
                return True

            # Check if creation time is in the future
            if creation_time > current_time + 3600:
                return True

            # Check if modification time is before creation time
            if modification_time < creation_time - 3600:
                return True

            return False
        except Exception:
            return False

    def _setup_behavior_patterns(self):
        """Setup behavioral analysis patterns"""
        self.behavior_patterns = {
            'file_system_manipulation': {
                'indicators': ['CreateFile', 'WriteFile', 'DeleteFile', 'MoveFile'],
                'threshold': 10,
                'severity': 'medium'
            },
            'process_manipulation': {
                'indicators': ['CreateProcess', 'OpenProcess', 'TerminateProcess'],
                'threshold': 5,
                'severity': 'high'
            },
            'registry_manipulation': {
                'indicators': ['RegCreateKey', 'RegSetValue', 'RegDeleteKey'],
                'threshold': 3,
                'severity': 'high'
            },
            'network_communication': {
                'indicators': ['socket', 'connect', 'send', 'recv', 'HttpSendRequest'],
                'threshold': 5,
                'severity': 'medium'
            },
            'memory_manipulation': {
                'indicators': ['VirtualAlloc', 'VirtualProtect', 'WriteProcessMemory'],
                'threshold': 3,
                'severity': 'critical'
            }
        }

    def _setup_suspicious_indicators(self):
        """Setup suspicious string indicators"""
        self.suspicious_indicators = [
            # Command execution
            'cmd.exe', 'powershell.exe', 'wscript.exe', 'cscript.exe',
            # System manipulation
            'rundll32.exe', 'regsvr32.exe', 'schtasks.exe', 'at.exe',
            # Network tools
            'netsh.exe', 'ping.exe', 'telnet.exe', 'ftp.exe',
            # Suspicious APIs
            'CreateRemoteThread', 'SetWindowsHook', 'GetAsyncKeyState',
            # Crypto/encoding
            'CryptAcquireContext', 'CryptEncrypt', 'CryptDecrypt',
            # Anti-analysis
            'IsDebuggerPresent', 'CheckRemoteDebuggerPresent', 'GetTickCount'
        ]

    def perform_heuristic_analysis(self, file_features: Dict[str, Any]) -> Dict[str, Any]:
        """Perform comprehensive heuristic analysis"""
        analysis_result = {
            'heuristic_score': 0,
            'triggered_rules': [],
            'behavior_analysis': {},
            'risk_level': 'low',
            'recommendations': []
        }

        try:
            # Apply heuristic rules
            for rule in self.heuristic_rules:
                try:
                    if rule['condition'](file_features):
                        analysis_result['triggered_rules'].append({
                            'name': rule['name'],
                            'description': rule['description'],
                            'severity': rule['severity'],
                            'score': rule['score']
                        })
                        analysis_result['heuristic_score'] += rule['score']
                except Exception as e:
                    logger.error(f"Heuristic rule {rule['name']} failed: {e}")

            # Analyze behavioral patterns
            analysis_result['behavior_analysis'] = self._analyze_behavioral_patterns(file_features)

            # Determine risk level
            analysis_result['risk_level'] = self._calculate_risk_level(analysis_result['heuristic_score'])

            # Generate recommendations
            analysis_result['recommendations'] = self._generate_recommendations(analysis_result)

        except Exception as e:
            logger.error(f"Heuristic analysis error: {e}")
            analysis_result['error'] = str(e)

        return analysis_result

    def _analyze_behavioral_patterns(self, file_features: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze behavioral patterns in file"""
        behavior_analysis = {}

        try:
            suspicious_strings = file_features.get('string_features', {}).get('suspicious_strings', [])

            for pattern_name, pattern_info in self.behavior_patterns.items():
                matches = 0
                matched_indicators = []

                for string in suspicious_strings:
                    for indicator in pattern_info['indicators']:
                        if indicator.lower() in string.lower():
                            matches += 1
                            matched_indicators.append(indicator)

                if matches >= pattern_info['threshold']:
                    behavior_analysis[pattern_name] = {
                        'matches': matches,
                        'threshold': pattern_info['threshold'],
                        'severity': pattern_info['severity'],
                        'indicators': matched_indicators,
                        'triggered': True
                    }
                elif matches > 0:
                    behavior_analysis[pattern_name] = {
                        'matches': matches,
                        'threshold': pattern_info['threshold'],
                        'severity': pattern_info['severity'],
                        'indicators': matched_indicators,
                        'triggered': False
                    }

        except Exception as e:
            logger.error(f"Behavioral pattern analysis error: {e}")

        return behavior_analysis

    def _calculate_risk_level(self, heuristic_score: int) -> str:
        """Calculate risk level based on heuristic score"""
        if heuristic_score >= 80:
            return 'critical'
        elif heuristic_score >= 60:
            return 'high'
        elif heuristic_score >= 30:
            return 'medium'
        else:
            return 'low'

    def _generate_recommendations(self, analysis_result: Dict[str, Any]) -> List[str]:
        """Generate security recommendations"""
        recommendations = []

        risk_level = analysis_result['risk_level']
        triggered_rules = analysis_result['triggered_rules']

        if risk_level in ['critical', 'high']:
            recommendations.append("Quarantine file immediately")
            recommendations.append("Perform deep system scan")
            recommendations.append("Monitor system for signs of compromise")

        if any(rule['name'] == 'memory_manipulation' for rule in triggered_rules):
            recommendations.append("Check for process injection attempts")

        if any(rule['name'] == 'network_indicators' for rule in triggered_rules):
            recommendations.append("Monitor network traffic for suspicious connections")

        if any(rule['name'] == 'persistence_indicators' for rule in triggered_rules):
            recommendations.append("Check system startup locations and registry")

        if not recommendations:
            recommendations.append("Continue monitoring - file appears benign")

        return recommendations

class ReHabScanner:
    """Enhanced ReHabScanner with AI-powered threat detection"""

    def __init__(self, config_path: str = "config.json"):
        """Initialize ReHabScanner with AI capabilities"""
        self.config = self._load_config(config_path)
        self.ai_interface = None
        self.scanning_active = False

        # Initialize AI components
        self.feature_extractor = FeatureExtractor()
        self.ml_classifier = MLThreatClassifier()
        self.heuristic_engine = HeuristicAnalysisEngine()

        self.scan_history = deque(maxlen=1000)
        self.threat_database = {}
        self.learning_mode = True

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                logger.info("Configuration loaded successfully")
                return config
        except FileNotFoundError:
            logger.warning("Config file not found, using defaults")
            return self._get_default_config()
        except json.JSONDecodeError as e:
            logger.error(f"Config file parsing error: {e}")
            return self._get_default_config()

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "ai_detection": {
                "ml_classification": True,
                "heuristic_analysis": True,
                "behavioral_analysis": True,
                "feature_extraction": True
            },
            "thresholds": {
                "ml_confidence": 0.7,
                "heuristic_score": 50,
                "risk_threshold": 60
            },
            "integration": {
                "agi_ai_models": True,
                "symbolic_computing": True,
                "learning_system": True
            }
        }

    def initialize_ai_detection(self) -> bool:
        """Initialize AI-powered threat detection"""
        logger.info("Initializing ReHabScanner AI detection...")

        try:
            # Connect to AGI-OS AI systems
            self._connect_to_agi_ai_systems()

            # Initialize ML classifier
            if self.config.get("ai_detection", {}).get("ml_classification", True):
                if not self.ml_classifier.initialize_model():
                    logger.error("Failed to initialize ML classifier")
                    return False

            # Initialize heuristic engine
            if self.config.get("ai_detection", {}).get("heuristic_analysis", True):
                if not self.heuristic_engine.initialize_heuristics():
                    logger.error("Failed to initialize heuristic engine")
                    return False

            self.scanning_active = True
            logger.info("ReHabScanner AI detection initialized successfully")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize AI detection: {e}")
            return False

    def _connect_to_agi_ai_systems(self):
        """Connect to AGI-OS AI systems"""
        ai_models_path = "../../assets/etc/ai/models/"
        if os.path.exists(ai_models_path):
            logger.info("Connected to AGI-OS AI models")
            self.ai_interface = {
                'path': ai_models_path,
                'connected': True,
                'capabilities': ['threat_classification', 'pattern_recognition', 'learning']
            }
        else:
            logger.warning("AGI-OS AI models not found")

    def scan_file(self, file_path: str) -> Dict[str, Any]:
        """Perform comprehensive AI-powered file scan"""
        logger.info(f"Starting AI scan of file: {file_path}")

        scan_result = {
            'scan_id': hashlib.md5(f"{file_path}{datetime.now()}".encode()).hexdigest()[:8],
            'file_path': file_path,
            'timestamp': datetime.now().isoformat(),
            'feature_extraction': {},
            'ml_classification': {},
            'heuristic_analysis': {},
            'final_verdict': {},
            'recommendations': []
        }

        try:
            if not os.path.exists(file_path):
                scan_result['error'] = 'File not found'
                return scan_result

            # Step 1: Feature extraction
            logger.info("Extracting file features...")
            scan_result['feature_extraction'] = self.feature_extractor.extract_file_features(file_path)

            if 'error' in scan_result['feature_extraction']:
                scan_result['error'] = f"Feature extraction failed: {scan_result['feature_extraction']['error']}"
                return scan_result

            # Step 2: ML classification
            if self.config.get("ai_detection", {}).get("ml_classification", True):
                logger.info("Performing ML classification...")
                scan_result['ml_classification'] = self.ml_classifier.classify_threat(
                    scan_result['feature_extraction']
                )

            # Step 3: Heuristic analysis
            if self.config.get("ai_detection", {}).get("heuristic_analysis", True):
                logger.info("Performing heuristic analysis...")
                scan_result['heuristic_analysis'] = self.heuristic_engine.perform_heuristic_analysis(
                    scan_result['feature_extraction']
                )

            # Step 4: Generate final verdict
            scan_result['final_verdict'] = self._generate_final_verdict(scan_result)

            # Step 5: Generate recommendations
            scan_result['recommendations'] = self._generate_scan_recommendations(scan_result)

            # Store scan result
            self.scan_history.append(scan_result)

            logger.info(f"Scan completed: {scan_result['final_verdict'].get('verdict', 'unknown')}")

        except Exception as e:
            logger.error(f"File scan error: {e}")
            scan_result['error'] = str(e)

        return scan_result

    def _generate_final_verdict(self, scan_result: Dict[str, Any]) -> Dict[str, Any]:
        """Generate final verdict based on all analysis results"""
        verdict = {
            'verdict': 'benign',
            'confidence': 0.0,
            'risk_score': 0,
            'threat_type': 'none',
            'is_malicious': False
        }

        try:
            ml_result = scan_result.get('ml_classification', {})
            heuristic_result = scan_result.get('heuristic_analysis', {})

            # Combine ML and heuristic scores
            ml_confidence = ml_result.get('confidence', 0.0)
            ml_is_malicious = ml_result.get('is_malicious', False)
            ml_risk_score = ml_result.get('risk_score', 0)

            heuristic_score = heuristic_result.get('heuristic_score', 0)
            heuristic_risk = heuristic_result.get('risk_level', 'low')

            # Calculate combined risk score
            combined_risk_score = int((ml_risk_score + heuristic_score) / 2)

            # Determine final verdict
            risk_threshold = self.config.get("thresholds", {}).get("risk_threshold", 60)
            ml_threshold = self.config.get("thresholds", {}).get("ml_confidence", 0.7)

            if (ml_is_malicious and ml_confidence >= ml_threshold) or heuristic_score >= 80:
                verdict['verdict'] = 'malicious'
                verdict['is_malicious'] = True
                verdict['threat_type'] = ml_result.get('predicted_class', 'unknown')
            elif combined_risk_score >= risk_threshold:
                verdict['verdict'] = 'suspicious'
                verdict['is_malicious'] = True
                verdict['threat_type'] = 'potentially_unwanted'
            else:
                verdict['verdict'] = 'benign'
                verdict['is_malicious'] = False

            verdict['confidence'] = max(ml_confidence, heuristic_score / 100.0)
            verdict['risk_score'] = combined_risk_score

        except Exception as e:
            logger.error(f"Final verdict generation error: {e}")
            verdict['error'] = str(e)

        return verdict

    def _generate_scan_recommendations(self, scan_result: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on scan results"""
        recommendations = []

        try:
            final_verdict = scan_result.get('final_verdict', {})
            heuristic_analysis = scan_result.get('heuristic_analysis', {})

            if final_verdict.get('is_malicious', False):
                recommendations.append("File identified as malicious - quarantine immediately")
                recommendations.append("Perform full system scan")
                recommendations.append("Check for signs of system compromise")

            # Add heuristic recommendations
            heuristic_recommendations = heuristic_analysis.get('recommendations', [])
            recommendations.extend(heuristic_recommendations)

            # Add specific recommendations based on threat type
            threat_type = final_verdict.get('threat_type', '')
            if threat_type == 'ransomware':
                recommendations.append("Check for encrypted files and backup integrity")
            elif threat_type == 'trojan':
                recommendations.append("Monitor for unauthorized network connections")
            elif threat_type == 'rootkit':
                recommendations.append("Perform kernel-level integrity check")

            if not recommendations:
                recommendations.append("File appears safe - continue normal operations")

        except Exception as e:
            logger.error(f"Recommendation generation error: {e}")

        return recommendations

    def batch_scan(self, file_paths: List[str]) -> Dict[str, Any]:
        """Perform batch scanning of multiple files"""
        logger.info(f"Starting batch scan of {len(file_paths)} files")

        batch_result = {
            'batch_id': hashlib.md5(f"batch_{datetime.now()}".encode()).hexdigest()[:8],
            'timestamp': datetime.now().isoformat(),
            'total_files': len(file_paths),
            'scanned_files': 0,
            'malicious_files': 0,
            'suspicious_files': 0,
            'scan_results': [],
            'summary': {}
        }

        try:
            for file_path in file_paths:
                try:
                    scan_result = self.scan_file(file_path)
                    batch_result['scan_results'].append(scan_result)
                    batch_result['scanned_files'] += 1

                    # Count threats
                    if scan_result.get('final_verdict', {}).get('verdict') == 'malicious':
                        batch_result['malicious_files'] += 1
                    elif scan_result.get('final_verdict', {}).get('verdict') == 'suspicious':
                        batch_result['suspicious_files'] += 1

                except Exception as e:
                    logger.error(f"Batch scan error for {file_path}: {e}")
                    continue

            # Generate summary
            batch_result['summary'] = {
                'scan_completion_rate': batch_result['scanned_files'] / batch_result['total_files'],
                'threat_detection_rate': (batch_result['malicious_files'] + batch_result['suspicious_files']) / max(batch_result['scanned_files'], 1),
                'clean_files': batch_result['scanned_files'] - batch_result['malicious_files'] - batch_result['suspicious_files']
            }

            logger.info(f"Batch scan completed: {batch_result['scanned_files']}/{batch_result['total_files']} files scanned, "
                       f"{batch_result['malicious_files']} malicious, {batch_result['suspicious_files']} suspicious")

        except Exception as e:
            logger.error(f"Batch scan error: {e}")
            batch_result['error'] = str(e)

        return batch_result

    def get_scan_statistics(self) -> Dict[str, Any]:
        """Get scanning statistics and performance metrics"""
        stats = {
            'total_scans': len(self.scan_history),
            'malicious_detections': 0,
            'suspicious_detections': 0,
            'clean_files': 0,
            'average_scan_time': 0,
            'threat_types': defaultdict(int),
            'detection_accuracy': 0
        }

        try:
            if self.scan_history:
                for scan in self.scan_history:
                    verdict = scan.get('final_verdict', {}).get('verdict', 'unknown')
                    if verdict == 'malicious':
                        stats['malicious_detections'] += 1
                        threat_type = scan.get('final_verdict', {}).get('threat_type', 'unknown')
                        stats['threat_types'][threat_type] += 1
                    elif verdict == 'suspicious':
                        stats['suspicious_detections'] += 1
                    elif verdict == 'benign':
                        stats['clean_files'] += 1

                # Calculate detection rate
                total_threats = stats['malicious_detections'] + stats['suspicious_detections']
                stats['detection_accuracy'] = total_threats / len(self.scan_history) if self.scan_history else 0

        except Exception as e:
            logger.error(f"Statistics calculation error: {e}")
            stats['error'] = str(e)

        return stats

if __name__ == "__main__":
    # Initialize and test ReHabScanner
    scanner = ReHabScanner()

    if scanner.initialize_ai_detection():
        print("ReHabScanner AI detection initialized successfully")

        # Test scan on a sample file (if available)
        test_files = ['/bin/ls', '/usr/bin/python3', './source/ReHabScanner/main.py']
        available_files = [f for f in test_files if os.path.exists(f)]

        if available_files:
            print(f"\nTesting scan on: {available_files[0]}")
            scan_result = scanner.scan_file(available_files[0])
            print("\nScan Results:")
            print(json.dumps({
                'file_path': scan_result['file_path'],
                'final_verdict': scan_result['final_verdict'],
                'recommendations': scan_result['recommendations']
            }, indent=2))

        # Show statistics
        stats = scanner.get_scan_statistics()
        print("\nScanning Statistics:")
        print(json.dumps(stats, indent=2))

    else:
        print("Failed to initialize ReHabScanner AI detection")
