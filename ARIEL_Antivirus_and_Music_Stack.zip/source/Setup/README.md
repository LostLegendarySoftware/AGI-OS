# ARIEL Antivirus System - Setup Module

## Overview

The Setup module provides comprehensive installation and management capabilities for the ARIEL antivirus system, including cross-platform installers, daemon services, and centralized logging infrastructure.

## Components

### Core Components

1. **main.py** - Enhanced setup system with comprehensive installation capabilities
2. **daemon.py** - PsiGuard daemon for persistent system health monitoring
3. **logging_manager.py** - Centralized logging infrastructure for all modules
4. **windows_installer.py** - Windows-specific installation system
5. **linux_installer.py** - Linux-specific installation system with systemd integration

### Installation Scripts

1. **rehab_rehype_installer.sh** - Linux shell script installer
2. **rehab_rehype_installer.bat** - Windows batch script installer

### Configuration Files

1. **setup_config.json** - Main setup configuration
2. **daemon_config.json** - Daemon-specific configuration
3. **logging_config.json** - Logging system configuration

## Features

### Installation System
- Cross-platform installation (Windows/Linux)
- Dependency checking and installation
- System integration and service registration
- Module dependency resolution
- Enhanced pre-installation validation

### Daemon Management
- PsiGuard daemon for continuous monitoring
- Automatic module health checking
- Failed module restart capabilities
- Resource monitoring and alerting
- Service lifecycle management

### Logging Infrastructure
- Centralized logging for all 14 modules
- Log rotation and archival policies
- Real-time log monitoring
- Security event logging
- Performance metrics logging
- Audit trail logging

### System Integration
- OS-level service registration
- Startup configuration
- Firewall rule configuration
- Registry/configuration management
- User account and permission management

## Installation

### Linux Installation

```bash
# Make installer executable
chmod +x ./source/Setup/rehab_rehype_installer.sh

# Run installer with sudo
sudo ./source/Setup/rehab_rehype_installer.sh
```

### Windows Installation

```cmd
REM Run as Administrator
./source/Setup/rehab_rehype_installer.bat
```

### Manual Installation

```python
# Python installation
python3 ./source/Setup/main.py
```

## Service Management

### Linux (systemd)

```bash
# Start service
sudo systemctl start psiguard

# Stop service
sudo systemctl stop psiguard

# Check status
sudo systemctl status psiguard

# Enable auto-start
sudo systemctl enable psiguard

# View logs
sudo journalctl -u psiguard -f
```

### Windows (Task Scheduler/Service)

```cmd
# Start service
schtasks /run /tn "ARIEL_PsiGuard_Service"

# Check service status
sc query PsiGuardService
```

## Daemon Management

### Start Daemon
```python
from Setup.daemon import PsiGuardDaemon

daemon = PsiGuardDaemon()
daemon.start()
```

### Get Daemon Status
```python
status = daemon.get_status()
print(json.dumps(status, indent=2))
```

### Stop Daemon
```python
daemon.stop()
```

## Logging System

### Get Module Logger
```python
from Setup.logging_manager import get_module_logger

logger = get_module_logger("YourModule")
logger.info("Your log message")
```

### Log Security Events
```python
from Setup.logging_manager import get_logging_manager

manager = get_logging_manager()
manager.log_security_event("event_type", {"details": "data"}, "INFO")
```

### Log Performance Metrics
```python
manager.log_performance_metric("metric_name", 42.0, "unit", "module")
```

### Log Audit Events
```python
manager.log_audit_event("action", "user", "resource", "result", {"details": "data"})
```

## Configuration

### Module Configuration

Edit `setup_config.json` to configure modules:

```json
{
  "modules": {
    "ModuleName": {
      "enabled": true,
      "auto_start": true,
      "priority": "normal",
      "dependencies": ["RequiredModule"]
    }
  }
}
```

### Daemon Configuration

Edit `daemon_config.json` to configure daemon behavior:

```json
{
  "monitoring": {
    "health_check_interval": 30,
    "auto_restart": true,
    "max_restart_attempts": 3
  }
}
```

### Logging Configuration

Edit `logging_config.json` to configure logging:

```json
{
  "global": {
    "level": "INFO",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  }
}
```

## Module Integration

### Adding New Modules

1. Add module to `setup_config.json`
2. Configure dependencies
3. Set priority and auto-start preferences
4. Restart daemon to pick up changes

### Module Requirements

Each module should have:
- `main.py` - Main module file
- `config.json` - Module configuration
- `README.md` - Module documentation

## Troubleshooting

### Installation Issues

1. Check pre-installation requirements
2. Verify Python version (3.7+)
3. Ensure sufficient disk space (2GB)
4. Check administrator/root privileges

### Service Issues

1. Check service status
2. Review log files in `/var/log/ariel_antivirus/` (Linux) or installation directory (Windows)
3. Verify module dependencies
4. Check resource usage

### Logging Issues

1. Check log directory permissions
2. Verify disk space for logs
3. Check log rotation configuration
4. Review logging level settings

## Security Considerations

- All services run with minimal required privileges
- Log files are protected with appropriate permissions
- Audit logging tracks all system changes
- Security events are monitored and logged
- Access control is enforced for configuration files

## Performance Optimization

- Resource monitoring prevents system overload
- Module priorities ensure critical components get resources
- Log rotation prevents disk space issues
- Performance metrics help identify bottlenecks
- Auto-optimization features improve system performance

## Support

For technical support:
1. Check log files for error messages
2. Review configuration files for issues
3. Verify system requirements
4. Check module dependencies
5. Contact support with installation logs

## Version History

- v1.0.0 - Initial release with basic installation
- v1.0.0-enhanced - Added daemon management, centralized logging, and system integration

## License

ARIEL Antivirus System Setup Module
Copyright (c) 2024 ARIEL Project
