#!/usr/bin/env python3
"""
PsiGuard_Daemon - Persistent System Health Monitoring and Service Management
Cross-platform daemon service for the ARIEL antivirus system
"""

import os
import sys
import time
import json
import logging
import threading
import subprocess
import platform
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
import signal
import psutil

class PsiGuardDaemon:
    def __init__(self, config_path: str = "daemon_config.json"):
        """Initialize PsiGuard daemon"""
        self.config = self._load_config(config_path)
        self.platform = platform.system().lower()
        self.running = False
        self.modules = [
            "PhiGuard_Core", "WardenMonitor", "ReHabScanner", "SigStrat",
            "AVxSentinel", "ReDriverAI", "PsiPlayGuard", "PsiShield",
            "BiometricCore", "HeartRateMonitor", "VoiceApproval", 
            "GestureRecognition", "rehab_rehype_ai"
        ]
        self.module_processes = {}
        self.health_check_interval = 30  # seconds
        self.logger = self._setup_logging()
        self.setup_signal_handlers()

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load daemon configuration"""
        default_config = {
            "monitoring": {
                "health_check_interval": 30,
                "auto_restart": True,
                "max_restart_attempts": 3,
                "resource_monitoring": True
            },
            "logging": {
                "level": "INFO",
                "max_file_size": "10MB",
                "backup_count": 5
            },
            "modules": {module: {"enabled": True, "auto_start": True} 
                      for module in self.modules if hasattr(self, 'modules')}
        }

        try:
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    config = json.load(f)
                # Merge with defaults
                for key, value in default_config.items():
                    if key not in config:
                        config[key] = value
                return config
            else:
                return default_config
        except Exception as e:
            print(f"Error loading config: {e}")
            return default_config

    def _setup_logging(self) -> logging.Logger:
        """Setup daemon logging"""
        log_dir = "../../logs/daemon"
        os.makedirs(log_dir, exist_ok=True)

        logger = logging.getLogger("PsiGuardDaemon")
        logger.setLevel(getattr(logging, self.config.get("logging", {}).get("level", "INFO")))

        # File handler with rotation
        from logging.handlers import RotatingFileHandler
        log_file = os.path.join(log_dir, "psiguard_daemon.log")
        file_handler = RotatingFileHandler(
            log_file, 
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5
        )

        # Console handler
        console_handler = logging.StreamHandler()

        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

        return logger

    def setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown"""
        def signal_handler(signum, frame):
            self.logger.info(f"Received signal {signum}, shutting down...")
            self.stop()
            sys.exit(0)

        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        if hasattr(signal, 'SIGHUP'):
            signal.signal(signal.SIGHUP, signal_handler)

    def start(self):
        """Start the daemon"""
        self.logger.info("Starting PsiGuard Daemon...")
        self.running = True

        # Start enabled modules
        self._start_modules()

        # Start monitoring thread
        monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        monitor_thread.start()

        # Main daemon loop
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            self.stop()

    def stop(self):
        """Stop the daemon"""
        self.logger.info("Stopping PsiGuard Daemon...")
        self.running = False

        # Stop all modules
        self._stop_modules()

    def restart(self):
        """Restart the daemon"""
        self.logger.info("Restarting PsiGuard Daemon...")
        self.stop()
        time.sleep(2)
        self.start()

    def _start_modules(self):
        """Start all enabled modules"""
        for module in self.modules:
            if self.config.get("modules", {}).get(module, {}).get("enabled", True):
                self._start_module(module)

    def _start_module(self, module_name: str) -> bool:
        """Start individual module"""
        try:
            module_path = f"../{module_name}/main.py"
            if os.path.exists(module_path):
                process = subprocess.Popen([
                    sys.executable, module_path
                ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

                self.module_processes[module_name] = {
                    "process": process,
                    "start_time": datetime.now(),
                    "restart_count": 0
                }

                self.logger.info(f"Started module: {module_name} (PID: {process.pid})")
                return True
            else:
                self.logger.warning(f"Module not found: {module_path}")
                return False
        except Exception as e:
            self.logger.error(f"Failed to start module {module_name}: {e}")
            return False

    def _stop_modules(self):
        """Stop all running modules"""
        for module_name, module_info in self.module_processes.items():
            try:
                process = module_info["process"]
                if process.poll() is None:  # Process is still running
                    process.terminate()
                    # Wait for graceful shutdown
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                    self.logger.info(f"Stopped module: {module_name}")
            except Exception as e:
                self.logger.error(f"Error stopping module {module_name}: {e}")

        self.module_processes.clear()

    def _monitor_loop(self):
        """Main monitoring loop"""
        while self.running:
            try:
                self._health_check()
                self._resource_monitoring()
                time.sleep(self.health_check_interval)
            except Exception as e:
                self.logger.error(f"Monitoring error: {e}")

    def _health_check(self):
        """Perform health checks on all modules"""
        for module_name, module_info in list(self.module_processes.items()):
            process = module_info["process"]

            if process.poll() is not None:  # Process has terminated
                self.logger.warning(f"Module {module_name} has stopped unexpectedly")

                if self.config.get("monitoring", {}).get("auto_restart", True):
                    restart_count = module_info.get("restart_count", 0)
                    max_attempts = self.config.get("monitoring", {}).get("max_restart_attempts", 3)

                    if restart_count < max_attempts:
                        self.logger.info(f"Attempting to restart {module_name} (attempt {restart_count + 1})")
                        if self._start_module(module_name):
                            self.module_processes[module_name]["restart_count"] = restart_count + 1
                    else:
                        self.logger.error(f"Max restart attempts reached for {module_name}")
                        del self.module_processes[module_name]

    def _resource_monitoring(self):
        """Monitor system resources"""
        if not self.config.get("monitoring", {}).get("resource_monitoring", True):
            return

        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)

            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent

            # Disk usage
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent

            # Log resource usage if high
            if cpu_percent > 80:
                self.logger.warning(f"High CPU usage: {cpu_percent}%")
            if memory_percent > 80:
                self.logger.warning(f"High memory usage: {memory_percent}%")
            if disk_percent > 90:
                self.logger.warning(f"High disk usage: {disk_percent}%")

        except Exception as e:
            self.logger.error(f"Resource monitoring error: {e}")

    def get_status(self) -> Dict[str, Any]:
        """Get daemon status"""
        return {
            "running": self.running,
            "platform": self.platform,
            "modules": {
                name: {
                    "running": info["process"].poll() is None,
                    "pid": info["process"].pid,
                    "start_time": info["start_time"].isoformat(),
                    "restart_count": info.get("restart_count", 0)
                }
                for name, info in self.module_processes.items()
            },
            "timestamp": datetime.now().isoformat()
        }

if __name__ == "__main__":
    daemon = PsiGuardDaemon()

    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        if command == "start":
            daemon.start()
        elif command == "stop":
            daemon.stop()
        elif command == "restart":
            daemon.restart()
        elif command == "status":
            status = daemon.get_status()
            print(json.dumps(status, indent=2))
        else:
            print("Usage: python daemon.py [start|stop|restart|status]")
    else:
        daemon.start()
