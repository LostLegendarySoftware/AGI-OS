#!/usr/bin/env python3
"""
Linux Installer for ARIEL Antivirus System
Cross-platform installer with systemd integration and dependency management
"""

import os
import sys
import json
import subprocess
import platform
import shutil
import pwd
import grp
from typing import Dict, List, Any, Optional
from datetime import datetime
import tempfile

class LinuxInstaller:
    def __init__(self):
        """Initialize Linux installer"""
        self.platform = platform.system()
        self.distribution = self._get_distribution()
        self.architecture = platform.architecture()[0]
        self.python_version = f"{sys.version_info.major}.{sys.version_info.minor}"
        self.install_dir = "/opt/ariel_antivirus"
        self.service_name = "psiguard"
        self.user_name = "ariel"
        self.group_name = "ariel"
        self.installation_log = []

    def _get_distribution(self) -> str:
        """Get Linux distribution"""
        try:
            with open('/etc/os-release', 'r') as f:
                for line in f:
                    if line.startswith('ID='):
                        return line.split('=')[1].strip().strip('"')
        except:
            return "unknown"
        return "unknown"

    def install(self) -> Dict[str, Any]:
        """Main installation process"""
        print("ARIEL Antivirus System - Linux Installer")
        print("=" * 50)

        result = {
            "started": datetime.now().isoformat(),
            "platform": f"{self.platform} {self.architecture}",
            "distribution": self.distribution,
            "python_version": self.python_version,
            "install_directory": self.install_dir,
            "steps_completed": [],
            "steps_failed": [],
            "success": False
        }

        try:
            # Step 1: Pre-installation checks
            print("\n[1/9] Performing pre-installation checks...")
            if self._pre_installation_checks():
                result["steps_completed"].append("pre_installation_checks")
                print("✓ Pre-installation checks passed")
            else:
                result["steps_failed"].append("pre_installation_checks")
                print("✗ Pre-installation checks failed")
                return result

            # Step 2: Create system user and group
            print("\n[2/9] Creating system user and group...")
            if self._create_system_user():
                result["steps_completed"].append("create_user")
                print("✓ System user and group created")
            else:
                result["steps_failed"].append("create_user")
                print("✗ Failed to create system user and group")

            # Step 3: Create installation directory
            print("\n[3/9] Creating installation directory...")
            if self._create_install_directory():
                result["steps_completed"].append("create_directory")
                print(f"✓ Created installation directory: {self.install_dir}")
            else:
                result["steps_failed"].append("create_directory")
                print("✗ Failed to create installation directory")
                return result

            # Step 4: Install system dependencies
            print("\n[4/9] Installing system dependencies...")
            if self._install_system_dependencies():
                result["steps_completed"].append("install_system_deps")
                print("✓ System dependencies installed")
            else:
                result["steps_failed"].append("install_system_deps")
                print("✗ Failed to install system dependencies")

            # Step 5: Install Python dependencies
            print("\n[5/9] Installing Python dependencies...")
            if self._install_python_dependencies():
                result["steps_completed"].append("install_python_deps")
                print("✓ Python dependencies installed")
            else:
                result["steps_failed"].append("install_python_deps")
                print("✗ Failed to install Python dependencies")

            # Step 6: Copy application files
            print("\n[6/9] Copying application files...")
            if self._copy_application_files():
                result["steps_completed"].append("copy_files")
                print("✓ Application files copied successfully")
            else:
                result["steps_failed"].append("copy_files")
                print("✗ Failed to copy application files")
                return result

            # Step 7: Configure system integration
            print("\n[7/9] Configuring system integration...")
            if self._configure_system_integration():
                result["steps_completed"].append("system_integration")
                print("✓ System integration configured")
            else:
                result["steps_failed"].append("system_integration")
                print("✗ Failed to configure system integration")

            # Step 8: Install systemd service
            print("\n[8/9] Installing systemd service...")
            if self._install_systemd_service():
                result["steps_completed"].append("install_service")
                print("✓ Systemd service installed successfully")
            else:
                result["steps_failed"].append("install_service")
                print("✗ Failed to install systemd service")

            # Step 9: Final validation
            print("\n[9/9] Performing final validation...")
            if self._final_validation():
                result["steps_completed"].append("final_validation")
                print("✓ Installation validation successful")
                result["success"] = True
            else:
                result["steps_failed"].append("final_validation")
                print("✗ Installation validation failed")

        except Exception as e:
            print(f"\n✗ Installation failed with error: {e}")
            result["error"] = str(e)

        result["completed"] = datetime.now().isoformat()

        if result["success"]:
            print("\n" + "=" * 50)
            print("✓ ARIEL Antivirus System installed successfully!")
            print(f"Installation directory: {self.install_dir}")
            print(f"Service name: {self.service_name}")
            print("\nTo manage the service:")
            print(f"  Start:   sudo systemctl start {self.service_name}")
            print(f"  Stop:    sudo systemctl stop {self.service_name}")
            print(f"  Status:  sudo systemctl status {self.service_name}")
            print(f"  Logs:    sudo journalctl -u {self.service_name}")
        else:
            print("\n" + "=" * 50)
            print("✗ Installation failed. Please check the error messages above.")

        return result

    def _pre_installation_checks(self) -> bool:
        """Perform pre-installation checks"""
        checks = []

        # Check if running on Linux
        if self.platform.lower() != "linux":
            print("  ✗ This installer is for Linux only")
            return False

        # Check if running as root
        if os.geteuid() != 0:
            print("  ✗ Root privileges required (run with sudo)")
            return False
        checks.append("root_privileges")

        # Check Python version
        if sys.version_info.major >= 3 and sys.version_info.minor >= 7:
            checks.append("python_version")
        else:
            print(f"  ✗ Python 3.7+ required (found {self.python_version})")
            return False

        # Check systemd availability
        if os.path.exists("/bin/systemctl") or os.path.exists("/usr/bin/systemctl"):
            checks.append("systemd_available")
        else:
            print("  ✗ systemd not available (required for service management)")
            return False

        # Check disk space (require 1GB)
        try:
            statvfs = os.statvfs('/')
            free_bytes = statvfs.f_frsize * statvfs.f_bavail
            free_gb = free_bytes / (1024**3)
            if free_gb >= 1.0:
                checks.append("disk_space")
            else:
                print(f"  ✗ Insufficient disk space (need 1GB, have {free_gb:.1f}GB)")
                return False
        except:
            print("  ✗ Unable to check disk space")
            return False

        # Check for existing installation
        if os.path.exists(self.install_dir):
            print(f"  ! Existing installation found at {self.install_dir}")
            try:
                response = input("  Continue with upgrade? (y/N): ")
                if response.lower() != 'y':
                    return False
            except:
                print("  ! Continuing with upgrade (non-interactive mode)")

        print(f"  ✓ All pre-installation checks passed ({len(checks)} checks)")
        return True

    def _create_system_user(self) -> bool:
        """Create system user and group for the service"""
        try:
            # Check if group exists
            try:
                grp.getgrnam(self.group_name)
                print(f"  ✓ Group '{self.group_name}' already exists")
            except KeyError:
                # Create group
                result = subprocess.run([
                    "groupadd", "--system", self.group_name
                ], capture_output=True, text=True)

                if result.returncode == 0:
                    print(f"  ✓ Created system group: {self.group_name}")
                else:
                    print(f"  ✗ Failed to create group: {result.stderr}")
                    return False

            # Check if user exists
            try:
                pwd.getpwnam(self.user_name)
                print(f"  ✓ User '{self.user_name}' already exists")
            except KeyError:
                # Create user
                result = subprocess.run([
                    "useradd", "--system", "--gid", self.group_name,
                    "--home-dir", self.install_dir,
                    "--no-create-home", "--shell", "/bin/false",
                    self.user_name
                ], capture_output=True, text=True)

                if result.returncode == 0:
                    print(f"  ✓ Created system user: {self.user_name}")
                else:
                    print(f"  ✗ Failed to create user: {result.stderr}")
                    return False

            return True
        except Exception as e:
            print(f"  ✗ Error creating system user: {e}")
            return False

    def _create_install_directory(self) -> bool:
        """Create installation directory structure"""
        try:
            directories = [
                self.install_dir,
                os.path.join(self.install_dir, "source"),
                os.path.join(self.install_dir, "logs"),
                os.path.join(self.install_dir, "config"),
                os.path.join(self.install_dir, "data"),
                "/var/log/ariel_antivirus",
                "/etc/ariel_antivirus"
            ]

            for directory in directories:
                os.makedirs(directory, exist_ok=True)

                # Set ownership for application directories
                if directory.startswith(self.install_dir) or directory.startswith("/var/log/ariel"):
                    try:
                        user_info = pwd.getpwnam(self.user_name)
                        group_info = grp.getgrnam(self.group_name)
                        os.chown(directory, user_info.pw_uid, group_info.gr_gid)
                    except:
                        pass  # Continue if user doesn't exist yet

            return True
        except Exception as e:
            print(f"  ✗ Error creating directories: {e}")
            return False

    def _install_system_dependencies(self) -> bool:
        """Install system-level dependencies"""
        try:
            # Determine package manager and packages
            if self.distribution in ["ubuntu", "debian"]:
                pkg_manager = "apt-get"
                update_cmd = ["apt-get", "update"]
                install_cmd = ["apt-get", "install", "-y"]
                packages = [
                    "python3-pip", "python3-dev", "python3-venv",
                    "build-essential", "libssl-dev", "libffi-dev",
                    "libjpeg-dev", "libpng-dev",
                    "pkg-config", "cmake"
                ]
            elif self.distribution in ["centos", "rhel", "fedora"]:
                if self.distribution == "fedora":
                    pkg_manager = "dnf"
                    update_cmd = ["dnf", "check-update"]
                    install_cmd = ["dnf", "install", "-y"]
                else:
                    pkg_manager = "yum"
                    update_cmd = ["yum", "check-update"]
                    install_cmd = ["yum", "install", "-y"]
                packages = [
                    "python3-pip", "python3-devel", "python3-virtualenv",
                    "gcc", "gcc-c++", "openssl-devel", "libffi-devel",
                    "libjpeg-devel", "libpng-devel",
                    "pkgconfig", "cmake"
                ]
            else:
                print(f"  ! Unsupported distribution: {self.distribution}")
                print("  ! Skipping system package installation")
                return True

            # Update package lists
            print(f"  Updating package lists...")
            subprocess.run(update_cmd, capture_output=True, timeout=300)

            # Install packages
            failed_packages = []
            for package in packages:
                try:
                    print(f"  Installing {package}...")
                    result = subprocess.run(
                        install_cmd + [package],
                        capture_output=True, text=True, timeout=300
                    )

                    if result.returncode != 0:
                        print(f"  ! Failed to install {package}")
                        failed_packages.append(package)
                    else:
                        print(f"  ✓ Installed {package}")
                except subprocess.TimeoutExpired:
                    print(f"  ! Timeout installing {package}")
                    failed_packages.append(package)
                except Exception as e:
                    print(f"  ! Error installing {package}: {e}")
                    failed_packages.append(package)

            if failed_packages:
                print(f"  ! Some packages failed to install: {failed_packages}")
                print("  ! Installation will continue, but some features may not work")

            return len(failed_packages) < len(packages) // 2  # Allow up to 50% failure

        except Exception as e:
            print(f"  ✗ Error installing system dependencies: {e}")
            return False

    def _install_python_dependencies(self) -> bool:
        """Install Python dependencies"""
        dependencies = [
            "psutil>=5.9.0",
            "requests>=2.28.0",
            "numpy>=1.21.0",
            "cryptography>=3.4.8",
            "pillow>=9.0.0"
        ]

        failed_deps = []

        for dep in dependencies:
            try:
                print(f"  Installing {dep}...")
                result = subprocess.run([
                    sys.executable, "-m", "pip", "install", dep, "--upgrade"
                ], capture_output=True, text=True, timeout=300)

                if result.returncode != 0:
                    print(f"  ✗ Failed to install {dep}: {result.stderr}")
                    failed_deps.append(dep)
                else:
                    print(f"  ✓ Installed {dep}")
            except subprocess.TimeoutExpired:
                print(f"  ✗ Timeout installing {dep}")
                failed_deps.append(dep)
            except Exception as e:
                print(f"  ✗ Error installing {dep}: {e}")
                failed_deps.append(dep)

        if failed_deps:
            print(f"  ! Some dependencies failed to install: {failed_deps}")
            print("  Installation will continue, but some features may not work properly.")

        return len(failed_deps) < len(dependencies) // 2  # Allow up to 50% failure

    def _copy_application_files(self) -> bool:
        """Copy application files to installation directory"""
        try:
            source_dir = "./source"
            target_dir = os.path.join(self.install_dir, "source")

            if os.path.exists(source_dir):
                # Copy source files
                for item in os.listdir(source_dir):
                    source_path = os.path.join(source_dir, item)
                    target_path = os.path.join(target_dir, item)

                    if os.path.isdir(source_path):
                        shutil.copytree(source_path, target_path, dirs_exist_ok=True)
                    else:
                        shutil.copy2(source_path, target_path)

                print(f"  ✓ Copied source files to {target_dir}")

                # Set ownership
                try:
                    user_info = pwd.getpwnam(self.user_name)
                    group_info = grp.getgrnam(self.group_name)

                    for root, dirs, files in os.walk(target_dir):
                        os.chown(root, user_info.pw_uid, group_info.gr_gid)
                        for file in files:
                            file_path = os.path.join(root, file)
                            os.chown(file_path, user_info.pw_uid, group_info.gr_gid)
                            # Make Python files executable
                            if file.endswith('.py'):
                                os.chmod(file_path, 0o755)
                except Exception as e:
                    print(f"  ! Warning: Could not set file ownership: {e}")

            else:
                print("  ✗ Source directory not found")
                return False

            return True
        except Exception as e:
            print(f"  ✗ Error copying files: {e}")
            return False

    def _configure_system_integration(self) -> bool:
        """Configure Linux system integration"""
        try:
            # Create configuration files
            config_dir = "/etc/ariel_antivirus"

            # Main configuration
            main_config = {
                "installation": {
                    "install_dir": self.install_dir,
                    "user": self.user_name,
                    "group": self.group_name,
                    "version": "1.0.0",
                    "install_date": datetime.now().isoformat()
                },
                "logging": {
                    "system_log": "/var/log/ariel_antivirus/system.log",
                    "security_log": "/var/log/ariel_antivirus/security.log",
                    "level": "INFO"
                },
                "service": {
                    "name": self.service_name,
                    "auto_start": True,
                    "restart_policy": "always"
                }
            }

            config_file = os.path.join(config_dir, "config.json")
            with open(config_file, 'w') as f:
                json.dump(main_config, f, indent=2)

            print(f"  ✓ Created configuration file: {config_file}")

            # Create logrotate configuration
            logrotate_content = "/var/log/ariel_antivirus/*.log {\n"
            logrotate_content += "    daily\n"
            logrotate_content += "    missingok\n"
            logrotate_content += "    rotate 30\n"
            logrotate_content += "    compress\n"
            logrotate_content += "    delaycompress\n"
            logrotate_content += "    notifempty\n"
            logrotate_content += f"    create 644 {self.user_name} {self.group_name}\n"
            logrotate_content += "    postrotate\n"
            logrotate_content += f"        systemctl reload {self.service_name} > /dev/null 2>&1 || true\n"
            logrotate_content += "    endscript\n"
            logrotate_content += "}\n"

            logrotate_file = "/etc/logrotate.d/ariel_antivirus"
            with open(logrotate_file, 'w') as f:
                f.write(logrotate_content)

            print(f"  ✓ Created logrotate configuration: {logrotate_file}")

            return True
        except Exception as e:
            print(f"  ✗ Error configuring system integration: {e}")
            return False

    def _install_systemd_service(self) -> bool:
        """Install systemd service"""
        try:
            # Create systemd service file
            service_lines = [
                "[Unit]",
                "Description=ARIEL PsiGuard Antivirus Service",
                "Documentation=https://github.com/ariel/antivirus",
                "After=network.target",
                "Wants=network.target",
                "",
                "[Service]",
                "Type=simple",
                f"User={self.user_name}",
                f"Group={self.group_name}",
                f"WorkingDirectory={self.install_dir}",
                f"ExecStart=/usr/bin/python3 {self.install_dir}/source/Setup/daemon.py start",
                "ExecReload=/bin/kill -HUP $MAINPID",
                "Restart=always",
                "RestartSec=10",
                "StandardOutput=journal",
                "StandardError=journal",
                f"SyslogIdentifier={self.service_name}",
                "",
                "# Security settings",
                "NoNewPrivileges=true",
                "PrivateTmp=true",
                "ProtectSystem=strict",
                "ProtectHome=true",
                f"ReadWritePaths={self.install_dir} /var/log/ariel_antivirus /tmp",
                "",
                "[Install]",
                "WantedBy=multi-user.target"
            ]

            service_content = "\n".join(service_lines)

            service_file = f"/etc/systemd/system/{self.service_name}.service"
            with open(service_file, 'w') as f:
                f.write(service_content)

            print(f"  ✓ Created systemd service file: {service_file}")

            # Reload systemd and enable service
            commands = [
                ["systemctl", "daemon-reload"],
                ["systemctl", "enable", self.service_name],
                ["systemctl", "start", self.service_name]
            ]

            for cmd in commands:
                result = subprocess.run(cmd, capture_output=True, text=True)
                if result.returncode == 0:
                    print(f"  ✓ Executed: {' '.join(cmd)}")
                else:
                    print(f"  ! Warning: Failed to execute {' '.join(cmd)}: {result.stderr}")

            return True
        except Exception as e:
            print(f"  ✗ Error installing systemd service: {e}")
            return False

    def _final_validation(self) -> bool:
        """Perform final installation validation"""
        try:
            # Check if all required files exist
            required_files = [
                os.path.join(self.install_dir, "source", "Setup", "main.py"),
                os.path.join(self.install_dir, "source", "Setup", "daemon.py"),
                os.path.join(self.install_dir, "source", "Setup", "logging_manager.py"),
                f"/etc/systemd/system/{self.service_name}.service"
            ]

            for file_path in required_files:
                if not os.path.exists(file_path):
                    print(f"  ✗ Required file missing: {file_path}")
                    return False

            # Check service status
            try:
                result = subprocess.run([
                    "systemctl", "is-active", self.service_name
                ], capture_output=True, text=True)

                if result.stdout.strip() == "active":
                    print(f"  ✓ Service '{self.service_name}' is running")
                else:
                    print(f"  ! Service '{self.service_name}' is not active: {result.stdout.strip()}")
            except:
                print("  ! Could not check service status")

            print("  ✓ All required files are present")
            return True
        except Exception as e:
            print(f"  ✗ Validation error: {e}")
            return False

if __name__ == "__main__":
    installer = LinuxInstaller()
    result = installer.install()

    # Save installation log
    try:
        log_file = os.path.join(installer.install_dir, "installation_log.json")
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file, 'w') as f:
            json.dump(result, f, indent=2)
    except Exception as e:
        print(f"Could not save installation log: {e}")
