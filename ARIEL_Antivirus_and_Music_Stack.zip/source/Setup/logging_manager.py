#!/usr/bin/env python3
"""
Logging Manager - Centralized Logging Infrastructure
Comprehensive logging system for all ARIEL antivirus modules
"""

import os
import sys
import json
import logging
import threading
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
import queue
import time

class CentralizedLoggingManager:
    def __init__(self, config_path: str = "logging_config.json"):
        """Initialize centralized logging manager"""
        self.config = self._load_config(config_path)
        self.loggers = {}
        self.log_queue = queue.Queue()
        self.monitoring_thread = None
        self.running = False
        self._setup_log_directories()
        self._setup_monitoring()

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load logging configuration"""
        default_config = {
            "global": {
                "level": "INFO",
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                "date_format": "%Y-%m-%d %H:%M:%S"
            },
            "handlers": {
                "file": {
                    "enabled": True,
                    "max_bytes": 10485760,  # 10MB
                    "backup_count": 5,
                    "rotation": "size"
                },
                "timed": {
                    "enabled": True,
                    "when": "midnight",
                    "interval": 1,
                    "backup_count": 30
                },
                "console": {
                    "enabled": True,
                    "level": "INFO"
                }
            },
            "modules": {
                "PhiGuard_Core": {"level": "INFO", "separate_file": True},
                "WardenMonitor": {"level": "INFO", "separate_file": True},
                "ReHabScanner": {"level": "INFO", "separate_file": True},
                "SigStrat": {"level": "INFO", "separate_file": True},
                "AVxSentinel": {"level": "INFO", "separate_file": True},
                "ReDriverAI": {"level": "INFO", "separate_file": True},
                "PsiPlayGuard": {"level": "INFO", "separate_file": True},
                "PsiShield": {"level": "INFO", "separate_file": True},
                "BiometricCore": {"level": "INFO", "separate_file": True},
                "HeartRateMonitor": {"level": "INFO", "separate_file": True},
                "VoiceApproval": {"level": "INFO", "separate_file": True},
                "GestureRecognition": {"level": "INFO", "separate_file": True},
                "rehab_rehype_ai": {"level": "INFO", "separate_file": True},
                "Integration": {"level": "INFO", "separate_file": True},
                "Setup": {"level": "INFO", "separate_file": True}
            },
            "security": {
                "audit_logging": True,
                "security_events": True,
                "threat_logging": True
            },
            "performance": {
                "performance_logging": True,
                "resource_monitoring": True,
                "timing_logs": True
            },
            "retention": {
                "days": 30,
                "max_size_gb": 5,
                "compression": True
            }
        }

        try:
            if os.path.exists(config_path):
                with open(config_path, 'r') as f:
                    config = json.load(f)
                # Merge with defaults
                for key, value in default_config.items():
                    if key not in config:
                        config[key] = value
                return config
            else:
                # Save default config
                with open(config_path, 'w') as f:
                    json.dump(default_config, f, indent=2)
                return default_config
        except Exception as e:
            print(f"Error loading logging config: {e}")
            return default_config

    def _setup_log_directories(self):
        """Setup log directory structure"""
        log_dirs = [
            "../../logs",
            "../../logs/system",
            "../../logs/modules",
            "../../logs/security",
            "../../logs/performance",
            "../../logs/daemon",
            "../../logs/audit",
            "../../logs/archived"
        ]

        for log_dir in log_dirs:
            os.makedirs(log_dir, exist_ok=True)

    def get_logger(self, module_name: str) -> logging.Logger:
        """Get or create logger for specific module"""
        if module_name in self.loggers:
            return self.loggers[module_name]

        logger = logging.Logger(module_name)

        # Get module-specific config
        module_config = self.config.get("modules", {}).get(module_name, {})
        log_level = getattr(logging, module_config.get("level", "INFO"))
        logger.setLevel(log_level)

        # Setup handlers
        self._setup_handlers(logger, module_name, module_config)

        self.loggers[module_name] = logger
        return logger

    def _setup_handlers(self, logger: logging.Logger, module_name: str, module_config: Dict[str, Any]):
        """Setup handlers for logger"""
        formatter = logging.Formatter(
            self.config["global"]["format"],
            datefmt=self.config["global"]["date_format"]
        )

        # File handler
        if self.config["handlers"]["file"]["enabled"]:
            if module_config.get("separate_file", False):
                log_file = f"../../logs/modules/{module_name.lower()}.log"
            else:
                log_file = "../../logs/system/antivirus_system.log"

            if self.config["handlers"]["file"]["rotation"] == "size":
                file_handler = RotatingFileHandler(
                    log_file,
                    maxBytes=self.config["handlers"]["file"]["max_bytes"],
                    backupCount=self.config["handlers"]["file"]["backup_count"]
                )
            else:
                file_handler = TimedRotatingFileHandler(
                    log_file,
                    when=self.config["handlers"]["timed"]["when"],
                    interval=self.config["handlers"]["timed"]["interval"],
                    backupCount=self.config["handlers"]["timed"]["backup_count"]
                )

            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

        # Console handler
        if self.config["handlers"]["console"]["enabled"]:
            console_handler = logging.StreamHandler()
            console_level = getattr(logging, self.config["handlers"]["console"]["level"])
            console_handler.setLevel(console_level)
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)

    def log_security_event(self, event_type: str, details: Dict[str, Any], severity: str = "INFO"):
        """Log security events"""
        if not self.config.get("security", {}).get("security_events", True):
            return

        security_logger = self.get_security_logger()

        event_data = {
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            "severity": severity,
            "details": details
        }

        log_message = f"SECURITY_EVENT: {json.dumps(event_data)}"

        if severity.upper() == "CRITICAL":
            security_logger.critical(log_message)
        elif severity.upper() == "ERROR":
            security_logger.error(log_message)
        elif severity.upper() == "WARNING":
            security_logger.warning(log_message)
        else:
            security_logger.info(log_message)

    def log_performance_metric(self, metric_name: str, value: float, unit: str = "", module: str = ""):
        """Log performance metrics"""
        if not self.config.get("performance", {}).get("performance_logging", True):
            return

        performance_logger = self.get_performance_logger()

        metric_data = {
            "timestamp": datetime.now().isoformat(),
            "metric": metric_name,
            "value": value,
            "unit": unit,
            "module": module
        }

        performance_logger.info(f"PERFORMANCE_METRIC: {json.dumps(metric_data)}")

    def log_audit_event(self, action: str, user: str, resource: str, result: str, details: Dict[str, Any] = None):
        """Log audit events"""
        if not self.config.get("security", {}).get("audit_logging", True):
            return

        audit_logger = self.get_audit_logger()

        audit_data = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "user": user,
            "resource": resource,
            "result": result,
            "details": details or {}
        }

        audit_logger.info(f"AUDIT_EVENT: {json.dumps(audit_data)}")

    def get_security_logger(self) -> logging.Logger:
        """Get security-specific logger"""
        if "security" not in self.loggers:
            logger = logging.Logger("security")
            logger.setLevel(logging.INFO)

            formatter = logging.Formatter(
                "%(asctime)s - SECURITY - %(levelname)s - %(message)s"
            )

            # Security log file
            security_handler = RotatingFileHandler(
                "../../logs/security/security_events.log",
                maxBytes=10485760,  # 10MB
                backupCount=10
            )
            security_handler.setFormatter(formatter)
            logger.addHandler(security_handler)

            self.loggers["security"] = logger

        return self.loggers["security"]

    def get_performance_logger(self) -> logging.Logger:
        """Get performance-specific logger"""
        if "performance" not in self.loggers:
            logger = logging.Logger("performance")
            logger.setLevel(logging.INFO)

            formatter = logging.Formatter(
                "%(asctime)s - PERFORMANCE - %(levelname)s - %(message)s"
            )

            # Performance log file
            perf_handler = RotatingFileHandler(
                "../../logs/performance/performance_metrics.log",
                maxBytes=10485760,  # 10MB
                backupCount=5
            )
            perf_handler.setFormatter(formatter)
            logger.addHandler(perf_handler)

            self.loggers["performance"] = logger

        return self.loggers["performance"]

    def get_audit_logger(self) -> logging.Logger:
        """Get audit-specific logger"""
        if "audit" not in self.loggers:
            logger = logging.Logger("audit")
            logger.setLevel(logging.INFO)

            formatter = logging.Formatter(
                "%(asctime)s - AUDIT - %(levelname)s - %(message)s"
            )

            # Audit log file
            audit_handler = RotatingFileHandler(
                "../../logs/audit/audit_trail.log",
                maxBytes=10485760,  # 10MB
                backupCount=20  # Keep more audit logs
            )
            audit_handler.setFormatter(formatter)
            logger.addHandler(audit_handler)

            self.loggers["audit"] = logger

        return self.loggers["audit"]

    def _setup_monitoring(self):
        """Setup log monitoring and alerting"""
        self.running = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()

    def _monitoring_loop(self):
        """Monitor logs for critical events"""
        while self.running:
            try:
                # Check log file sizes
                self._check_log_sizes()

                # Check for critical errors
                self._check_critical_errors()

                # Cleanup old logs
                self._cleanup_old_logs()

                time.sleep(300)  # Check every 5 minutes

            except Exception as e:
                print(f"Log monitoring error: {e}")

    def _check_log_sizes(self):
        """Check log file sizes and rotate if necessary"""
        log_dirs = ["../../logs/system", "../../logs/modules", "../../logs/security", "../../logs/performance"]

        for log_dir in log_dirs:
            if os.path.exists(log_dir):
                for filename in os.listdir(log_dir):
                    filepath = os.path.join(log_dir, filename)
                    if os.path.isfile(filepath) and filename.endswith('.log'):
                        size_mb = os.path.getsize(filepath) / (1024 * 1024)
                        if size_mb > 50:  # Alert if log file > 50MB
                            self.log_security_event(
                                "large_log_file",
                                {"file": filepath, "size_mb": size_mb},
                                "WARNING"
                            )

    def _check_critical_errors(self):
        """Check for critical errors in recent logs"""
        # This would implement real-time log analysis for critical patterns
        pass

    def _cleanup_old_logs(self):
        """Cleanup old log files based on retention policy"""
        retention_days = self.config.get("retention", {}).get("days", 30)
        cutoff_date = datetime.now() - timedelta(days=retention_days)

        log_dirs = ["../../logs/system", "../../logs/modules", "../../logs/security", "../../logs/performance"]

        for log_dir in log_dirs:
            if os.path.exists(log_dir):
                for filename in os.listdir(log_dir):
                    filepath = os.path.join(log_dir, filename)
                    if os.path.isfile(filepath):
                        file_time = datetime.fromtimestamp(os.path.getmtime(filepath))
                        if file_time < cutoff_date:
                            try:
                                # Move to archived directory instead of deleting
                                archive_dir = "../../logs/archived"
                                os.makedirs(archive_dir, exist_ok=True)
                                archive_path = os.path.join(archive_dir, filename)
                                os.rename(filepath, archive_path)
                            except Exception as e:
                                print(f"Error archiving log file {filepath}: {e}")

    def get_log_statistics(self) -> Dict[str, Any]:
        """Get logging statistics"""
        stats = {
            "active_loggers": len(self.loggers),
            "log_directories": [],
            "total_log_size_mb": 0,
            "oldest_log": None,
            "newest_log": None
        }

        log_dirs = ["../../logs/system", "../../logs/modules", "../../logs/security", "../../logs/performance"]

        for log_dir in log_dirs:
            if os.path.exists(log_dir):
                dir_info = {
                    "directory": log_dir,
                    "file_count": 0,
                    "size_mb": 0
                }

                for filename in os.listdir(log_dir):
                    filepath = os.path.join(log_dir, filename)
                    if os.path.isfile(filepath):
                        dir_info["file_count"] += 1
                        size_mb = os.path.getsize(filepath) / (1024 * 1024)
                        dir_info["size_mb"] += size_mb
                        stats["total_log_size_mb"] += size_mb

                stats["log_directories"].append(dir_info)

        return stats

    def shutdown(self):
        """Shutdown logging manager"""
        self.running = False
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5)

# Global logging manager instance
_logging_manager = None

def get_logging_manager() -> CentralizedLoggingManager:
    """Get global logging manager instance"""
    global _logging_manager
    if _logging_manager is None:
        _logging_manager = CentralizedLoggingManager()
    return _logging_manager

def get_module_logger(module_name: str) -> logging.Logger:
    """Convenience function to get module logger"""
    return get_logging_manager().get_logger(module_name)

if __name__ == "__main__":
    # Test the logging manager
    manager = CentralizedLoggingManager()

    # Test different loggers
    test_logger = manager.get_logger("TestModule")
    test_logger.info("Test log message")

    # Test security logging
    manager.log_security_event("test_event", {"test": "data"}, "INFO")

    # Test performance logging
    manager.log_performance_metric("cpu_usage", 45.2, "%", "TestModule")

    # Test audit logging
    manager.log_audit_event("file_access", "test_user", "/test/file", "success")

    # Get statistics
    stats = manager.get_log_statistics()
    print("Logging Statistics:")
    print(json.dumps(stats, indent=2))
