#!/bin/bash
# ARIEL Antivirus System - Linux Installer Script
# Cross-platform installation with systemd integration

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root (use sudo)"
        exit 1
    fi
}

# Check Python availability
check_python() {
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 is required but not installed"
        exit 1
    fi

    python_version=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    print_status "Found Python $python_version"

    # Check if version is 3.7+
    if ! python3 -c "import sys; exit(0 if sys.version_info >= (3, 7) else 1)"; then
        print_error "Python 3.7 or higher is required"
        exit 1
    fi
}

# Main installation function
main() {
    echo "=============================================="
    echo "ARIEL Antivirus System - Linux Installer"
    echo "=============================================="
    echo

    print_status "Starting installation process..."

    # Perform checks
    check_root
    check_python

    # Check if installer exists
    if [[ ! -f "./source/Setup/linux_installer.py" ]]; then
        print_error "Linux installer not found at ./source/Setup/linux_installer.py"
        exit 1
    fi

    print_status "Running Python installer..."

    # Run the Python installer
    if python3 ./source/Setup/linux_installer.py; then
        print_success "Installation completed successfully!"
        echo
        echo "=============================================="
        echo "Installation Summary:"
        echo "- Service name: psiguard"
        echo "- Installation directory: /opt/ariel_antivirus"
        echo "- Configuration: /etc/ariel_antivirus/"
        echo "- Logs: /var/log/ariel_antivirus/"
        echo
        echo "Service Management Commands:"
        echo "  sudo systemctl start psiguard"
        echo "  sudo systemctl stop psiguard"
        echo "  sudo systemctl status psiguard"
        echo "  sudo systemctl enable psiguard"
        echo "  sudo systemctl disable psiguard"
        echo
        echo "View Logs:"
        echo "  sudo journalctl -u psiguard -f"
        echo "=============================================="
    else
        print_error "Installation failed!"
        echo
        echo "Please check the error messages above and try again."
        echo "For support, check the installation logs."
        exit 1
    fi
}

# Handle script arguments
case "${1:-}" in
    --help|-h)
        echo "ARIEL Antivirus System - Linux Installer"
        echo
        echo "Usage: $0 [OPTIONS]"
        echo
        echo "Options:"
        echo "  --help, -h     Show this help message"
        echo "  --version, -v  Show version information"
        echo
        echo "This installer will:"
        echo "  1. Check system requirements"
        echo "  2. Install system dependencies"
        echo "  3. Create system user and directories"
        echo "  4. Install Python dependencies"
        echo "  5. Copy application files"
        echo "  6. Configure systemd service"
        echo "  7. Start the antivirus service"
        echo
        echo "Requirements:"
        echo "  - Linux with systemd"
        echo "  - Python 3.7+"
        echo "  - Root privileges (sudo)"
        echo "  - 1GB free disk space"
        exit 0
        ;;
    --version|-v)
        echo "ARIEL Antivirus System Installer v1.0.0"
        exit 0
        ;;
    "")
        main
        ;;
    *)
        print_error "Unknown option: $1"
        echo "Use --help for usage information"
        exit 1
        ;;
esac
