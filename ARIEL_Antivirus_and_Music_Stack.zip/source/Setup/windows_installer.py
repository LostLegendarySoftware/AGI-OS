#!/usr/bin/env python3
"""
Windows Installer for ARIEL Antivirus System
Cross-platform installer with dependency management and service registration
"""

import os
import sys
import json
import subprocess
import platform
import shutil
from typing import Dict, List, Any, Optional
from datetime import datetime
import tempfile

class WindowsInstaller:
    def __init__(self):
        """Initialize Windows installer"""
        self.platform = platform.system()
        self.architecture = platform.architecture()[0]
        self.python_version = f"{sys.version_info.major}.{sys.version_info.minor}"
        self.install_dir = os.path.join(os.environ.get("PROGRAMFILES", "C:\Program Files"), "ARIEL_Antivirus")
        self.service_name = "PsiGuardService"
        self.installation_log = []

    def install(self) -> Dict[str, Any]:
        """Main installation process"""
        print("ARIEL Antivirus System - Windows Installer")
        print("=" * 50)

        result = {
            "started": datetime.now().isoformat(),
            "platform": f"{self.platform} {self.architecture}",
            "python_version": self.python_version,
            "install_directory": self.install_dir,
            "steps_completed": [],
            "steps_failed": [],
            "success": False
        }

        try:
            # Step 1: Pre-installation checks
            print("\n[1/8] Performing pre-installation checks...")
            if self._pre_installation_checks():
                result["steps_completed"].append("pre_installation_checks")
                print("✓ Pre-installation checks passed")
            else:
                result["steps_failed"].append("pre_installation_checks")
                print("✗ Pre-installation checks failed")
                return result

            # Step 2: Create installation directory
            print("\n[2/8] Creating installation directory...")
            if self._create_install_directory():
                result["steps_completed"].append("create_directory")
                print(f"✓ Created installation directory: {self.install_dir}")
            else:
                result["steps_failed"].append("create_directory")
                print("✗ Failed to create installation directory")
                return result

            # Step 3: Install dependencies
            print("\n[3/8] Installing dependencies...")
            if self._install_dependencies():
                result["steps_completed"].append("install_dependencies")
                print("✓ Dependencies installed successfully")
            else:
                result["steps_failed"].append("install_dependencies")
                print("✗ Failed to install dependencies")

            # Step 4: Copy application files
            print("\n[4/8] Copying application files...")
            if self._copy_application_files():
                result["steps_completed"].append("copy_files")
                print("✓ Application files copied successfully")
            else:
                result["steps_failed"].append("copy_files")
                print("✗ Failed to copy application files")
                return result

            # Step 5: Configure system integration
            print("\n[5/8] Configuring system integration...")
            if self._configure_system_integration():
                result["steps_completed"].append("system_integration")
                print("✓ System integration configured")
            else:
                result["steps_failed"].append("system_integration")
                print("✗ Failed to configure system integration")

            # Step 6: Install Windows service
            print("\n[6/8] Installing Windows service...")
            if self._install_windows_service():
                result["steps_completed"].append("install_service")
                print("✓ Windows service installed successfully")
            else:
                result["steps_failed"].append("install_service")
                print("✗ Failed to install Windows service")

            # Step 7: Configure firewall rules
            print("\n[7/8] Configuring firewall rules...")
            if self._configure_firewall():
                result["steps_completed"].append("configure_firewall")
                print("✓ Firewall rules configured")
            else:
                result["steps_failed"].append("configure_firewall")
                print("✗ Failed to configure firewall rules")

            # Step 8: Final validation
            print("\n[8/8] Performing final validation...")
            if self._final_validation():
                result["steps_completed"].append("final_validation")
                print("✓ Installation validation successful")
                result["success"] = True
            else:
                result["steps_failed"].append("final_validation")
                print("✗ Installation validation failed")

        except Exception as e:
            print(f"\n✗ Installation failed with error: {e}")
            result["error"] = str(e)

        result["completed"] = datetime.now().isoformat()

        if result["success"]:
            print("\n" + "=" * 50)
            print("✓ ARIEL Antivirus System installed successfully!")
            print(f"Installation directory: {self.install_dir}")
            print("The service will start automatically on system boot.")
        else:
            print("\n" + "=" * 50)
            print("✗ Installation failed. Please check the error messages above.")

        return result

    def _pre_installation_checks(self) -> bool:
        """Perform pre-installation checks"""
        checks = []

        # Check if running on Windows
        if self.platform.lower() != "windows":
            print("  ✗ This installer is for Windows only")
            return False

        # Check if running as administrator (Windows-specific check)
        try:
            if self.platform.lower() == "windows":
                import ctypes
                is_admin = ctypes.windll.shell32.IsUserAnAdmin()
                if not is_admin:
                    print("  ✗ Administrator privileges required")
                    return False
            checks.append("admin_privileges")
        except Exception as e:
            print(f"  ! Warning: Could not check administrator privileges: {e}")

        # Check Python version
        if sys.version_info.major >= 3 and sys.version_info.minor >= 7:
            checks.append("python_version")
        else:
            print(f"  ✗ Python 3.7+ required (found {self.python_version})")
            return False

        # Check disk space (require 1GB)
        try:
            free_bytes = shutil.disk_usage(os.environ.get("SYSTEMDRIVE", "C:")).free
            free_gb = free_bytes / (1024**3)
            if free_gb >= 1.0:
                checks.append("disk_space")
            else:
                print(f"  ✗ Insufficient disk space (need 1GB, have {free_gb:.1f}GB)")
                return False
        except:
            print("  ✗ Unable to check disk space")
            return False

        # Check for existing installation
        if os.path.exists(self.install_dir):
            print(f"  ! Existing installation found at {self.install_dir}")
            try:
                response = input("  Continue with upgrade? (y/N): ")
                if response.lower() != 'y':
                    return False
            except:
                print("  ! Continuing with upgrade (non-interactive mode)")

        print(f"  ✓ All pre-installation checks passed ({len(checks)} checks)")
        return True

    def _create_install_directory(self) -> bool:
        """Create installation directory structure"""
        try:
            directories = [
                self.install_dir,
                os.path.join(self.install_dir, "source"),
                os.path.join(self.install_dir, "logs"),
                os.path.join(self.install_dir, "config"),
                os.path.join(self.install_dir, "data")
            ]

            for directory in directories:
                os.makedirs(directory, exist_ok=True)

            return True
        except Exception as e:
            print(f"  ✗ Error creating directories: {e}")
            return False

    def _install_dependencies(self) -> bool:
        """Install required Python dependencies"""
        dependencies = [
            "psutil>=5.9.0",
            "requests>=2.28.0", 
            "numpy>=1.21.0",
            "cryptography>=3.4.8",
            "pillow>=9.0.0"
        ]

        # Add Windows-specific dependencies
        if self.platform.lower() == "windows":
            dependencies.extend([
                "pywin32>=305"
            ])

        failed_deps = []

        for dep in dependencies:
            try:
                print(f"  Installing {dep}...")
                result = subprocess.run([
                    sys.executable, "-m", "pip", "install", dep, "--upgrade"
                ], capture_output=True, text=True, timeout=300)

                if result.returncode != 0:
                    print(f"  ✗ Failed to install {dep}: {result.stderr}")
                    failed_deps.append(dep)
                else:
                    print(f"  ✓ Installed {dep}")
            except subprocess.TimeoutExpired:
                print(f"  ✗ Timeout installing {dep}")
                failed_deps.append(dep)
            except Exception as e:
                print(f"  ✗ Error installing {dep}: {e}")
                failed_deps.append(dep)

        if failed_deps:
            print(f"  ! Some dependencies failed to install: {failed_deps}")
            print("  Installation will continue, but some features may not work properly.")

        return len(failed_deps) < len(dependencies) // 2  # Allow up to 50% failure

    def _copy_application_files(self) -> bool:
        """Copy application files to installation directory"""
        try:
            source_dir = "./source"
            target_dir = os.path.join(self.install_dir, "source")

            if os.path.exists(source_dir):
                # Copy source files
                for item in os.listdir(source_dir):
                    source_path = os.path.join(source_dir, item)
                    target_path = os.path.join(target_dir, item)

                    if os.path.isdir(source_path):
                        shutil.copytree(source_path, target_path, dirs_exist_ok=True)
                    else:
                        shutil.copy2(source_path, target_path)

                print(f"  ✓ Copied source files to {target_dir}")
            else:
                print("  ✗ Source directory not found")
                return False

            return True
        except Exception as e:
            print(f"  ✗ Error copying files: {e}")
            return False

    def _configure_system_integration(self) -> bool:
        """Configure Windows system integration"""
        try:
            # Try to configure Windows registry if available
            if self.platform.lower() == "windows":
                try:
                    import winreg
                    reg_key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, 
                                             r"SOFTWARE\ARIEL\Antivirus")
                    winreg.SetValueEx(reg_key, "InstallPath", 0, winreg.REG_SZ, self.install_dir)
                    winreg.SetValueEx(reg_key, "Version", 0, winreg.REG_SZ, "1.0.0")
                    winreg.SetValueEx(reg_key, "InstallDate", 0, winreg.REG_SZ, 
                                    datetime.now().isoformat())
                    winreg.CloseKey(reg_key)
                    print("  ✓ Registry entries created")
                except Exception as e:
                    print(f"  ! Warning: Could not create registry entries: {e}")

            return True
        except Exception as e:
            print(f"  ✗ Error configuring system integration: {e}")
            return False

    def _install_windows_service(self) -> bool:
        """Install as Windows service using Task Scheduler"""
        try:
            # Create a batch file to start the daemon
            batch_content = '@echo off\n'
            batch_content += f'cd /d "{self.install_dir}"\n'
            batch_content += 'python source\Setup\daemon.py start\n'

            batch_file = os.path.join(self.install_dir, "start_service.bat")
            with open(batch_file, 'w') as f:
                f.write(batch_content)

            # Try to create a scheduled task for auto-start
            task_name = "ARIEL_PsiGuard_Service"
            task_cmd = [
                "schtasks", "/create", "/tn", task_name,
                "/tr", batch_file,
                "/sc", "onstart",
                "/ru", "SYSTEM",
                "/f"  # Force overwrite if exists
            ]

            result = subprocess.run(task_cmd, capture_output=True, text=True)
            if result.returncode == 0:
                print(f"  ✓ Scheduled task '{task_name}' created successfully")

                # Start the task
                start_cmd = ["schtasks", "/run", "/tn", task_name]
                subprocess.run(start_cmd, capture_output=True)

                return True
            else:
                print(f"  ! Warning: Could not create scheduled task: {result.stderr}")
                # Fallback: just create startup script
                return self._create_startup_script()

        except Exception as e:
            print(f"  ✗ Error installing Windows service: {e}")
            return self._create_startup_script()

    def _create_startup_script(self) -> bool:
        """Create startup script as fallback"""
        try:
            startup_dir = os.path.join(os.environ.get("APPDATA", ""), 
                                     "Microsoft", "Windows", "Start Menu", "Programs", "Startup")

            if os.path.exists(startup_dir):
                startup_script = os.path.join(startup_dir, "ARIEL_Antivirus.bat")
                script_content = '@echo off\n'
                script_content += f'cd /d "{self.install_dir}"\n'
                script_content += 'python source\Setup\daemon.py start\n'

                with open(startup_script, 'w') as f:
                    f.write(script_content)

                print(f"  ✓ Startup script created at {startup_script}")
                return True
            else:
                print("  ! Could not find startup directory")
                return False
        except Exception as e:
            print(f"  ✗ Error creating startup script: {e}")
            return False

    def _configure_firewall(self) -> bool:
        """Configure Windows Firewall rules"""
        try:
            # Add firewall rules for the antivirus system
            daemon_path = os.path.join(self.install_dir, "source", "Setup", "daemon.py")

            rules = [
                {
                    "name": "ARIEL Antivirus Inbound",
                    "direction": "in",
                    "action": "allow",
                    "program": daemon_path
                },
                {
                    "name": "ARIEL Antivirus Outbound", 
                    "direction": "out",
                    "action": "allow",
                    "program": daemon_path
                }
            ]

            for rule in rules:
                cmd = [
                    "netsh", "advfirewall", "firewall", "add", "rule",
                    f"name={rule['name']}",
                    f"dir={rule['direction']}",
                    f"action={rule['action']}",
                    f"program={rule['program']}"
                ]

                result = subprocess.run(cmd, capture_output=True, text=True)
                if result.returncode == 0:
                    print(f"  ✓ Added firewall rule: {rule['name']}")
                else:
                    print(f"  ! Warning: Could not add firewall rule: {rule['name']}")

            return True
        except Exception as e:
            print(f"  ✗ Error configuring firewall: {e}")
            return False

    def _final_validation(self) -> bool:
        """Perform final installation validation"""
        try:
            # Check if all required files exist
            required_files = [
                os.path.join(self.install_dir, "source", "Setup", "main.py"),
                os.path.join(self.install_dir, "source", "Setup", "daemon.py"),
                os.path.join(self.install_dir, "source", "Setup", "logging_manager.py")
            ]

            for file_path in required_files:
                if not os.path.exists(file_path):
                    print(f"  ✗ Required file missing: {file_path}")
                    return False

            print("  ✓ All required files are present")
            return True
        except Exception as e:
            print(f"  ✗ Validation error: {e}")
            return False

if __name__ == "__main__":
    installer = WindowsInstaller()
    result = installer.install()

    # Save installation log
    try:
        log_file = os.path.join(installer.install_dir, "installation_log.json")
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file, 'w') as f:
            json.dump(result, f, indent=2)
    except Exception as e:
        print(f"Could not save installation log: {e}")

    try:
        input("\nPress Enter to exit...")
    except:
        pass
