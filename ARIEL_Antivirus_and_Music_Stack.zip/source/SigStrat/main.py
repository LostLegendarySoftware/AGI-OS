#!/usr/bin/env python3
"""
SigStrat - Advanced Signature-based Scanning Engine
Implements modern signature-based malware detection with pattern matching,
virus definition management, and quarantine capabilities.
Integrates with AGI-OS symbolic computing and ternary systems.
"""

import os
import sys
import json
import logging
import threading
import time
import hashlib
import re
import struct
import sqlite3
from typing import Dict, List, Any, Optional, Tuple, Union, Set
from datetime import datetime, timedelta
from collections import defaultdict, deque
from pathlib import Path
import fnmatch

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('SigStrat')

class SignatureDatabase:
    """Advanced signature database management"""

    def __init__(self, db_path: str = "signatures.db"):
        self.db_path = db_path
        self.connection = None
        self.signature_cache = {}
        self.last_update = None

    def initialize_database(self) -> bool:
        """Initialize signature database"""
        try:
            self.connection = sqlite3.connect(self.db_path, check_same_thread=False)
            self.connection.execute('PRAGMA journal_mode=WAL')  # Enable WAL mode for better concurrency

            # Create tables
            self._create_tables()

            # Load default signatures
            self._load_default_signatures()

            # Build cache
            self._build_signature_cache()

            logger.info(f"Signature database initialized with {len(self.signature_cache)} signatures")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize signature database: {e}")
            return False

    def _create_tables(self):
        """Create database tables for signatures"""
        tables = [
            """CREATE TABLE IF NOT EXISTS signatures (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                signature_type TEXT NOT NULL,
                pattern BLOB NOT NULL,
                pattern_text TEXT,
                offset INTEGER DEFAULT -1,
                file_types TEXT,
                threat_family TEXT,
                severity INTEGER DEFAULT 5,
                description TEXT,
                created_date TEXT,
                updated_date TEXT,
                active INTEGER DEFAULT 1
            )""",

            """CREATE TABLE IF NOT EXISTS hash_signatures (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hash_type TEXT NOT NULL,
                hash_value TEXT NOT NULL,
                file_size INTEGER,
                threat_name TEXT,
                threat_family TEXT,
                severity INTEGER DEFAULT 5,
                created_date TEXT,
                active INTEGER DEFAULT 1,
                UNIQUE(hash_type, hash_value)
            )""",

            """CREATE TABLE IF NOT EXISTS signature_updates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                update_date TEXT,
                signatures_added INTEGER,
                signatures_updated INTEGER,
                signatures_removed INTEGER,
                update_source TEXT
            )"""
        ]

        for table_sql in tables:
            self.connection.execute(table_sql)

        # Create indexes
        indexes = [
            'CREATE INDEX IF NOT EXISTS idx_signatures_type ON signatures(signature_type)',
            'CREATE INDEX IF NOT EXISTS idx_signatures_family ON signatures(threat_family)',
            'CREATE INDEX IF NOT EXISTS idx_hash_signatures_type ON hash_signatures(hash_type)',
            'CREATE INDEX IF NOT EXISTS idx_hash_signatures_value ON hash_signatures(hash_value)'
        ]

        for index_sql in indexes:
            self.connection.execute(index_sql)

        self.connection.commit()

    def _load_default_signatures(self):
        """Load default signature set"""
        try:
            # Common malware signatures (simplified for demonstration)
            default_signatures = [
                {
                    'name': 'EICAR_Test_Signature',
                    'signature_type': 'string',
                    'pattern': b'X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*',
                    'pattern_text': 'EICAR test string',
                    'threat_family': 'test',
                    'severity': 1,
                    'description': 'EICAR antivirus test file'
                },
                {
                    'name': 'PE_Suspicious_Section_Names',
                    'signature_type': 'regex',
                    'pattern': b'\.(UPX[0-9]?|packed|themida|aspack|fsg)',
                    'pattern_text': 'Suspicious PE section names',
                    'threat_family': 'packer',
                    'severity': 3,
                    'description': 'Suspicious PE section names indicating packed executable'
                },
                {
                    'name': 'Suspicious_Registry_Keys',
                    'signature_type': 'string',
                    'pattern': b'SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run',
                    'pattern_text': 'Registry autostart key',
                    'threat_family': 'persistence',
                    'severity': 4,
                    'description': 'References to registry autostart locations'
                },
                {
                    'name': 'Suspicious_API_Calls',
                    'signature_type': 'regex',
                    'pattern': b'(CreateRemoteThread|WriteProcessMemory|VirtualAllocEx|SetWindowsHookEx)',
                    'pattern_text': 'Suspicious API calls',
                    'threat_family': 'injection',
                    'severity': 6,
                    'description': 'API calls commonly used for process injection'
                },
                {
                    'name': 'Ransomware_Extensions',
                    'signature_type': 'regex',
                    'pattern': b'\.(locked|encrypted|crypto|vault|cerber|locky)',
                    'pattern_text': 'Ransomware file extensions',
                    'threat_family': 'ransomware',
                    'severity': 9,
                    'description': 'File extensions associated with ransomware'
                }
            ]

            # Insert default signatures
            for sig in default_signatures:
                try:
                    self.connection.execute(
                        """INSERT OR IGNORE INTO signatures 
                        (name, signature_type, pattern, pattern_text, threat_family, severity, description, created_date)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                        (sig['name'], sig['signature_type'], sig['pattern'], sig['pattern_text'],
                         sig['threat_family'], sig['severity'], sig['description'], 
                         datetime.now().isoformat())
                    )
                except Exception as e:
                    logger.error(f"Failed to insert signature {sig['name']}: {e}")

            # Common malware hashes (MD5, SHA1, SHA256)
            default_hashes = [
                {
                    'hash_type': 'md5',
                    'hash_value': '44d88612fea8a8f36de82e1278abb02f',  # EICAR test file MD5
                    'threat_name': 'EICAR-Test-File',
                    'threat_family': 'test',
                    'severity': 1
                },
                {
                    'hash_type': 'sha256',
                    'hash_value': '275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f',  # EICAR SHA256
                    'threat_name': 'EICAR-Test-File',
                    'threat_family': 'test',
                    'severity': 1
                }
            ]

            for hash_sig in default_hashes:
                try:
                    self.connection.execute(
                        """INSERT OR IGNORE INTO hash_signatures 
                        (hash_type, hash_value, threat_name, threat_family, severity, created_date)
                        VALUES (?, ?, ?, ?, ?, ?)""",
                        (hash_sig['hash_type'], hash_sig['hash_value'], hash_sig['threat_name'],
                         hash_sig['threat_family'], hash_sig['severity'], datetime.now().isoformat())
                    )
                except Exception as e:
                    logger.error(f"Failed to insert hash signature: {e}")

            self.connection.commit()
            logger.info("Default signatures loaded")

        except Exception as e:
            logger.error(f"Failed to load default signatures: {e}")

    def _build_signature_cache(self):
        """Build in-memory signature cache for fast lookups"""
        try:
            self.signature_cache = {
                'string': [],
                'regex': [],
                'binary': [],
                'hash': {'md5': {}, 'sha1': {}, 'sha256': {}}
            }

            # Load pattern signatures
            cursor = self.connection.execute(
                """SELECT name, signature_type, pattern, pattern_text, threat_family, severity, description
                FROM signatures WHERE active = 1"""
            )

            for row in cursor.fetchall():
                name, sig_type, pattern, pattern_text, family, severity, description = row

                signature_entry = {
                    'name': name,
                    'pattern': pattern,
                    'pattern_text': pattern_text,
                    'threat_family': family,
                    'severity': severity,
                    'description': description
                }

                if sig_type in self.signature_cache:
                    self.signature_cache[sig_type].append(signature_entry)

            # Load hash signatures
            cursor = self.connection.execute(
                """SELECT hash_type, hash_value, threat_name, threat_family, severity
                FROM hash_signatures WHERE active = 1"""
            )

            for row in cursor.fetchall():
                hash_type, hash_value, threat_name, family, severity = row

                if hash_type in self.signature_cache['hash']:
                    self.signature_cache['hash'][hash_type][hash_value] = {
                        'threat_name': threat_name,
                        'threat_family': family,
                        'severity': severity
                    }

            self.last_update = datetime.now()
            total_sigs = sum(len(v) if isinstance(v, list) else sum(len(h) for h in v.values()) for v in self.signature_cache.values())
            logger.info(f"Signature cache built: {total_sigs} signatures")

        except Exception as e:
            logger.error(f"Failed to build signature cache: {e}")

    def get_signatures_by_type(self, signature_type: str) -> List[Dict[str, Any]]:
        """Get signatures by type from cache"""
        return self.signature_cache.get(signature_type, [])

    def get_hash_signatures(self, hash_type: str) -> Dict[str, Any]:
        """Get hash signatures by type from cache"""
        return self.signature_cache.get('hash', {}).get(hash_type, {})

class PatternMatcher:
    """Advanced pattern matching engine"""

    def __init__(self):
        self.compiled_regex = {}
        self.string_patterns = []

    def initialize_patterns(self, signature_db: SignatureDatabase):
        """Initialize pattern matching with signatures from database"""
        try:
            # Compile regex patterns
            regex_signatures = signature_db.get_signatures_by_type('regex')
            for sig in regex_signatures:
                try:
                    pattern = sig['pattern'].decode('utf-8', errors='ignore')
                    compiled = re.compile(pattern, re.IGNORECASE | re.MULTILINE)
                    self.compiled_regex[sig['name']] = {
                        'pattern': compiled,
                        'signature': sig
                    }
                except Exception as e:
                    logger.error(f"Failed to compile regex {sig['name']}: {e}")

            # Load string patterns
            self.string_patterns = signature_db.get_signatures_by_type('string')

            logger.info(f"Pattern matcher initialized: {len(self.compiled_regex)} regex, {len(self.string_patterns)} string patterns")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize pattern matcher: {e}")
            return False

    def scan_data(self, data: bytes, file_path: str = "") -> List[Dict[str, Any]]:
        """Scan data for signature matches"""
        matches = []

        try:
            # Convert data to string for text-based matching
            try:
                text_data = data.decode('utf-8', errors='ignore')
            except:
                text_data = str(data)

            # Regex pattern matching
            for name, regex_info in self.compiled_regex.items():
                try:
                    if regex_info['pattern'].search(text_data):
                        matches.append({
                            'signature_name': name,
                            'signature_type': 'regex',
                            'match_type': 'pattern',
                            'threat_family': regex_info['signature']['threat_family'],
                            'severity': regex_info['signature']['severity'],
                            'description': regex_info['signature']['description'],
                            'file_path': file_path
                        })
                except Exception as e:
                    logger.error(f"Regex matching error for {name}: {e}")

            # String pattern matching
            for sig in self.string_patterns:
                try:
                    if sig['pattern'] in data:
                        matches.append({
                            'signature_name': sig['name'],
                            'signature_type': 'string',
                            'match_type': 'exact',
                            'threat_family': sig['threat_family'],
                            'severity': sig['severity'],
                            'description': sig['description'],
                            'file_path': file_path
                        })
                except Exception as e:
                    logger.error(f"String matching error for {sig['name']}: {e}")

        except Exception as e:
            logger.error(f"Data scanning error: {e}")

        return matches

class HashScanner:
    """Hash-based malware detection"""

    def __init__(self):
        self.hash_signatures = {}

    def initialize_hashes(self, signature_db: SignatureDatabase):
        """Initialize hash signatures"""
        try:
            self.hash_signatures = {
                'md5': signature_db.get_hash_signatures('md5'),
                'sha1': signature_db.get_hash_signatures('sha1'),
                'sha256': signature_db.get_hash_signatures('sha256')
            }

            total_hashes = sum(len(hashes) for hashes in self.hash_signatures.values())
            logger.info(f"Hash scanner initialized with {total_hashes} hash signatures")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize hash scanner: {e}")
            return False

    def scan_file_hashes(self, file_path: str) -> List[Dict[str, Any]]:
        """Scan file hashes against signature database"""
        matches = []

        try:
            if not os.path.exists(file_path):
                return matches

            # Calculate file hashes
            file_hashes = self._calculate_file_hashes(file_path)

            # Check against signature database
            for hash_type, hash_value in file_hashes.items():
                if hash_type in self.hash_signatures:
                    if hash_value in self.hash_signatures[hash_type]:
                        sig_info = self.hash_signatures[hash_type][hash_value]
                        matches.append({
                            'signature_name': f"{hash_type.upper()}_{hash_value[:8]}",
                            'signature_type': 'hash',
                            'match_type': hash_type,
                            'hash_value': hash_value,
                            'threat_name': sig_info['threat_name'],
                            'threat_family': sig_info['threat_family'],
                            'severity': sig_info['severity'],
                            'description': f"File hash matches known {sig_info['threat_family']} malware",
                            'file_path': file_path
                        })

        except Exception as e:
            logger.error(f"Hash scanning error for {file_path}: {e}")

        return matches

    def _calculate_file_hashes(self, file_path: str) -> Dict[str, str]:
        """Calculate MD5, SHA1, and SHA256 hashes of file"""
        hashes = {}

        try:
            with open(file_path, 'rb') as f:
                data = f.read()

            hashes['md5'] = hashlib.md5(data).hexdigest()
            hashes['sha1'] = hashlib.sha1(data).hexdigest()
            hashes['sha256'] = hashlib.sha256(data).hexdigest()

        except Exception as e:
            logger.error(f"Hash calculation error for {file_path}: {e}")

        return hashes

class SigStrat:
    """Enhanced SigStrat signature-based scanning engine"""

    def __init__(self, config_path: str = "config.json"):
        """Initialize SigStrat with comprehensive signature-based detection"""
        self.config = self._load_config(config_path)
        self.symbolic_interface = None
        self.ternary_interface = None

        # Initialize components
        self.signature_db = SignatureDatabase()
        self.pattern_matcher = PatternMatcher()
        self.hash_scanner = HashScanner()

        self.scan_history = deque(maxlen=1000)
        self.scanning_active = False
        self.scan_statistics = {
            'total_scans': 0,
            'threats_detected': 0,
            'signatures_matched': defaultdict(int)
        }

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                logger.info("Configuration loaded successfully")
                return config
        except FileNotFoundError:
            logger.warning("Config file not found, using defaults")
            return self._get_default_config()
        except json.JSONDecodeError as e:
            logger.error(f"Config file parsing error: {e}")
            return self._get_default_config()

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "signature_scanning": {
                "pattern_matching": True,
                "hash_scanning": True,
                "auto_update": True
            },
            "scan_settings": {
                "max_file_size": 100 * 1024 * 1024,  # 100MB
                "scan_archives": True,
                "deep_scan": False
            },
            "integration": {
                "symbolic_computing": True,
                "ternary_systems": True
            }
        }

    def initialize_signature_engine(self) -> bool:
        """Initialize comprehensive signature-based scanning engine"""
        logger.info("Initializing SigStrat signature engine...")

        try:
            # Connect to AGI-OS systems
            self._connect_to_symbolic_computing()
            self._connect_to_ternary_systems()

            # Initialize signature database
            if not self.signature_db.initialize_database():
                logger.error("Failed to initialize signature database")
                return False

            # Initialize pattern matcher
            if not self.pattern_matcher.initialize_patterns(self.signature_db):
                logger.error("Failed to initialize pattern matcher")
                return False

            # Initialize hash scanner
            if not self.hash_scanner.initialize_hashes(self.signature_db):
                logger.error("Failed to initialize hash scanner")
                return False

            self.scanning_active = True
            logger.info("SigStrat signature engine initialized successfully")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize signature engine: {e}")
            return False

    def _connect_to_symbolic_computing(self):
        """Connect to AGI-OS symbolic computing system"""
        symbolic_path = "../../assets/bin/symbolic/"
        if os.path.exists(symbolic_path):
            logger.info("Connected to AGI-OS symbolic computing")
            self.symbolic_interface = {
                'path': symbolic_path,
                'connected': True,
                'capabilities': ['pattern_matching', 'symbolic_analysis']
            }
        else:
            logger.warning("AGI-OS symbolic computing not found")

    def _connect_to_ternary_systems(self):
        """Connect to AGI-OS ternary computing system"""
        ternary_path = "../../assets/etc/ternary/"
        if os.path.exists(ternary_path):
            logger.info("Connected to AGI-OS ternary systems")
            self.ternary_interface = {
                'path': ternary_path,
                'connected': True,
                'capabilities': ['ternary_logic', 'advanced_analysis']
            }
        else:
            logger.warning("AGI-OS ternary systems not found")

    def scan_file(self, file_path: str) -> Dict[str, Any]:
        """Perform comprehensive signature-based file scan"""
        logger.info(f"Starting signature scan of file: {file_path}")

        scan_result = {
            'scan_id': hashlib.md5(f"{file_path}{datetime.now()}".encode()).hexdigest()[:8],
            'file_path': file_path,
            'timestamp': datetime.now().isoformat(),
            'file_info': {},
            'hash_matches': [],
            'pattern_matches': [],
            'symbolic_analysis': {},
            'ternary_analysis': {},
            'threat_detected': False,
            'matches': []
        }

        try:
            if not os.path.exists(file_path):
                scan_result['error'] = 'File not found'
                return scan_result

            # Get file information
            scan_result['file_info'] = self._get_file_info(file_path)

            # Check file size limits
            max_size = self.config.get("scan_settings", {}).get("max_file_size", 100 * 1024 * 1024)
            if scan_result['file_info']['size'] > max_size:
                scan_result['warning'] = f'File size exceeds limit ({max_size} bytes)'
                return scan_result

            # Hash-based scanning
            logger.info("Performing hash-based scanning...")
            hash_matches = self.hash_scanner.scan_file_hashes(file_path)
            scan_result['hash_matches'] = hash_matches
            scan_result['matches'].extend(hash_matches)

            # Pattern-based scanning
            logger.info("Performing pattern-based scanning...")
            with open(file_path, 'rb') as f:
                file_data = f.read()

            pattern_matches = self.pattern_matcher.scan_data(file_data, file_path)
            scan_result['pattern_matches'] = pattern_matches
            scan_result['matches'].extend(pattern_matches)

            # Symbolic computing analysis
            if self.symbolic_interface:
                scan_result['symbolic_analysis'] = self._perform_symbolic_analysis(file_path, file_data)

            # Ternary systems analysis
            if self.ternary_interface:
                scan_result['ternary_analysis'] = self._perform_ternary_analysis(file_path, file_data)

            # Determine if threat detected
            scan_result['threat_detected'] = len(scan_result['matches']) > 0

            # Update statistics
            self.scan_statistics['total_scans'] += 1
            if scan_result['threat_detected']:
                self.scan_statistics['threats_detected'] += 1
                for match in scan_result['matches']:
                    self.scan_statistics['signatures_matched'][match['signature_name']] += 1

            # Store scan result
            self.scan_history.append(scan_result)

            logger.info(f"Scan completed: {'THREAT DETECTED' if scan_result['threat_detected'] else 'CLEAN'}")

        except Exception as e:
            logger.error(f"File scan error: {e}")
            scan_result['error'] = str(e)

        return scan_result

    def _get_file_info(self, file_path: str) -> Dict[str, Any]:
        """Get basic file information"""
        try:
            stat_info = os.stat(file_path)
            return {
                'size': stat_info.st_size,
                'creation_time': stat_info.st_ctime,
                'modification_time': stat_info.st_mtime,
                'access_time': stat_info.st_atime,
                'extension': Path(file_path).suffix.lower(),
                'name': os.path.basename(file_path)
            }
        except Exception as e:
            logger.error(f"File info error: {e}")
            return {}

    def _perform_symbolic_analysis(self, file_path: str, file_data: bytes) -> Dict[str, Any]:
        """Perform symbolic computing analysis"""
        analysis = {'enabled': True, 'results': []}

        try:
            # Use symbolic computing for advanced pattern matching
            symbolic_patterns = [
                b'\x4d\x5a',  # PE header
                b'\x7f\x45\x4c\x46',  # ELF header
                b'\xca\xfe\xba\xbe',  # Java class file
            ]

            for pattern in symbolic_patterns:
                if pattern in file_data:
                    analysis['results'].append({
                        'pattern': pattern.hex(),
                        'description': 'Executable file header detected',
                        'symbolic_match': True
                    })

        except Exception as e:
            logger.error(f"Symbolic analysis error: {e}")
            analysis['error'] = str(e)

        return analysis

    def _perform_ternary_analysis(self, file_path: str, file_data: bytes) -> Dict[str, Any]:
        """Perform ternary systems analysis"""
        analysis = {'enabled': True, 'ternary_score': 0, 'analysis': []}

        try:
            # Simulate ternary logic analysis
            entropy_regions = []
            chunk_size = 256
            for i in range(0, min(len(file_data), 2048), chunk_size):
                chunk = file_data[i:i + chunk_size]
                unique_bytes = len(set(chunk))

                if unique_bytes < 50:
                    entropy_regions.append(0)  # Low entropy
                elif unique_bytes < 150:
                    entropy_regions.append(1)  # Medium entropy
                else:
                    entropy_regions.append(2)  # High entropy

            # Calculate ternary score
            if entropy_regions:
                analysis['ternary_score'] = sum(entropy_regions) / len(entropy_regions)
                analysis['analysis'].append({
                    'metric': 'entropy_distribution',
                    'ternary_values': entropy_regions,
                    'interpretation': 'File entropy analysis using ternary logic'
                })

        except Exception as e:
            logger.error(f"Ternary analysis error: {e}")
            analysis['error'] = str(e)

        return analysis

    def get_scan_statistics(self) -> Dict[str, Any]:
        """Get scanning statistics"""
        stats = dict(self.scan_statistics)
        stats['signature_count'] = {
            'total': len(self.signature_db.signature_cache.get('string', [])) + 
                    len(self.signature_db.signature_cache.get('regex', [])),
            'hash_signatures': sum(len(h) for h in self.signature_db.signature_cache.get('hash', {}).values())
        }
        stats['last_update'] = self.signature_db.last_update.isoformat() if self.signature_db.last_update else None

        return stats

if __name__ == "__main__":
    # Initialize and test SigStrat
    scanner = SigStrat()

    if scanner.initialize_signature_engine():
        print("SigStrat signature engine initialized successfully")

        # Test scan on available files
        test_files = ['/bin/ls', '/usr/bin/python3', './source/SigStrat/main.py']
        available_files = [f for f in test_files if os.path.exists(f)]

        if available_files:
            print(f"\nTesting signature scan on: {available_files[0]}")
            scan_result = scanner.scan_file(available_files[0])
            print("\nScan Results:")
            print(json.dumps({
                'file_path': scan_result['file_path'],
                'threat_detected': scan_result['threat_detected'],
                'matches': len(scan_result['matches'])
            }, indent=2))

        # Show statistics
        stats = scanner.get_scan_statistics()
        print("\nScanning Statistics:")
        print(json.dumps(stats, indent=2))

    else:
        print("Failed to initialize SigStrat signature engine")
