#!/usr/bin/env python3
"""
VoiceApproval - Enterprise Voice Recognition for Security Authentication
Implements voice biometric authentication for approving critical security actions.
Based on research: Enterprise voice biometrics with multi-factor authentication.
"""

import os
import sys
import json
import logging
import threading
import time
import asyncio
import wave
import pyaudio
from typing import Dict, List, Any, Optional, Callable, Tuple
from datetime import datetime, timedelta
import numpy as np
from dataclasses import dataclass
import hashlib
import base64

@dataclass
class VoiceProfile:
    """Voice profile for user authentication"""
    user_id: str
    voice_features: Dict[str, Any]
    enrollment_date: datetime
    last_used: datetime
    confidence_scores: List[float]

@dataclass
class VoiceApprovalRequest:
    """Voice approval request structure"""
    request_id: str
    action_description: str
    required_phrases: List[str]
    timeout_seconds: int
    timestamp: datetime
    status: str  # pending, approved, denied, timeout

class VoiceFeatureExtractor:
    """Extract voice features for biometric authentication"""

    def __init__(self):
        self.logger = logging.getLogger('VoiceFeatureExtractor')

    def extract_mfcc_features(self, audio_data: np.ndarray, sample_rate: int = 16000) -> np.ndarray:
        """
        Extract MFCC (Mel-Frequency Cepstral Coefficients) features
        Standard approach for voice recognition systems
        """
        try:
            # Pre-emphasis filter
            pre_emphasis = 0.97
            emphasized_signal = np.append(audio_data[0], audio_data[1:] - pre_emphasis * audio_data[:-1])

            # Frame the signal
            frame_size = 0.025  # 25ms
            frame_stride = 0.01  # 10ms
            frame_length = int(round(frame_size * sample_rate))
            frame_step = int(round(frame_stride * sample_rate))
            signal_length = len(emphasized_signal)
            num_frames = int(np.ceil(float(np.abs(signal_length - frame_length)) / frame_step))

            # Pad signal to make sure all frames have equal number of samples
            pad_signal_length = num_frames * frame_step + frame_length
            z = np.zeros((pad_signal_length - signal_length))
            pad_signal = np.append(emphasized_signal, z)

            # Create frames
            indices = np.tile(np.arange(0, frame_length), (num_frames, 1)) +                      np.tile(np.arange(0, num_frames * frame_step, frame_step), (frame_length, 1)).T
            frames = pad_signal[indices.astype(np.int32, copy=False)]

            # Apply Hamming window
            frames *= np.hamming(frame_length)

            # Compute FFT and power spectrum
            NFFT = 512
            mag_frames = np.absolute(np.fft.rfft(frames, NFFT))
            pow_frames = ((1.0 / NFFT) * ((mag_frames) ** 2))

            # Apply Mel filter bank
            nfilt = 40
            low_freq_mel = 0
            high_freq_mel = (2595 * np.log10(1 + (sample_rate / 2) / 700))
            mel_points = np.linspace(low_freq_mel, high_freq_mel, nfilt + 2)
            hz_points = (700 * (10**(mel_points / 2595) - 1))
            bin = np.floor((NFFT + 1) * hz_points / sample_rate)

            fbank = np.zeros((nfilt, int(np.floor(NFFT / 2 + 1))))
            for m in range(1, nfilt + 1):
                f_m_minus = int(bin[m - 1])
                f_m = int(bin[m])
                f_m_plus = int(bin[m + 1])

                for k in range(f_m_minus, f_m):
                    fbank[m - 1, k] = (k - bin[m - 1]) / (bin[m] - bin[m - 1])
                for k in range(f_m, f_m_plus):
                    fbank[m - 1, k] = (bin[m + 1] - k) / (bin[m + 1] - bin[m])

            filter_banks = np.dot(pow_frames, fbank.T)
            filter_banks = np.where(filter_banks == 0, np.finfo(float).eps, filter_banks)
            filter_banks = 20 * np.log10(filter_banks)

            # Compute MFCC
            num_ceps = 12
            mfcc = np.zeros((num_frames, num_ceps))
            for i in range(num_ceps):
                mfcc[:, i] = np.sum(filter_banks * np.cos(np.pi * i * (2 * np.arange(nfilt) + 1) / (2 * nfilt)), axis=1)

            # Mean normalize
            mfcc = mfcc - np.mean(mfcc, axis=0)

            return mfcc

        except Exception as e:
            self.logger.error(f"MFCC extraction failed: {e}")
            return np.array([])

    def extract_pitch_features(self, audio_data: np.ndarray, sample_rate: int = 16000) -> Dict[str, float]:
        """Extract pitch-based features for voice identification"""
        try:
            # Simple autocorrelation-based pitch detection
            autocorr = np.correlate(audio_data, audio_data, mode='full')
            autocorr = autocorr[autocorr.size // 2:]

            # Find pitch period
            min_period = int(sample_rate / 500)  # 500 Hz max
            max_period = int(sample_rate / 50)   # 50 Hz min

            if len(autocorr) > max_period:
                pitch_autocorr = autocorr[min_period:max_period]
                if len(pitch_autocorr) > 0:
                    pitch_period = np.argmax(pitch_autocorr) + min_period
                    fundamental_freq = sample_rate / pitch_period
                else:
                    fundamental_freq = 0
            else:
                fundamental_freq = 0

            # Calculate pitch statistics
            pitch_features = {
                'fundamental_frequency': fundamental_freq,
                'pitch_variance': np.var(autocorr[:min(len(autocorr), 1000)]),
                'pitch_mean': np.mean(autocorr[:min(len(autocorr), 1000)])
            }

            return pitch_features

        except Exception as e:
            self.logger.error(f"Pitch extraction failed: {e}")
            return {'fundamental_frequency': 0, 'pitch_variance': 0, 'pitch_mean': 0}

class SpeechRecognizer:
    """Speech recognition for phrase verification"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger('SpeechRecognizer')

    def recognize_speech(self, audio_data: np.ndarray, sample_rate: int = 16000) -> Optional[str]:
        """
        Recognize speech from audio data
        In production, this would use enterprise speech recognition APIs
        For now, implements basic pattern matching
        """
        try:
            # Simple energy-based speech detection
            energy = np.sum(audio_data ** 2)
            if energy < 0.01:  # Too quiet
                return None

            # In a real implementation, this would use:
            # - Google Speech-to-Text API
            # - Azure Speech Services
            # - AWS Transcribe
            # - IBM Watson Speech to Text

            # For demonstration, simulate recognition based on audio characteristics
            duration = len(audio_data) / sample_rate

            # Simple heuristic based on duration and energy
            if 2.0 <= duration <= 4.0 and energy > 0.1:
                # Simulate recognition of approval phrases
                required_phrases = self.config.get('required_phrases', [])
                if required_phrases:
                    # Return first phrase as simulation
                    return required_phrases[0]

            return None

        except Exception as e:
            self.logger.error(f"Speech recognition failed: {e}")
            return None

class VoiceBiometricMatcher:
    """Voice biometric matching for user authentication"""

    def __init__(self):
        self.logger = logging.getLogger('VoiceBiometricMatcher')
        self.enrolled_profiles = {}

    def enroll_voice_profile(self, user_id: str, audio_samples: List[np.ndarray], 
                           sample_rate: int = 16000) -> bool:
        """Enroll a new voice profile"""
        try:
            feature_extractor = VoiceFeatureExtractor()
            all_features = []

            for audio_data in audio_samples:
                # Extract MFCC features
                mfcc_features = feature_extractor.extract_mfcc_features(audio_data, sample_rate)

                # Extract pitch features
                pitch_features = feature_extractor.extract_pitch_features(audio_data, sample_rate)

                if len(mfcc_features) > 0:
                    # Combine features
                    combined_features = {
                        'mfcc_mean': np.mean(mfcc_features, axis=0).tolist(),
                        'mfcc_std': np.std(mfcc_features, axis=0).tolist(),
                        'pitch_features': pitch_features
                    }
                    all_features.append(combined_features)

            if all_features:
                # Create voice profile
                voice_profile = VoiceProfile(
                    user_id=user_id,
                    voice_features={'samples': all_features},
                    enrollment_date=datetime.now(),
                    last_used=datetime.now(),
                    confidence_scores=[]
                )

                self.enrolled_profiles[user_id] = voice_profile
                self.logger.info(f"Voice profile enrolled for user: {user_id}")
                return True

            return False

        except Exception as e:
            self.logger.error(f"Voice enrollment failed: {e}")
            return False

    def verify_voice(self, user_id: str, audio_data: np.ndarray, 
                    sample_rate: int = 16000) -> Tuple[bool, float]:
        """Verify voice against enrolled profile"""
        try:
            if user_id not in self.enrolled_profiles:
                return False, 0.0

            profile = self.enrolled_profiles[user_id]
            feature_extractor = VoiceFeatureExtractor()

            # Extract features from test audio
            test_mfcc = feature_extractor.extract_mfcc_features(audio_data, sample_rate)
            test_pitch = feature_extractor.extract_pitch_features(audio_data, sample_rate)

            if len(test_mfcc) == 0:
                return False, 0.0

            test_mfcc_mean = np.mean(test_mfcc, axis=0)
            test_mfcc_std = np.std(test_mfcc, axis=0)

            # Compare with enrolled samples
            similarities = []

            for enrolled_sample in profile.voice_features['samples']:
                enrolled_mfcc_mean = np.array(enrolled_sample['mfcc_mean'])
                enrolled_mfcc_std = np.array(enrolled_sample['mfcc_std'])
                enrolled_pitch = enrolled_sample['pitch_features']

                # Calculate MFCC similarity (cosine similarity)
                if len(test_mfcc_mean) == len(enrolled_mfcc_mean):
                    mfcc_similarity = np.dot(test_mfcc_mean, enrolled_mfcc_mean) /                                     (np.linalg.norm(test_mfcc_mean) * np.linalg.norm(enrolled_mfcc_mean))
                else:
                    mfcc_similarity = 0.0

                # Calculate pitch similarity
                pitch_diff = abs(test_pitch['fundamental_frequency'] - 
                               enrolled_pitch['fundamental_frequency'])
                pitch_similarity = max(0, 1 - (pitch_diff / 100))  # Normalize

                # Combined similarity
                combined_similarity = 0.7 * mfcc_similarity + 0.3 * pitch_similarity
                similarities.append(max(0, combined_similarity))

            # Calculate final confidence
            if similarities:
                confidence = np.mean(similarities)
                profile.confidence_scores.append(confidence)
                profile.last_used = datetime.now()

                # Threshold for verification
                threshold = self.config.get('confidence_threshold', 0.75)
                verified = confidence >= threshold

                return verified, confidence

            return False, 0.0

        except Exception as e:
            self.logger.error(f"Voice verification failed: {e}")
            return False, 0.0

class AudioRecorder:
    """Audio recording for voice capture"""

    def __init__(self, sample_rate: int = 16000, channels: int = 1):
        self.sample_rate = sample_rate
        self.channels = channels
        self.chunk_size = 1024
        self.audio_format = pyaudio.paInt16
        self.logger = logging.getLogger('AudioRecorder')

    def record_audio(self, duration_seconds: float) -> Optional[np.ndarray]:
        """Record audio for specified duration"""
        try:
            audio = pyaudio.PyAudio()

            # Open stream
            stream = audio.open(
                format=self.audio_format,
                channels=self.channels,
                rate=self.sample_rate,
                input=True,
                frames_per_buffer=self.chunk_size
            )

            frames = []
            num_chunks = int(self.sample_rate * duration_seconds / self.chunk_size)

            self.logger.info(f"Recording audio for {duration_seconds} seconds...")

            for _ in range(num_chunks):
                data = stream.read(self.chunk_size)
                frames.append(data)

            # Stop and close stream
            stream.stop_stream()
            stream.close()
            audio.terminate()

            # Convert to numpy array
            audio_data = b''.join(frames)
            audio_array = np.frombuffer(audio_data, dtype=np.int16).astype(np.float32)
            audio_array = audio_array / 32768.0  # Normalize to [-1, 1]

            self.logger.info("Audio recording completed")
            return audio_array

        except Exception as e:
            self.logger.error(f"Audio recording failed: {e}")
            return None

class VoiceApproval:
    """Main voice approval system"""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.speech_recognizer = SpeechRecognizer(config)
        self.biometric_matcher = VoiceBiometricMatcher()
        self.audio_recorder = AudioRecorder()

        # Active requests
        self.active_requests = {}
        self.request_counter = 0

        # Setup logging
        self.logger = logging.getLogger('VoiceApproval')

        # Load enrolled profiles
        self._load_voice_profiles()

    def _load_voice_profiles(self):
        """Load existing voice profiles"""
        profiles_file = self.config.get('profiles_file', 'voice_profiles.json')
        if os.path.exists(profiles_file):
            try:
                with open(profiles_file, 'r') as f:
                    profiles_data = json.load(f)
                    # Convert to VoiceProfile objects
                    for user_id, profile_data in profiles_data.items():
                        profile = VoiceProfile(
                            user_id=user_id,
                            voice_features=profile_data['voice_features'],
                            enrollment_date=datetime.fromisoformat(profile_data['enrollment_date']),
                            last_used=datetime.fromisoformat(profile_data['last_used']),
                            confidence_scores=profile_data['confidence_scores']
                        )
                        self.biometric_matcher.enrolled_profiles[user_id] = profile
                self.logger.info(f"Loaded {len(profiles_data)} voice profiles")
            except Exception as e:
                self.logger.error(f"Failed to load voice profiles: {e}")

    def enroll_user_voice(self, user_id: str, num_samples: int = 3) -> bool:
        """Enroll a user's voice for biometric authentication"""
        self.logger.info(f"Starting voice enrollment for user: {user_id}")

        audio_samples = []

        for i in range(num_samples):
            print(f"Please speak one of the required phrases (sample {i+1}/{num_samples})")
            print("Required phrases:", self.config.get('required_phrases', []))
            input("Press Enter when ready to record...")

            # Record audio sample
            audio_data = self.audio_recorder.record_audio(3.0)  # 3 seconds

            if audio_data is not None:
                audio_samples.append(audio_data)
                print(f"Sample {i+1} recorded successfully")
            else:
                print(f"Failed to record sample {i+1}")
                return False

        # Enroll the voice profile
        success = self.biometric_matcher.enroll_voice_profile(user_id, audio_samples)

        if success:
            self._save_voice_profiles()
            self.logger.info(f"Voice enrollment completed for user: {user_id}")

        return success

    def request_approval(self, action_description: str, timeout: int = 30) -> bool:
        """Request voice approval for a critical action"""
        request_id = f"req_{self.request_counter}"
        self.request_counter += 1

        # Create approval request
        request = VoiceApprovalRequest(
            request_id=request_id,
            action_description=action_description,
            required_phrases=self.config.get('required_phrases', []),
            timeout_seconds=timeout,
            timestamp=datetime.now(),
            status='pending'
        )

        self.active_requests[request_id] = request

        self.logger.info(f"Voice approval requested for: {action_description}")

        # Start approval process
        return self._process_approval_request(request)

    def _process_approval_request(self, request: VoiceApprovalRequest) -> bool:
        """Process a voice approval request"""
        try:
            print(f"\nVOICE APPROVAL REQUIRED")
            print(f"Action: {request.action_description}")
            print(f"Please speak one of these phrases:")
            for phrase in request.required_phrases:
                print(f"  - '{phrase}'")
            print(f"Timeout: {request.timeout_seconds} seconds")

            input("Press Enter when ready to speak...")

            # Record audio
            audio_data = self.audio_recorder.record_audio(5.0)  # 5 seconds max

            if audio_data is None:
                request.status = 'denied'
                return False

            # Recognize speech
            recognized_text = self.speech_recognizer.recognize_speech(audio_data)

            if recognized_text and recognized_text in request.required_phrases:
                # Check voice biometrics if profiles exist
                if self.biometric_matcher.enrolled_profiles:
                    # For demo, use first enrolled user
                    user_id = list(self.biometric_matcher.enrolled_profiles.keys())[0]
                    verified, confidence = self.biometric_matcher.verify_voice(user_id, audio_data)

                    if verified:
                        request.status = 'approved'
                        self.logger.info(f"Voice approval granted (confidence: {confidence:.2f})")
                        return True
                    else:
                        request.status = 'denied'
                        self.logger.warning(f"Voice verification failed (confidence: {confidence:.2f})")
                        return False
                else:
                    # No enrolled profiles, approve based on phrase recognition only
                    request.status = 'approved'
                    self.logger.info("Voice approval granted (phrase recognition only)")
                    return True
            else:
                request.status = 'denied'
                self.logger.warning("Voice approval denied - phrase not recognized")
                return False

        except Exception as e:
            self.logger.error(f"Voice approval process failed: {e}")
            request.status = 'denied'
            return False
        finally:
            # Clean up request
            if request.request_id in self.active_requests:
                del self.active_requests[request.request_id]

    def _save_voice_profiles(self):
        """Save voice profiles to file"""
        profiles_file = self.config.get('profiles_file', 'voice_profiles.json')
        try:
            profiles_data = {}
            for user_id, profile in self.biometric_matcher.enrolled_profiles.items():
                profiles_data[user_id] = {
                    'voice_features': profile.voice_features,
                    'enrollment_date': profile.enrollment_date.isoformat(),
                    'last_used': profile.last_used.isoformat(),
                    'confidence_scores': profile.confidence_scores
                }

            with open(profiles_file, 'w') as f:
                json.dump(profiles_data, f, indent=2)

        except Exception as e:
            self.logger.error(f"Failed to save voice profiles: {e}")

    def get_approval_status(self, request_id: str) -> Optional[str]:
        """Get status of an approval request"""
        if request_id in self.active_requests:
            return self.active_requests[request_id].status
        return None

    def shutdown(self):
        """Shutdown voice approval system"""
        self._save_voice_profiles()
        self.logger.info("Voice approval system shutdown")

# Main execution for testing
if __name__ == "__main__":
    # Test configuration
    test_config = {
        "confidence_threshold": 0.75,
        "timeout_seconds": 30,
        "required_phrases": [
            "approve security action",
            "confirm installation",
            "authorize critical operation"
        ],
        "profiles_file": "test_voice_profiles.json"
    }

    # Initialize voice approval system
    voice_approval = VoiceApproval(test_config)

    print("Voice Approval System Test")
    print("1. Enroll voice profile")
    print("2. Test approval request")

    choice = input("Enter choice (1 or 2): ")

    if choice == "1":
        user_id = input("Enter user ID: ")
        success = voice_approval.enroll_user_voice(user_id)
        print(f"Enrollment {'successful' if success else 'failed'}")

    elif choice == "2":
        action = input("Enter action description: ")
        approved = voice_approval.request_approval(action)
        print(f"Approval {'granted' if approved else 'denied'}")

    voice_approval.shutdown()
