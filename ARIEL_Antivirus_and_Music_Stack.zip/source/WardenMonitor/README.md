# WardenMonitor - Real-time Process Monitoring System

## Overview
WardenMonitor provides real-time process and system monitoring integrated with AGI-OS HALO guardian system.

## AGI-OS Integration
- **HALO Guardian**: Integrates with existing guardian system in `assets/etc/security/guardian/`
- **DOM0 Layer**: Monitors applications and services in DOM0 layer
- **HAVEN Layer**: Memory monitoring through HAVEN memory management

## Features
- Real-time process creation monitoring
- File system access pattern analysis
- Network connection tracking
- Integration with AGI-OS security layers
- Automated threat assessment and alerting

## Configuration
Configured through `config.json` with thresholds and AGI-OS integration settings.

## Usage
```python
from main import WardenMonitor

monitor = WardenMonitor()
monitor.start_real_time_monitoring()
status = monitor.get_monitoring_status()
alerts = monitor.get_alerts()
```
