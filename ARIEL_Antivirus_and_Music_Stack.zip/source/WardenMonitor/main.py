#!/usr/bin/env python3
"""
WardenMonitor - Advanced Real-time Process Monitoring System
Implements modern behavioral analysis, anomaly detection, and real-time monitoring
based on current antivirus techniques. Integrates with AGI-OS HALO guardian system.
"""

import os
import sys
import json
import time
import logging
import threading
import psutil
import hashlib
import statistics
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from collections import defaultdict, deque
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('WardenMonitor')

class BehavioralAnalysisEngine:
    """Advanced behavioral analysis for process monitoring"""

    def __init__(self):
        self.behavior_patterns = {}
        self.baseline_behaviors = {}
        self.anomaly_thresholds = {}
        self.learning_mode = True
        self.analysis_window = 300  # 5 minutes

    def initialize_behavioral_analysis(self):
        """Initialize behavioral analysis patterns and thresholds"""
        try:
            self._setup_behavior_patterns()
            self._setup_anomaly_thresholds()
            self._create_baseline_behaviors()
            logger.info("Behavioral analysis engine initialized")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize behavioral analysis: {e}")
            return False

    def _setup_behavior_patterns(self):
        """Setup behavioral patterns for threat detection"""
        self.behavior_patterns = {
            'file_system_abuse': {
                'indicators': ['rapid_file_creation', 'mass_file_deletion', 'suspicious_file_access'],
                'thresholds': {'file_ops_per_minute': 100, 'deletion_ratio': 0.8},
                'severity': 'high'
            },
            'network_anomaly': {
                'indicators': ['unusual_connections', 'data_exfiltration', 'c2_communication'],
                'thresholds': {'connections_per_minute': 50, 'data_transfer_mb': 100},
                'severity': 'critical'
            },
            'process_injection': {
                'indicators': ['memory_manipulation', 'dll_injection', 'process_hollowing'],
                'thresholds': {'memory_writes': 20, 'cross_process_access': 5},
                'severity': 'critical'
            },
            'privilege_escalation': {
                'indicators': ['token_manipulation', 'service_creation', 'registry_modification'],
                'thresholds': {'privilege_changes': 3, 'system_modifications': 10},
                'severity': 'high'
            },
            'persistence_mechanism': {
                'indicators': ['startup_modification', 'scheduled_task_creation', 'service_installation'],
                'thresholds': {'persistence_attempts': 2, 'autostart_entries': 5},
                'severity': 'medium'
            },
            'data_collection': {
                'indicators': ['keylogging', 'screen_capture', 'clipboard_access'],
                'thresholds': {'input_monitoring': 10, 'data_access_frequency': 30},
                'severity': 'high'
            }
        }

    def _setup_anomaly_thresholds(self):
        """Setup thresholds for anomaly detection"""
        self.anomaly_thresholds = {
            'cpu_usage': {'normal_max': 80, 'spike_threshold': 95, 'sustained_threshold': 90},
            'memory_usage': {'normal_max': 85, 'spike_threshold': 95, 'growth_rate': 10},
            'disk_io': {'normal_ops_per_sec': 100, 'spike_threshold': 1000},
            'network_io': {'normal_bytes_per_sec': 1048576, 'spike_threshold': 10485760},  # 1MB, 10MB
            'file_operations': {'normal_per_minute': 50, 'spike_threshold': 200},
            'process_creation': {'normal_per_minute': 10, 'spike_threshold': 50}
        }

    def _create_baseline_behaviors(self):
        """Create baseline of normal system behaviors"""
        try:
            # Collect initial system metrics for baseline
            processes = list(psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']))

            self.baseline_behaviors = {
                'process_count': len(processes),
                'avg_cpu_usage': statistics.mean([p.info['cpu_percent'] or 0 for p in processes]),
                'avg_memory_usage': statistics.mean([p.info['memory_percent'] or 0 for p in processes]),
                'system_load': psutil.cpu_percent(interval=1),
                'memory_usage': psutil.virtual_memory().percent,
                'disk_usage': psutil.disk_usage('/').percent if os.path.exists('/') else 0,
                'network_connections': len(psutil.net_connections()),
                'timestamp': datetime.now().isoformat()
            }

            logger.info("Behavioral baseline created")
        except Exception as e:
            logger.warning(f"Baseline creation warning: {e}")
            self.baseline_behaviors = {}

    def analyze_process_behavior(self, process_info: Dict[str, Any], 
                               historical_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze individual process behavior for anomalies"""
        analysis_result = {
            'process_id': process_info.get('pid'),
            'process_name': process_info.get('name'),
            'anomalies': [],
            'risk_score': 0,
            'behavioral_flags': []
        }

        try:
            # Analyze CPU usage patterns
            cpu_anomalies = self._analyze_cpu_behavior(process_info, historical_data)
            analysis_result['anomalies'].extend(cpu_anomalies)

            # Analyze memory usage patterns
            memory_anomalies = self._analyze_memory_behavior(process_info, historical_data)
            analysis_result['anomalies'].extend(memory_anomalies)

            # Analyze I/O patterns
            io_anomalies = self._analyze_io_behavior(process_info, historical_data)
            analysis_result['anomalies'].extend(io_anomalies)

            # Analyze network behavior
            network_anomalies = self._analyze_network_behavior(process_info)
            analysis_result['anomalies'].extend(network_anomalies)

            # Calculate overall risk score
            analysis_result['risk_score'] = self._calculate_risk_score(analysis_result['anomalies'])

            # Generate behavioral flags
            analysis_result['behavioral_flags'] = self._generate_behavioral_flags(analysis_result)

        except Exception as e:
            logger.error(f"Process behavior analysis failed: {e}")
            analysis_result['error'] = str(e)

        return analysis_result

    def _analyze_cpu_behavior(self, process_info: Dict[str, Any], 
                            historical_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Analyze CPU usage behavior patterns"""
        anomalies = []
        current_cpu = process_info.get('cpu_percent', 0)

        if len(historical_data) >= 5:
            historical_cpu = [data.get('cpu_percent', 0) for data in historical_data[-5:]]
            avg_cpu = statistics.mean(historical_cpu)

            # Check for sudden CPU spikes
            if current_cpu > self.anomaly_thresholds['cpu_usage']['spike_threshold']:
                anomalies.append({
                    'type': 'cpu_spike',
                    'current_value': current_cpu,
                    'threshold': self.anomaly_thresholds['cpu_usage']['spike_threshold'],
                    'severity': 'high'
                })

            # Check for sustained high CPU usage
            if avg_cpu > self.anomaly_thresholds['cpu_usage']['sustained_threshold']:
                anomalies.append({
                    'type': 'sustained_high_cpu',
                    'average_value': avg_cpu,
                    'threshold': self.anomaly_thresholds['cpu_usage']['sustained_threshold'],
                    'severity': 'medium'
                })

        return anomalies

    def _analyze_memory_behavior(self, process_info: Dict[str, Any], 
                               historical_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Analyze memory usage behavior patterns"""
        anomalies = []
        current_memory = process_info.get('memory_percent', 0)

        if len(historical_data) >= 3:
            historical_memory = [data.get('memory_percent', 0) for data in historical_data[-3:]]

            # Check for rapid memory growth
            if len(historical_memory) >= 2:
                growth_rate = (current_memory - historical_memory[0]) / len(historical_memory)
                if growth_rate > self.anomaly_thresholds['memory_usage']['growth_rate']:
                    anomalies.append({
                        'type': 'rapid_memory_growth',
                        'growth_rate': growth_rate,
                        'threshold': self.anomaly_thresholds['memory_usage']['growth_rate'],
                        'severity': 'high'
                    })

            # Check for memory spike
            if current_memory > self.anomaly_thresholds['memory_usage']['spike_threshold']:
                anomalies.append({
                    'type': 'memory_spike',
                    'current_value': current_memory,
                    'threshold': self.anomaly_thresholds['memory_usage']['spike_threshold'],
                    'severity': 'high'
                })

        return anomalies

    def _analyze_io_behavior(self, process_info: Dict[str, Any], 
                           historical_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Analyze I/O behavior patterns"""
        anomalies = []

        # Simulate I/O analysis (in real implementation, would use process I/O counters)
        simulated_io_ops = process_info.get('simulated_io_ops', 0)

        if simulated_io_ops > self.anomaly_thresholds['disk_io']['spike_threshold']:
            anomalies.append({
                'type': 'excessive_disk_io',
                'io_operations': simulated_io_ops,
                'threshold': self.anomaly_thresholds['disk_io']['spike_threshold'],
                'severity': 'medium'
            })

        return anomalies

    def _analyze_network_behavior(self, process_info: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Analyze network behavior patterns"""
        anomalies = []

        # Check for suspicious network connections
        try:
            connections = psutil.net_connections()
            process_connections = [conn for conn in connections 
                                 if conn.pid == process_info.get('pid')]

            if len(process_connections) > 10:  # Threshold for suspicious connection count
                anomalies.append({
                    'type': 'excessive_network_connections',
                    'connection_count': len(process_connections),
                    'threshold': 10,
                    'severity': 'medium'
                })

            # Check for connections to suspicious ports
            suspicious_ports = [4444, 5555, 6666, 31337, 1337]
            for conn in process_connections:
                if conn.raddr and conn.raddr.port in suspicious_ports:
                    anomalies.append({
                        'type': 'suspicious_port_connection',
                        'port': conn.raddr.port,
                        'address': conn.raddr.ip,
                        'severity': 'high'
                    })

        except Exception as e:
            logger.warning(f"Network behavior analysis warning: {e}")

        return anomalies

    def _calculate_risk_score(self, anomalies: List[Dict[str, Any]]) -> int:
        """Calculate overall risk score based on anomalies"""
        score = 0
        severity_weights = {'low': 1, 'medium': 3, 'high': 5, 'critical': 10}

        for anomaly in anomalies:
            severity = anomaly.get('severity', 'low')
            score += severity_weights.get(severity, 1)

        return min(score, 100)  # Cap at 100

    def _generate_behavioral_flags(self, analysis_result: Dict[str, Any]) -> List[str]:
        """Generate behavioral flags based on analysis"""
        flags = []

        if analysis_result['risk_score'] > 50:
            flags.append('HIGH_RISK_BEHAVIOR')

        anomaly_types = [anomaly['type'] for anomaly in analysis_result['anomalies']]

        if 'cpu_spike' in anomaly_types or 'sustained_high_cpu' in anomaly_types:
            flags.append('RESOURCE_ABUSE')

        if 'rapid_memory_growth' in anomaly_types:
            flags.append('MEMORY_ANOMALY')

        if 'suspicious_port_connection' in anomaly_types:
            flags.append('NETWORK_THREAT')

        if 'excessive_network_connections' in anomaly_types:
            flags.append('NETWORK_ABUSE')

        return flags

class RealTimeMonitor:
    """Real-time system monitoring with advanced detection"""

    def __init__(self):
        self.monitoring_active = False
        self.process_history = defaultdict(lambda: deque(maxlen=10))
        self.system_metrics_history = deque(maxlen=100)
        self.alert_queue = deque(maxlen=1000)
        self.monitoring_threads = []

    def start_monitoring(self):
        """Start real-time monitoring threads"""
        if self.monitoring_active:
            logger.warning("Monitoring already active")
            return

        self.monitoring_active = True

        # Start monitoring threads
        threads = [
            threading.Thread(target=self._monitor_processes, daemon=True),
            threading.Thread(target=self._monitor_system_resources, daemon=True),
            threading.Thread(target=self._monitor_file_system, daemon=True),
            threading.Thread(target=self._monitor_network_activity, daemon=True)
        ]

        for thread in threads:
            thread.start()
            self.monitoring_threads.append(thread)

        logger.info("Real-time monitoring started")

    def stop_monitoring(self):
        """Stop real-time monitoring"""
        self.monitoring_active = False
        logger.info("Real-time monitoring stopped")

    def _monitor_processes(self):
        """Monitor process creation, termination, and behavior"""
        known_processes = set()

        while self.monitoring_active:
            try:
                current_processes = {p.pid: p.info for p in psutil.process_iter(['pid', 'name', 'exe', 'cpu_percent', 'memory_percent', 'create_time'])}
                current_pids = set(current_processes.keys())

                # Detect new processes
                new_processes = current_pids - known_processes
                for pid in new_processes:
                    process_info = current_processes[pid]
                    self._analyze_new_process(process_info)

                # Detect terminated processes
                terminated_processes = known_processes - current_pids
                for pid in terminated_processes:
                    self._handle_process_termination(pid)

                # Update process history and analyze behavior
                for pid, process_info in current_processes.items():
                    self.process_history[pid].append({
                        **process_info,
                        'timestamp': datetime.now().isoformat()
                    })

                known_processes = current_pids
                time.sleep(2)  # Monitor every 2 seconds

            except Exception as e:
                logger.error(f"Process monitoring error: {e}")
                time.sleep(5)

    def _analyze_new_process(self, process_info: Dict[str, Any]):
        """Analyze newly created process"""
        try:
            # Basic suspicious process detection
            process_name = process_info.get('name', '').lower()
            process_exe = process_info.get('exe', '').lower()

            suspicious_indicators = [
                'temp' in process_name or 'tmp' in process_name,
                len(process_name) > 20 and any(c.isdigit() for c in process_name),
                process_exe and ('temp' in process_exe or 'appdata' in process_exe),
                not process_exe,  # No executable path
            ]

            if any(suspicious_indicators):
                self.alert_queue.append({
                    'type': 'suspicious_process_creation',
                    'process_info': process_info,
                    'timestamp': datetime.now().isoformat(),
                    'severity': 'medium'
                })
                logger.warning(f"Suspicious process detected: {process_name} (PID: {process_info.get('pid')})")

        except Exception as e:
            logger.error(f"New process analysis error: {e}")

    def _handle_process_termination(self, pid: int):
        """Handle process termination"""
        if pid in self.process_history:
            process_history = list(self.process_history[pid])
            if process_history:
                last_info = process_history[-1]
                # Check if process had suspicious behavior before termination
                if len(process_history) < 3:  # Very short-lived process
                    self.alert_queue.append({
                        'type': 'short_lived_process',
                        'pid': pid,
                        'name': last_info.get('name'),
                        'lifetime_seconds': len(process_history) * 2,  # Approximate
                        'severity': 'low'
                    })

            # Clean up history
            del self.process_history[pid]

    def _monitor_system_resources(self):
        """Monitor system-wide resource usage"""
        while self.monitoring_active:
            try:
                system_metrics = {
                    'timestamp': datetime.now().isoformat(),
                    'cpu_percent': psutil.cpu_percent(interval=1),
                    'memory_percent': psutil.virtual_memory().percent,
                    'disk_usage_percent': psutil.disk_usage('/').percent if os.path.exists('/') else 0,
                    'network_connections': len(psutil.net_connections()),
                    'process_count': len(psutil.pids())
                }

                self.system_metrics_history.append(system_metrics)

                # Check for system-wide anomalies
                self._check_system_anomalies(system_metrics)

                time.sleep(10)  # Monitor every 10 seconds

            except Exception as e:
                logger.error(f"System resource monitoring error: {e}")
                time.sleep(15)

    def _check_system_anomalies(self, current_metrics: Dict[str, Any]):
        """Check for system-wide anomalies"""
        try:
            if len(self.system_metrics_history) >= 5:
                recent_metrics = list(self.system_metrics_history)[-5:]

                # Check CPU usage trend
                cpu_values = [m['cpu_percent'] for m in recent_metrics]
                avg_cpu = statistics.mean(cpu_values)

                if avg_cpu > 90:
                    self.alert_queue.append({
                        'type': 'sustained_high_cpu',
                        'average_cpu': avg_cpu,
                        'current_cpu': current_metrics['cpu_percent'],
                        'severity': 'high'
                    })

                # Check memory usage trend
                memory_values = [m['memory_percent'] for m in recent_metrics]
                if len(memory_values) >= 2:
                    memory_growth = memory_values[-1] - memory_values[0]
                    if memory_growth > 20:  # 20% growth in monitoring window
                        self.alert_queue.append({
                            'type': 'rapid_memory_growth',
                            'growth_percent': memory_growth,
                            'current_memory': current_metrics['memory_percent'],
                            'severity': 'medium'
                        })

        except Exception as e:
            logger.error(f"System anomaly check error: {e}")

    def _monitor_file_system(self):
        """Monitor file system for suspicious activity"""
        while self.monitoring_active:
            try:
                # Monitor critical system directories
                critical_paths = [
                    '/etc', '/usr/bin', '/usr/sbin', '/boot',
                    'C:\\Windows\\System32', 'C:\\Windows\\SysWOW64'
                ]

                for path in critical_paths:
                    if os.path.exists(path):
                        # In real implementation, would use file system monitoring
                        # For now, just check if path is accessible
                        try:
                            os.listdir(path)
                        except PermissionError:
                            self.alert_queue.append({
                                'type': 'critical_path_access_denied',
                                'path': path,
                                'severity': 'high'
                            })

                time.sleep(30)  # Check every 30 seconds

            except Exception as e:
                logger.error(f"File system monitoring error: {e}")
                time.sleep(60)

    def _monitor_network_activity(self):
        """Monitor network activity for suspicious patterns"""
        connection_history = deque(maxlen=50)

        while self.monitoring_active:
            try:
                current_connections = psutil.net_connections()
                connection_count = len(current_connections)

                connection_history.append({
                    'timestamp': datetime.now().isoformat(),
                    'connection_count': connection_count,
                    'connections': current_connections
                })

                # Check for connection anomalies
                if len(connection_history) >= 3:
                    recent_counts = [entry['connection_count'] for entry in list(connection_history)[-3:]]
                    if max(recent_counts) - min(recent_counts) > 50:  # Rapid connection change
                        self.alert_queue.append({
                            'type': 'rapid_connection_change',
                            'connection_counts': recent_counts,
                            'severity': 'medium'
                        })

                # Check for suspicious connections
                suspicious_ports = [4444, 5555, 6666, 31337, 1337]
                for conn in current_connections:
                    if conn.raddr and conn.raddr.port in suspicious_ports:
                        self.alert_queue.append({
                            'type': 'suspicious_port_connection',
                            'local_addr': f"{conn.laddr.ip}:{conn.laddr.port}" if conn.laddr else "unknown",
                            'remote_addr': f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else "unknown",
                            'pid': conn.pid,
                            'severity': 'high'
                        })

                time.sleep(15)  # Monitor every 15 seconds

            except Exception as e:
                logger.error(f"Network monitoring error: {e}")
                time.sleep(30)

    def get_recent_alerts(self, count: int = 10) -> List[Dict[str, Any]]:
        """Get recent alerts from monitoring"""
        return list(self.alert_queue)[-count:] if self.alert_queue else []

class WardenMonitor:
    """Enhanced WardenMonitor with advanced real-time monitoring and behavioral analysis"""

    def __init__(self, config_path: str = "config.json"):
        """Initialize WardenMonitor with comprehensive monitoring capabilities"""
        self.config = self._load_config(config_path)
        self.guardian_interface = None
        self.monitoring_active = False

        # Initialize advanced monitoring components
        self.behavioral_engine = BehavioralAnalysisEngine()
        self.realtime_monitor = RealTimeMonitor()

        self.process_registry = {}
        self.alert_queue = deque(maxlen=1000)
        self.monitoring_statistics = {
            'processes_analyzed': 0,
            'threats_detected': 0,
            'alerts_generated': 0,
            'start_time': None
        }

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                logger.info("Configuration loaded successfully")
                return config
        except FileNotFoundError:
            logger.warning("Config file not found, using defaults")
            return self._get_default_config()
        except json.JSONDecodeError as e:
            logger.error(f"Config file parsing error: {e}")
            return self._get_default_config()

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "monitoring": {
                "behavioral_analysis": True,
                "realtime_monitoring": True,
                "process_monitoring": True,
                "network_monitoring": True,
                "file_system_monitoring": True
            },
            "thresholds": {
                "high_risk_score": 70,
                "medium_risk_score": 40,
                "alert_threshold": 50
            },
            "integration": {
                "halo_guardian": True,
                "dom0_layer": True,
                "haven_memory": True
            }
        }

    def initialize_monitoring(self) -> bool:
        """Initialize comprehensive monitoring systems"""
        logger.info("Initializing WardenMonitor...")

        try:
            # Connect to AGI-OS systems
            self._connect_to_guardian_system()
            self._setup_dom0_monitoring()
            self._setup_haven_memory_monitoring()

            # Initialize behavioral analysis
            if self.config.get("monitoring", {}).get("behavioral_analysis", True):
                if not self.behavioral_engine.initialize_behavioral_analysis():
                    logger.error("Failed to initialize behavioral analysis")
                    return False

            # Initialize real-time monitoring
            if self.config.get("monitoring", {}).get("realtime_monitoring", True):
                self.realtime_monitor.start_monitoring()

            self.monitoring_active = True
            self.monitoring_statistics['start_time'] = datetime.now().isoformat()
            logger.info("WardenMonitor initialized successfully")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize monitoring: {e}")
            return False

    def _connect_to_guardian_system(self):
        """Connect to existing AGI-OS guardian system"""
        guardian_path = "../../assets/etc/security/guardian/"
        if os.path.exists(guardian_path):
            logger.info("Connected to AGI-OS guardian system")
            self.guardian_interface = {
                'path': guardian_path,
                'connected': True,
                'capabilities': ['threat_reporting', 'policy_enforcement']
            }
            return True
        else:
            logger.warning("AGI-OS guardian system not found")
            return False

    def _setup_dom0_monitoring(self):
        """Setup monitoring for DOM0 layer applications"""
        dom0_path = "../../assets/usr/dom0/"
        if os.path.exists(dom0_path):
            logger.info("DOM0 layer monitoring initialized")
            self._scan_dom0_applications()
        else:
            logger.warning("DOM0 layer not found")

    def _scan_dom0_applications(self):
        """Scan and register DOM0 applications"""
        dom0_apps_path = "../../assets/usr/dom0/apps/"
        if os.path.exists(dom0_apps_path):
            try:
                for app in os.listdir(dom0_apps_path):
                    app_path = os.path.join(dom0_apps_path, app)
                    self.process_registry[app] = {
                        "type": "dom0_app",
                        "path": app_path,
                        "first_seen": datetime.now().isoformat(),
                        "status": "registered",
                        "risk_score": 0,
                        "behavioral_flags": []
                    }
                logger.info(f"Registered {len(self.process_registry)} DOM0 applications")
            except Exception as e:
                logger.error(f"DOM0 application scanning error: {e}")

    def _setup_haven_memory_monitoring(self):
        """Setup memory monitoring through HAVEN layer"""
        haven_memory_path = "../../assets/var/haven/memory/"
        if os.path.exists(haven_memory_path):
            logger.info("HAVEN memory monitoring initialized")
        else:
            logger.warning("HAVEN memory layer not found")

    def perform_comprehensive_analysis(self) -> Dict[str, Any]:
        """Perform comprehensive behavioral analysis of all monitored processes"""
        logger.info("Starting comprehensive behavioral analysis...")

        analysis_results = {
            'analysis_id': hashlib.md5(str(datetime.now()).encode()).hexdigest()[:8],
            'timestamp': datetime.now().isoformat(),
            'processes_analyzed': 0,
            'high_risk_processes': [],
            'medium_risk_processes': [],
            'alerts_generated': [],
            'system_health': {}
        }

        try:
            # Analyze all running processes
            for process in psutil.process_iter(['pid', 'name', 'exe', 'cpu_percent', 'memory_percent']):
                try:
                    process_info = process.info
                    historical_data = list(self.realtime_monitor.process_history.get(process_info['pid'], []))

                    # Perform behavioral analysis
                    behavior_analysis = self.behavioral_engine.analyze_process_behavior(
                        process_info, historical_data
                    )

                    analysis_results['processes_analyzed'] += 1

                    # Categorize by risk level
                    risk_score = behavior_analysis.get('risk_score', 0)
                    if risk_score >= self.config.get("thresholds", {}).get("high_risk_score", 70):
                        analysis_results['high_risk_processes'].append(behavior_analysis)
                    elif risk_score >= self.config.get("thresholds", {}).get("medium_risk_score", 40):
                        analysis_results['medium_risk_processes'].append(behavior_analysis)

                    # Generate alerts for high-risk processes
                    if risk_score >= self.config.get("thresholds", {}).get("alert_threshold", 50):
                        alert = {
                            'type': 'high_risk_process_detected',
                            'process_info': behavior_analysis,
                            'timestamp': datetime.now().isoformat(),
                            'severity': 'high' if risk_score >= 70 else 'medium'
                        }
                        analysis_results['alerts_generated'].append(alert)
                        self.alert_queue.append(alert)
                        self.monitoring_statistics['alerts_generated'] += 1

                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                except Exception as e:
                    logger.error(f"Process analysis error: {e}")
                    continue

            # Get real-time monitoring alerts
            realtime_alerts = self.realtime_monitor.get_recent_alerts(20)
            analysis_results['alerts_generated'].extend(realtime_alerts)

            # Analyze system health
            analysis_results['system_health'] = self._analyze_system_health()

            # Update statistics
            self.monitoring_statistics['processes_analyzed'] += analysis_results['processes_analyzed']
            self.monitoring_statistics['threats_detected'] += len(analysis_results['high_risk_processes'])

            logger.info(f"Analysis completed: {analysis_results['processes_analyzed']} processes analyzed, "
                       f"{len(analysis_results['high_risk_processes'])} high-risk processes found")

        except Exception as e:
            logger.error(f"Comprehensive analysis failed: {e}")
            analysis_results['error'] = str(e)

        return analysis_results

    def _analyze_system_health(self) -> Dict[str, Any]:
        """Analyze overall system health"""
        try:
            system_health = {
                'cpu_usage': psutil.cpu_percent(interval=1),
                'memory_usage': psutil.virtual_memory().percent,
                'disk_usage': psutil.disk_usage('/').percent if os.path.exists('/') else 0,
                'process_count': len(psutil.pids()),
                'network_connections': len(psutil.net_connections()),
                'uptime_hours': (time.time() - psutil.boot_time()) / 3600,
                'health_status': 'healthy'
            }

            # Determine health status
            if (system_health['cpu_usage'] > 90 or 
                system_health['memory_usage'] > 95 or 
                system_health['disk_usage'] > 95):
                system_health['health_status'] = 'critical'
            elif (system_health['cpu_usage'] > 80 or 
                  system_health['memory_usage'] > 85 or 
                  system_health['disk_usage'] > 85):
                system_health['health_status'] = 'warning'

            return system_health

        except Exception as e:
            logger.error(f"System health analysis error: {e}")
            return {'health_status': 'unknown', 'error': str(e)}

    def get_monitoring_status(self) -> Dict[str, Any]:
        """Get comprehensive monitoring status"""
        return {
            'monitoring_active': self.monitoring_active,
            'guardian_connected': self.guardian_interface is not None,
            'behavioral_analysis_active': self.behavioral_engine.learning_mode,
            'realtime_monitoring_active': self.realtime_monitor.monitoring_active,
            'registered_processes': len(self.process_registry),
            'pending_alerts': len(self.alert_queue),
            'statistics': self.monitoring_statistics,
            'last_update': datetime.now().isoformat()
        }

    def get_alerts(self, severity_filter: Optional[str] = None, count: int = 50) -> List[Dict[str, Any]]:
        """Get alerts with optional severity filtering"""
        alerts = list(self.alert_queue)

        if severity_filter:
            alerts = [alert for alert in alerts if alert.get('severity') == severity_filter]

        return alerts[-count:] if alerts else []

    def stop_monitoring(self):
        """Stop all monitoring activities"""
        self.monitoring_active = False
        self.realtime_monitor.stop_monitoring()
        logger.info("WardenMonitor stopped")

if __name__ == "__main__":
    # Initialize and test WardenMonitor
    monitor = WardenMonitor()

    if monitor.initialize_monitoring():
        print("WardenMonitor initialized successfully")

        # Run monitoring for a short period
        time.sleep(5)

        # Perform comprehensive analysis
        analysis_result = monitor.perform_comprehensive_analysis()
        print("\nComprehensive Analysis Results:")
        print(json.dumps(analysis_result, indent=2))

        # Show monitoring status
        status = monitor.get_monitoring_status()
        print("\nMonitoring Status:")
        print(json.dumps(status, indent=2))

        # Get recent alerts
        alerts = monitor.get_alerts(count=10)
        print(f"\nRecent Alerts ({len(alerts)}):")
        for alert in alerts:
            print(f"- {alert.get('type', 'unknown')}: {alert.get('severity', 'unknown')}")

        monitor.stop_monitoring()
    else:
        print("Failed to initialize WardenMonitor")
