#!/bin/bash
# PhiGuard Rescue Environment
clear
echo "=================================================="
echo "    PhiGuard Antivirus Recovery Environment"
echo "=================================================="
echo
echo "Available Tools:"
echo "1. System Scan"
echo "2. Malware Removal"
echo "3. System Recovery"
echo "4. Network Diagnostics"
echo "5. File System Check"
echo "6. Emergency Shell"
echo
echo "Select an option (1-6):"
read choice

case $choice in
    1) echo "Starting system scan..."; python3 /antivirus/ReHabScanner/main.py --full-scan ;;
    2) echo "Starting malware removal..."; python3 /antivirus/PhiGuard_Core/main.py --remove-threats ;;
    3) echo "Starting system recovery..."; python3 /antivirus/Setup/main.py --recovery-mode ;;
    4) echo "Running network diagnostics..."; python3 /antivirus/PsiShield/main.py --network-check ;;
    5) echo "Checking file system..."; fsck -f /dev/sda1 ;;
    6) echo "Entering emergency shell..."; /bin/bash ;;
    *) echo "Invalid option" ;;
esac
